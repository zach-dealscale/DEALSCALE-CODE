from django.urls import path
from .salesforce import service as salesforce_service
from . import views
from .zoom import webhook as zoom_webhook

urlpatterns = [
    #salesforce urls
    path("salesforce/connect/", views.ConnectSalesforceView.as_view(), name="connect_salesforce"),
    path("salesforce/callback/", views.SalesforceCallbackView.as_view(), name="salesforce_callback"),
    path('salesforce/sync-contacts/', views.FetchSalesforceContactsView.as_view(), name="fetch_user_contacts"),
    
    #zoom urls
    path("zoom/login/", views.ZoomLoginView.as_view(), name="zoom_login"),
    path("zoom/callback/", views.ZoomCallbackView.as_view(), name="zoom_callback"),
    path("zoom/meetings/", views.ZoomMeetingsTranscriptsView.as_view(), name="zoom_meetings"),
    path('zoom/webhook/', zoom_webhook.ZoomWebhookView.as_view(), name='zoom_webhook'),
    
    #google drive
    path("drive/connect/", views.GoogleDriveConnectView.as_view(), name="google_drive_connect"),
    path("drive/callback/", views.GoogleDriveCallbackView.as_view(), name="google_drive_callback"),
    path("drive/listfiles/", views.GoogleDriveListFilesView.as_view(), name="google_drive_list"),

]
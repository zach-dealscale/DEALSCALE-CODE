from apps.integrations.models import ZoomCredential
from apps.integrations.zoom.oauth import ZoomOAuth
from django.http import HttpResponseBadRequest
from django.shortcuts import render
from apps.integrations.models import SalesforceCredential
from apps.integrations.salesforce.oauth import SalesforceOAuth
import requests
from django.contrib.auth.mixins import LoginRequiredMixin
import logging
from django.contrib import messages
from .salesforce.service import SalesforceService
from .utils.crypto import TokenEncryptor
from apps.integrations.google_drive.oauth import GoogleDriveOAuth
from apps.integrations.google_drive.service import GoogleDriveService
logger = logging.getLogger(__name__)
from django.utils import timezone
from django.views import View
from django.http import JsonResponse
from django.shortcuts import redirect
from apps.integrations.zoom.service import ZoomService


class ZoomMeetingsTranscriptsView(View):
    def get(self, request):
        if not request.user.is_authenticated:
            return JsonResponse({"error": "Authentication required"}, status=401)

        if not request.user.zoom_token.exists():
            messages.warning(request, "Please connect your Zoom account first.")
            return redirect("profile")

        try:
            service = ZoomService(user=request.user)
        
            saved_transcripts = service.fetch_and_save_transcripts()
            messages.success(request, f"Successfully saved {len(saved_transcripts)} transcript(s).")
        except Exception as e:
            return JsonResponse({"error": f"Failed to fetch transcripts: {str(e)}"}, status=500)

        return redirect("transcripts_list")



class ZoomLoginView(View):
    """
    Redirects user to Zoom's OAuth authorization URL.
    """
    def get(self, request, *args, **kwargs):
        zoom_oauth = ZoomOAuth()
        auth_url = zoom_oauth.get_authorization_url()
        return redirect(auth_url)

class ZoomCallbackView(LoginRequiredMixin, View):
    """
    Handles Zoom OAuth callback and stores tokens in the DB.
    """
    def get(self, request, *args, **kwargs):
        code = request.GET.get("code")

        if not code:
            return JsonResponse({"error": "Authorization code not found"}, status=400)

        zoom_oauth = ZoomOAuth()
        try:
            token_data = zoom_oauth.get_access_token(code)

            ZoomCredential.objects.update_or_create(
                user=request.user,
                defaults={
                    "access_token": TokenEncryptor.encrypt(token_data["access_token"]),
                    "refresh_token": TokenEncryptor.encrypt(token_data["refresh_token"]),
                    "expires_in": token_data["expires_in"],
                    "created_at": timezone.now(),
                }
            )
            messages.success(request, "Zoom connected successfully!")
            return redirect("profile")

        except Exception as e:
            return JsonResponse({"error": f"Failed to authenticate with Zoom: {str(e)}"}, status=500)


class ConnectSalesforceView(LoginRequiredMixin, View):
    """
    Views for Connecting The SalesForce Account
    """
    def get(self, request, *args, **kwargs):
        oauth = SalesforceOAuth(user=request.user, session=request.session)
        auth_url = oauth.get_authorization_url(prompt_consent=True)
        return redirect(auth_url)

# room_views.py

class GoogleDriveConnectView(View):
    def get(self, request):
        oauth = GoogleDriveOAuth(user=request.user)
        auth_url, state = oauth.get_authorization_url()
        request.session['gd_state'] = state
        return redirect(auth_url)

class GoogleDriveCallbackView(View):
    def get(self, request):
        state = request.session.get('gd_state')
        if not state:
            messages.error(request, "OAuth state is missing. Please try connecting again.")
            return redirect('dashboard')

        oauth = GoogleDriveOAuth(user=request.user)
        try:
            oauth.exchange_code_for_token(request.build_absolute_uri())
            messages.success(request, "✅ Google Drive connected successfully!")
        except Exception as e:
            messages.error(request, f"❌ Failed to connect Google Drive: {str(e)}")

        return redirect('dashboard')



class GoogleDriveListFilesView(LoginRequiredMixin, View):
    def get(self, request):
        try:
            google_drive_service = GoogleDriveService(user=request.user)
            files_response = google_drive_service.list_user_files()

            # Extract files from the response
            if files_response.get('success'):
                files = files_response.get('data', {}).get('files', [])
            else:
                files = []

            context = {
                'drive_files': files,
                'success': files_response.get('success', False),
                'error': files_response.get('error', None) if not files_response.get('success') else None
            }

            return render(request, 'list_files.html', context)

        except Exception as e:
            context = {
                'drive_files': [],
                'success': False,
                'error': str(e)
            }
            return render(request, 'list_files.html', context)

class SalesforceCallbackView(LoginRequiredMixin, View):
    """
    OAuth Callback view for Salesforce
    """
    def get(self, request, *args, **kwargs):
        code = request.GET.get("code")
        if not code:
            return HttpResponseBadRequest("No authorization code provided.")

        state = request.GET.get("state")
        oauth = SalesforceOAuth(user=request.user, session=request.session)

        try:
            token_data = oauth.fetch_token(code, state=state)
        except requests.exceptions.RequestException as e:
            return HttpResponseBadRequest(f"Failed to fetch token: {str(e)}")

        salesforce_id_url = token_data.get("id", "")
        salesforce_id = salesforce_id_url.split("/")[-1] if salesforce_id_url else ""

        SalesforceCredential.objects.update_or_create(
            user=request.user,
            defaults={
                "access_token": TokenEncryptor.encrypt(token_data.get("access_token")),
                "refresh_token": TokenEncryptor.encrypt(token_data.get("refresh_token")),
                "signature": token_data.get("signature"),
                "scope": token_data.get("scope"),
                "instance_url": token_data.get("instance_url"),
                "salesforce_id": salesforce_id,
                "token_type": token_data.get("token_type"),
                "issued_at": int(token_data.get("issued_at")),
            }
        )

        return redirect("home")



class FetchSalesforceContactsView(LoginRequiredMixin, View):
    """
    View to fetch and import Salesforce contacts into local DB
    """
    def get(self, request, *args, **kwargs):
        service = SalesforceService(request.user)

        try:
            contacts = service.fetch_contacts()
            saved_data = service.import_contacts_to_db(request.user, contacts)

            messages.success(request, f"Successfully imported {len(saved_data)} Salesforce contact(s).")
        except Exception as e:
            messages.error(request, f"Salesforce import failed: {str(e)}")

        return redirect("deal_list")


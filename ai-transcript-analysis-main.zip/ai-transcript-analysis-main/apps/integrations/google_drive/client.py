from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from .oauth import GoogleDriveOAuth
import logging
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)

class GoogleDriveClient:
    def __init__(self, user):
        self.user = user
        self.oauth = GoogleDriveOAuth(user)
        self.credentials = self.oauth.get_valid_credentials()
        self.service = build("gmail", "v1", credentials=self.credentials)

    def list_messages(self, query=None, max_results=20):
        try:
            response = self.service.users().messages().list(
                userId="me", q=query or "", maxResults=max_results
            ).execute()
            return {"success": True, "data": response}
        except HttpError as e:
            logger.error(f"[Gmail] list_messages failed for {self.user.email}: {e}")
            return {"success": False, "error": str(e)}

    def get_message(self, message_id):
        try:
            message = self.service.users().messages().get(
                userId="me", id=message_id, format="full"
            ).execute()
            return {"success": True, "data": message}
        except HttpError as e:
            logger.error(f"[Gmail] get_message failed for {self.user.email}, ID: {message_id}: {e}")
            return {"success": False, "error": str(e)}

    def send_message(self, to, subject, body):
        try:
            message = MIMEText(body)
            message["to"] = to
            message["subject"] = subject
            raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
            sent = self.service.users().messages().send(
                userId="me", body={"raw": raw}
            ).execute()
            return {"success": True, "data": sent}
        except HttpError as e:
            logger.error(f"[Gmail] send_message failed for {self.user.email}: {e}")
            return {"success": False, "error": str(e)}

    def list_threads(self, query=None, max_results=20):
        try:
            threads = self.service.users().threads().list(
                userId="me", q=query or "", maxResults=max_results
            ).execute()
            return {"success": True, "data": threads}
        except HttpError as e:
            logger.error(f"[Gmail] list_threads failed for {self.user.email}: {e}")
            return {"success": False, "error": str(e)}

    def get_thread(self, thread_id):
        try:
            thread = self.service.users().threads().get(
                userId="me", id=thread_id, format="full"
            ).execute()
            return {"success": True, "data": thread}
        except HttpError as e:
            logger.error(f"[Gmail] get_thread failed for {self.user.email}, ID: {thread_id}: {e}")
            return {"success": False, "error": str(e)}

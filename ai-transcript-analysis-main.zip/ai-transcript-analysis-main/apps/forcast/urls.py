from django.urls import path
from . import views

urlpatterns = [
    path('forecast/', views.ForcastDashboardView.as_view(), name='forcast_dashboard'),
    path("forecast/delete/<str:id>/", views.DealForecastIntelligenceDeleteView.as_view(), name="forecast_delete"),
    path('analytics/', views.analytics_view, name='analytics'),
]



# views.py
from django.views.generic import TemplateView, DeleteView
from django.db.models import Sum, Avg
from django.views import View
from django.shortcuts import get_object_or_404, redirect
from django.http import JsonResponse, Http404
from django.contrib import messages
from django.urls import reverse_lazy, reverse
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import DealForecastIntelligence
from ..core.utils import humanize_big_number
from ..core.mixins import ForecastAccessMixin, RoleBasedClientAccessMixin


class ForcastDashboardView(LoginRequiredMixin, RoleBasedClientAccessMixin, TemplateView):
    template_name = "forcast.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["page_title"] = "Executive Dashboard"
        context["welcome_message"] = "Welcome to the Forecast Dashboard"

        # Get accessible clients based on user's role (same pattern as DealListView)
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)

        # Fetch deal forecast intelligence data for accessible clients only
        forecast_deals = DealForecastIntelligence.objects.filter(
            client__in=accessible_clients
        ).select_related('client', 'company').order_by('-created_at')
        context["forecast_deals"] = forecast_deals
        
        # Calculate metrics for top cards
        if forecast_deals.exists():
            # Total Pipeline - sum of all client company sizes
            total_pipeline = forecast_deals.aggregate(
                total=Sum('client__company_size')
            )['total'] or 0
            # Closing This Quarter - sum of company sizes where is_this_quarter = True
            this_quarter_deals = forecast_deals.filter(
                # Using the model method to filter
            ).exclude(client__company_size__isnull=True)
            
            # Filter deals that are closing this quarter using the model method
            closing_this_quarter = 0
            closing_this_quarter_count = 0
            for deal in forecast_deals:
                if deal.get_is_this_quarter() and deal.client.company_size:
                    closing_this_quarter += deal.client.company_size
                    closing_this_quarter_count += 1
            
            # Average Probability
            avg_probability = forecast_deals.aggregate(
                avg=Avg('final_win_probability')
            )['avg'] or 0
            
            # Deals at Risk - count of deals with high risk
            deals_at_risk = forecast_deals.filter(
                risk_level__iexact='high'
            ).count()
            
        else:
            total_pipeline = 0
            closing_this_quarter = 0
            closing_this_quarter_count = 0
            avg_probability = 0
            deals_at_risk = 0
        
        # Add metrics to context
        context.update({
            'total_pipeline': humanize_big_number(total_pipeline),
            'closing_this_quarter': closing_this_quarter,
            'closing_this_quarter_count': closing_this_quarter_count,
            'avg_probability': round(avg_probability, 1) if avg_probability else 0,
            'deals_at_risk': deals_at_risk,
        })
        
        return context


class ForecastDeleteView(LoginRequiredMixin, RoleBasedClientAccessMixin, View):
    """
    Handles deletion of a DealForecastIntelligence instance.
    Supports both standard POST and AJAX requests.
    Verifies user has access to the forecast's client before deletion.
    """

    success_url = reverse_lazy("forcast_dashboard")

    def post(self, request, pk, *args, **kwargs):
        forecast = get_object_or_404(DealForecastIntelligence, pk=pk)

        # Verify user has access to this forecast's client
        user = request.user
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=forecast.client_id).exists():
            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse({
                    "success": False,
                    "error": "You don't have permission to delete this forecast."
                }, status=403)
            messages.error(request, "You don't have permission to delete this forecast.")
            return redirect(self.success_url)

        try:
            forecast.delete()
            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse({
                    "success": True,
                    "message": "Forecast deleted successfully."
                })
            messages.success(request, "Forecast deleted successfully.")
        except Exception as e:
            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse({
                    "success": False,
                    "error": str(e)
                })
            messages.error(request, f"Error deleting forecast: {e}")
        return redirect(self.success_url)


class DealForecastIntelligenceDeleteView(ForecastAccessMixin, RoleBasedClientAccessMixin, DeleteView):
    """
    Handles deletion of DealForecastIntelligence objects.
    Works with both normal POST and JS fetch() requests.
    Verifies user has access to the forecast's client before deletion.
    """
    model = DealForecastIntelligence
    template_name = "confirm_delete.html"
    context_object_name = "deal_forecast_intelligence"

    def get_success_url(self):
        return reverse("forcast_dashboard")

    def get_queryset(self):
        """Return DealForecastIntelligence queryset (override mixin's Client queryset)."""
        return DealForecastIntelligence.objects.all()

    def get_object(self, queryset=None):
        """Get object by string ID with role-based access check."""
        if queryset is None:
            queryset = self.get_queryset()

        # Get the ID from URL kwargs (string-based primary key)
        forecast_id = self.kwargs.get("id")
        if not forecast_id:
            raise Http404("No forecast ID provided.")

        # Look up by the string primary key field
        obj = get_object_or_404(queryset, id=forecast_id)

        # Verify user has access to this forecast's client
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=obj.client_id).exists():
            messages.error(self.request, "You don't have permission to delete this forecast.")
            raise Http404("Forecast not found or access denied.")

        return obj

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.delete()

        # Handle AJAX/fetch requests
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"success": True, "message": "Forecast deleted successfully."})

        # Fallback for normal form submission
        messages.success(request, "Deal Forecast Intelligence deleted successfully.")
        return redirect(self.get_success_url())


# Analytics Dashboard View
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.db.models import Count, Q
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

@login_required
def analytics_view(request):
    """
    Analytics dashboard with permission check.
    Checks if user has can_view_analytics permission or is admin.
    """
    # Permission check: user must have analytics access or admin access
    # if not request.user.is_authenticated:
    #     messages.error(request, "You must be logged in to access this feature.")
    #     return redirect('login')

    # if not request.user.company:
    #     messages.error(request, "You must be part of a company to access this feature.")
    #     return redirect('home')

    # # Check if user's role has the required permission
    # if not (request.user.role and (request.user.role.can_view_all_data or request.user.role.can_view_analytics)):
    #     messages.error(request, "Your role does not have access to the Analytics feature.")
    #     return redirect('home')

    from apps.authentication.models import Client

    # ROW 1: Top Statistics Cards (Test Data for MVP)

    # Card 1: Total Pipeline Value
    total_pipeline_value = 25.4  # Test: $25.4M
    total_pipeline_deals = 47  # Test: 47 deals

    # Card 2: Active Deals
    active_deals_count = 35  # Test: 35 active deals
    total_deals = 47
    active_deals_percent = round((active_deals_count / total_deals * 100), 1) if total_deals > 0 else 0

    # Card 3: Closed Deals (Won & Lost)
    closed_won_count = 28
    closed_lost_count = 12
    total_closed = closed_won_count + closed_lost_count
    won_percentage = round((closed_won_count / total_closed * 100), 1) if total_closed > 0 else 0
    lost_percentage = round((closed_lost_count / total_closed * 100), 1) if total_closed > 0 else 0

    # Card 4: Average Deal Size
    avg_deal_size = 2.3  # Test: $2.3M

    # ROW 2: Pipeline Health & Win/Loss Analysis

    # Pipeline by Stage (for funnel chart)
    # Stage names are centralized in Stage class
    pipeline_by_stage = [
        {'name': 'Discovery', 'count': 15, 'value': 8500000, 'color': '#3B82F6'},
        {'name': 'Evaluation', 'count': 12, 'value': 6200000, 'color': '#A78BFA'},
        {'name': 'Validation', 'count': 8, 'value': 4800000, 'color': '#FBBF24'},
        {'name': 'Procurement', 'count': 6, 'value': 3200000, 'color': '#FB923C'},
    ]

    # Win/Loss Analysis
    win_rate = round((closed_won_count / total_closed * 100), 1) if total_closed > 0 else 0

    # ROW 3: Revenue Forecast & Stage Conversions

    # Revenue Forecast (6 months: current -1 to current +4)
    current_date = datetime.now()
    revenue_forecast = []
    for i in range(-1, 5):
        month_date = current_date + relativedelta(months=i)
        month_label = month_date.strftime('%b %Y')

        # Test data with growth trend
        if i < 0:
            forecasted = 1.8
            actual = 1.5
        elif i == 0:
            forecasted = 2.2
            actual = 2.0
        else:
            forecasted = 2.2 + (i * 0.3)
            actual = 0 if i > 0 else forecasted * 0.9

        revenue_forecast.append({
            'month': month_label,
            'forecasted': forecasted,
            'actual': actual if i <= 0 else 0
        })

    # Stage Conversion Rates (for funnel)
    # Stage names are centralized in Stage class
    stage_conversions = [
        {'from': 'Discovery', 'to': 'Evaluation', 'rate': 80, 'count': 12},
        {'from': 'Evaluation', 'to': 'Validation', 'rate': 67, 'count': 8},
        {'from': 'Validation', 'to': 'Procurement', 'rate': 75, 'count': 6},
        {'from': 'Procurement', 'to': 'Closed Won', 'rate': 67, 'count': 4},
    ]

    context = {
        # Row 1: Top stat cards
        'total_pipeline_value': total_pipeline_value,
        'total_pipeline_deals': total_pipeline_deals,
        'active_deals_count': active_deals_count,
        'active_deals_percent': active_deals_percent,
        'closed_won_count': closed_won_count,
        'closed_lost_count': closed_lost_count,
        'won_percentage': won_percentage,
        'lost_percentage': lost_percentage,
        'avg_deal_size': avg_deal_size,

        # Row 2: Charts
        'pipeline_by_stage': pipeline_by_stage,
        'win_rate': win_rate,

        # Row 3: Advanced charts
        'revenue_forecast': revenue_forecast,
        'stage_conversions': stage_conversions,

        # Meta
        'total_deals': total_deals,
        'total_closed': total_closed,
    }

    return render(request, 'analytics.html', context)
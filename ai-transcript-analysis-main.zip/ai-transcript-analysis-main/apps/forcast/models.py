from django.db import models
from apps.core.models import BaseModel
from apps.authentication.models import Client, Company



class DealForecastIntelligence(BaseModel):
    PREFIX = "DFI"

    client = models.OneToOneField(
        Client,
        on_delete=models.CASCADE,
        related_name='deal_forecast'
    )

    # Company-level scoping (same pattern as ReportDocument, ReportFormation)
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='deal_forecasts',
        null=True,
        blank=True
    )

    current_deal_stage = models.CharField(max_length=100)
    start_date = models.DateField()
    close_date = models.DateField()
    risk_level = models.CharField(max_length=50)
    final_win_probability = models.FloatField(help_text="Probability percentage (0-100)")
    key_deal_signals = models.JSONField(default=list, help_text="List of AI detected signals")
    risk_exposure_summary = models.TextField(default="")
    deal_saving_move = models.TextField(default="")

    def get_content_summary(self):
        return self.risk_exposure_summary + '<b>' + self.deal_saving_move + '</b>'

    def save(self, *args, **kwargs):
        """Auto-set company from client if not already set."""
        if not self.company and self.client and self.client.company:
            self.company = self.client.company
        super().save(*args, **kwargs)

    def get_is_this_quarter(self):
        from datetime import date, timedelta

        try:
            today = date.today()
            start = self.start_date
            close = self.close_date

            current_quarter = (today.month - 1) // 3 + 1
            quarter_start_month = 3 * (current_quarter - 1) + 1
            quarter_start = date(today.year, quarter_start_month, 1)

            if current_quarter == 4:
                next_quarter_start = date(today.year + 1, 1, 1)
            else:
                next_quarter_start = date(today.year, quarter_start_month + 3, 1)

            quarter_end = next_quarter_start - timedelta(days=1)
            print("Quarter:", quarter_start, "→", quarter_end)

            return quarter_start <= close <= quarter_end

        except Exception as e:
            print(f"[get_is_this_quarter error] {e}")
            return False

    class Meta:
        verbose_name = "Deal Forecast Intelligence"
        verbose_name_plural = "Deal Forecast Intelligence"
        indexes = [
            models.Index(fields=['company', 'created_at'], name='dfi_company_created_idx'),
            models.Index(fields=['company', 'risk_level'], name='dfi_company_risk_idx'),
        ]

    def __str__(self):
        return f"{self.client.name} - {self.current_deal_stage} ({self.final_win_probability}%)"

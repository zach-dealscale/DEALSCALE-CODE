from django.contrib import admin
from .models import DealForecastIntelligence


@admin.register(DealForecastIntelligence)
class DealForecastIntelligenceAdmin(admin.ModelAdmin):
    list_display = ('client', 'current_deal_stage', 'close_date', 'risk_level', 'final_win_probability', 'get_is_this_quarter', 'created_at')
    list_filter = ('current_deal_stage', 'risk_level', 'created_at')
    search_fields = ('client__name',)
    readonly_fields = ('id', 'created_at', 'updated_at', 'get_is_this_quarter')
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('client', 'current_deal_stage', 'start_date', 'close_date')
        }),
        ('Forecast Analysis', {
            'fields': ('final_win_probability', 'risk_level', 'risk_exposure_summary', 'deal_saving_move')
        }),
        ('AI Analysis', {
            'fields': ('key_deal_signals',)
        }),
        ('System Info', {
            'fields': ('id', 'created_at', 'updated_at', 'get_is_this_quarter'),
            'classes': ('collapse',)
        }),
    )

from django import template

register = template.Library()

@register.filter
def humanize_big_number(value):
    try:
        num = float(value)
    except (ValueError, TypeError):
        return value

    if num >= 1_000_000_000:
        formatted = num / 1_000_000_000
        suffix = "B"
    elif num >= 1_000_000:
        formatted = num / 1_000_000
        suffix = "M"
    elif num >= 1_000:
        formatted = num / 1_000
        suffix = "K"
    else:
        return str(int(num))

    formatted = int(formatted * 10) / 10.0
    return f"{formatted:.1f}{suffix}"
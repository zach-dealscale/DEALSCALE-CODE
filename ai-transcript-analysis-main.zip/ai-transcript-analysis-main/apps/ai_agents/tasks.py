import json
from celery import shared_task
from io import BytesIO
from django.db import transaction
from apps.report_management.models import ReportFormation, ReportDocument

from django.template.loader import render_to_string
import logging

from apps.ai_agents.utils.ai_report_generator import ReportGenerator
from apps.ai_agents.utils.html_extractor import clean_llm_html_response
from apps.report_management.utils import link_document_to_salesroom, save_pdf_with_fallbacks, generate_and_save_pdf
from xhtml2pdf import pisa
from datetime import datetime

logger = logging.getLogger(__name__)


@shared_task(bind=True)
def generate_report_task(self, uuid, report_document_id=None):
    """
    Robust report generation task — now supports multiple transcripts with separators.
    """
    try:
        report_instance = ReportFormation.objects.get(id=uuid)
        print("Checking Transcripts in The Celery Task", report_instance.transcript)

        # Collect transcripts in order
        transcripts_to_merge = []

        if hasattr(report_instance, "transcript") and report_instance.transcript:
            transcripts_to_merge.append(report_instance.transcript)

        if hasattr(report_instance, "transcripts") and report_instance.transcripts.exists():
            transcripts_to_merge.extend(report_instance.transcripts.all())

        if hasattr(report_instance, "additional_transcripts") and report_instance.additional_transcripts.exists():
            transcripts_to_merge.extend(report_instance.additional_transcripts.all())

        if not transcripts_to_merge:
            raise ValueError("No transcript found for this report formation")

        # Merge transcripts with separators
        transcript_text = ""
        for idx, t in enumerate(transcripts_to_merge, start=1):
            if idx > 1:
                transcript_text += f"\n\n----- Start Transcript {idx} -----\n\n"
            transcript_text += t.text or ""

        # --- Generate report content ---
        generator = ReportGenerator(template_object=report_instance.template)
        transcript_output_data = generator.generate_report(
            transcript=transcript_text,
            report_instance=report_instance
        )

        try:
            output_json = clean_llm_html_response(transcript_output_data)
            with transaction.atomic():
                report_instance.output_data = {'data': output_json}
                report_instance.status = "completed"
                report_instance.save(update_fields=["output_data", "status"])
        except json.JSONDecodeError as e:
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.error(f"Failed to parse JSON from agent output: {e}")
            return {"status": "error", "message": str(e)}
        except Exception as e:
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.error(f"Unexpected error while saving report output: {e}")
            return {"status": "error", "message": str(e)}

        # --- Create document title safely ---
        first_transcript = transcripts_to_merge[0]
        client_name = getattr(first_transcript.client, "name", "Unknown Client")
        transcript_title = getattr(first_transcript, "title", "Untitled Transcript")
        template_title = getattr(report_instance.template, "title", "Untitled Template")

        new_document_title = f"{template_title} - {transcript_title} - {client_name}"
        updated_content = report_instance.get_editor_content()

        # --- Create or update document ---
        if report_document_id:
            try:
                generated_document = ReportDocument.objects.get(pk=report_document_id)
                generated_document.content = updated_content
                generated_document.title = generated_document.title or new_document_title
                generated_document.user = generated_document.user or report_instance.user
                generated_document.save()
            except ReportDocument.DoesNotExist:
                generated_document = ReportDocument.objects.filter(report=report_instance).first()
                if generated_document:
                    generated_document.content = updated_content
                    generated_document.save()
                else:
                    generated_document = ReportDocument.objects.create(
                        report=report_instance,
                        title=new_document_title,
                        content=updated_content,
                        user=report_instance.user,
                        created_by=report_instance.user,
                        version="v1"
                    )
        else:
            generated_document = ReportDocument.objects.filter(report=report_instance).first()
            if generated_document:
                generated_document.content = updated_content
                generated_document.save()
            else:
                generated_document = ReportDocument.objects.create(
                    report=report_instance,
                    title=new_document_title,
                    content=updated_content,
                    user=report_instance.user,
                    created_by=report_instance.user,
                    version="v1"
                )

        # --- Generate PDF + link to SalesRoom ---
        generate_and_save_pdf(generated_document)
        link_document_to_salesroom(generated_document, created=True)

        return {
            "status": "success",
            "report_id": uuid,
            "existing": False,
            "task_id": self.request.id
        }

    except ReportFormation.DoesNotExist:
        msg = f"[Verification] ReportFormation ID: {uuid} not found"
        logger.error(msg)
        return {"status": "error", "message": msg}

    except Exception as e:
        msg = f"[Verification] Critical error processing ReportFormation ID: {uuid} - {str(e)}"
        logger.error(msg, exc_info=True)
        if 'report_instance' in locals():
            prev_status = report_instance.status
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.info(f"[Verification] Updated status from '{prev_status}' to 'failed' after error")
        return {"status": "error", "message": msg}




def regenerate_document_file(doc):
    """Regenerate PDF file for existing document with verification"""
    try:
        logger.info(f"[Verification] Starting file regeneration for document {doc.id}")

        # Version verification and increment
        current_version = doc.version if doc.version else "v0"
        try:
            current_version_num = int(current_version[1:]) if current_version.startswith('v') else 0
        except (ValueError, AttributeError):
            current_version_num = 0

        new_version_num = current_version_num + 1
        doc.version = f"v{new_version_num}"

        # Update title with new version
        base_title = doc.title
        if " (v" in base_title:
            base_title = base_title[:base_title.rfind(" (v")]
        doc.title = f"{base_title} (v{new_version_num})"

        doc.save(update_fields=['version', 'title'])
        logger.info(f"[Verification] Version updated from {current_version} to {doc.version}")

        # Rest of the regeneration logic remains the same...
        context = {"title": doc.title, "content": doc.content}
        logger.debug(f"[Verification] Regeneration context - Title: {doc.title}, Content length: {len(doc.content)}")

        html = render_to_string("documents/document_pdf_template.html", context)
        pdf_buffer = BytesIO()
        pisa_status = pisa.CreatePDF(html, dest=pdf_buffer)
        if pisa_status.err:
            logger.error(f"[Verification] PDF regeneration errors: {pisa_status.err}")
            raise ValueError("PDF regeneration failed")
        logger.info(f"[Verification] PDF regenerated successfully - Size: {pdf_buffer.tell()} bytes")

        old_file = doc.file.name if doc.file else None
        old_size = doc.file.size if doc.file else 0
        save_pdf_with_fallbacks(doc, pdf_buffer.getvalue())
        logger.info(f"[Verification] File saved - Old: {old_file} ({old_size} bytes), "
                    f"New: {doc.file.name} ({doc.file.size} bytes)")

        link_document_to_salesroom(doc, created=False)
        logger.info(f"[Verification] Salesroom link updated for regenerated file")

    except Exception as e:
        logger.error(f"[Verification] Document file regeneration failed: {str(e)}", exc_info=True)
        raise


@shared_task(bind=True)
def generate_report_task_streaming(self, uuid: int, report_document_id: int):
    """
    Generate a report with streaming output to Redis pub/sub.

    This is a streaming version of the report generation task that:
    - Publishes progress updates to Redis
    - Allows real-time monitoring of report generation
    - Maintains the same functionality as the original task

    Args:
        uuid: ReportFormation ID
        report_document_id: ReportDocument ID for pub/sub channel

    Returns:
        dict: Task status and metadata
    """
    try:
        report_instance = ReportFormation.objects.get(id=uuid)

        # 4. Generate report content with input verification
        transcript = report_instance.get_transcript()
        generator = ReportGenerator(template_object=report_instance.template)

        # Use streaming version and collect all content
        full_content = ""
        try:
            for content_chunk in generator.generate_report_streaming(
                    transcript=transcript,
                    report_document_id=report_document_id
            ):
                full_content += str(content_chunk)

        except Exception as streaming_error:
            logger.error(f"Streaming error: {streaming_error}")
            # Publish error to Redis
            if generator.redis_client:
                channel_name = f"report_generation_{report_document_id}"
                generator.redis_client.publish(channel_name, json.dumps({
                    "type": "error",
                    "message": f"Streaming error: {str(streaming_error)}",
                    "timestamp": str(datetime.now())
                }))
            raise streaming_error

        # Process the collected content
        try:
            output_json = full_content.replace("```html", "").replace("```", "").strip()

            # Save atomically
            with transaction.atomic():
                report_instance.output_data = {'data': output_json}
                report_instance.status = "completed"
                report_instance.save(update_fields=["output_data", "status"])

        except json.JSONDecodeError as e:
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.error(f"Failed to parse JSON from agent output: {e}")
        except Exception as e:
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.error(f"Unexpected error while saving report output: {e}")

        # Directly generate a document from the report instance
        new_document_title = f"{report_instance.template.title} - {report_instance.transcript.title} - {report_instance.transcript.client.name}"
        generated_document = ReportDocument.objects.filter(report=report_instance).first()
        updated_content = report_instance.get_editor_content()
        if generated_document:
            generated_document.content = updated_content
            generated_document.save()
        else:
            generated_document = ReportDocument(
                report=report_instance,
                title=new_document_title,
                content=report_instance.get_editor_content(),
                user=report_instance.user,
                version="v1"
            )
        generated_document.save()

        # Save document as pdf
        generate_and_save_pdf(generated_document)

        # Link the document to the salesroom
        link_document_to_salesroom(generated_document, created=True)

        # Send completion message with final data
        if generator.redis_client:
            channel_name = f"report_generation_{report_document_id}"
            generator.redis_client.publish(channel_name, json.dumps({
                "type": "complete",
                "message": "Report generation completed successfully",
                "data": output_json,  # Send the final processed content
                "timestamp": str(datetime.now())
            }))

        return {
            "status": "success",
            "report_id": uuid,
            "report_document_id": report_document_id,
            "task_id": self.request.id
        }

    except ReportFormation.DoesNotExist:
        error_msg = f"[Streaming] ReportFormation ID: {uuid} not found in database"
        logger.error(error_msg)
        return {"status": "error", "message": error_msg}

    except Exception as e:
        error_msg = f"[Streaming] Critical error processing ReportFormation ID: {uuid} - {str(e)}"
        logger.error(error_msg, exc_info=True)
        if 'report_instance' in locals():
            original_status = report_instance.status
            report_instance.status = "failed"
            report_instance.save(update_fields=["status"])
            logger.info(f"[Streaming] Updated status from '{original_status}' to 'failed' after error")
        return {"status": "error", "message": error_msg}

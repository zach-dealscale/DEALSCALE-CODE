import re


def extract_html_content(content):
    """
    Extract only HTML content from LLM response, removing conversational text.
    Handles cases where LLM adds introductory/concluding text like:
    - "Here is your html content"
    - "Looking at your transcript, let me create an html for you:"
    - "Above is what you asked, refine it as you need"
    
    Args:
        content (str): Raw LLM response containing HTML and conversational text
        
    Returns:
        str: Clean HTML content without conversational text
    """
    if not content:
        return ""
    
    # Remove code block markers first
    content = re.sub(r'```html\s*', '', content, flags=re.IGNORECASE)
    content = re.sub(r'```\s*$', '', content, flags=re.MULTILINE)
    
    # Find the first HTML tag (opening tag)
    first_html_match = re.search(r'<[^>]+>', content)
    if not first_html_match:
        return content.strip()  # No HTML found, return as is
    
    # Find the last HTML tag (closing tag)
    last_html_match = None
    html_tags = re.findall(r'</[^>]+>', content)
    if html_tags:
        last_tag = html_tags[-1]
        last_html_match = content.rfind(last_tag)
        if last_html_match != -1:
            last_html_match += len(last_tag)
    
    if last_html_match:
        # Extract content from first HTML tag to last HTML tag
        extracted = content[first_html_match.start():last_html_match].strip()
        return extracted
    
    # Fallback: if we can't find proper closing tags, return from first HTML tag to end
    return content[first_html_match.start():].strip()


def clean_llm_html_response(raw_response):
    """
    Convenience function to clean LLM HTML responses.
    
    Args:
        raw_response (str): Raw LLM response
        
    Returns:
        str: Clean HTML content
    """
    return extract_html_content(raw_response)
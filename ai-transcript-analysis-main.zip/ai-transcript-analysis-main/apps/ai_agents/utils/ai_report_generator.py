import json
import types
from chunk import Chunk

import redis
from django.conf import settings
from agno.agent import Agent
from agno.models.openai import OpenAIChat
from django.core.exceptions import ValidationError
from datetime import datetime
import asyncio

from apps.ai_agents.apis import serializers
from apps.ai_agents.services.deal_forcasy_extraction_agent import DealForecastExtractionAgent
from apps.core.models import BaseModel
from apps.report_management.constants import GENERAL_INSTRUCTIONS
from apps.report_management.models import ReportTemplate
from apps.report_management.helpers.report_choices import ReportTypeChoices
from apps.report_management.helpers.pydantic_to_docs_converter import DocBuilder
from apps.ai_agents.services.agent_service import SalesAgent
from apps.forcast.models import DealForecastIntelligence
import logging

logger = logging.getLogger(__name__)



class ReportGenerator:
    """
      Report generation utility class that uses the AGNO library to generate structured reports from transcripts.
    """

    def __init__(self, template_object):
        if not template_object:
            raise ValueError("template_object is required")
        
        logger.debug("[ReportGenerator] Using provided template_object")
        template = template_object

        if not template:
            logger.error("[ReportGenerator] Invalid or missing template object")
            raise ValueError("Invalid template object provided")

        self.template = template
        self.report_instance = None
        self.agent = SalesAgent(template=template)
        self.framework_prompt = template.framework_prompt

        # Initialize Redis connection for streaming
        try:
            self.redis_client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=0,
                decode_responses=True
            )
        except Exception as e:
            print(f"Redis connection failed: {e}")
            self.redis_client = None

    def get_final_prompt(self, transcript: str, framework_prompt, tool_instructions = '') -> str:
        prompt = f"""
            You are provided with two inputs:

            ### 1. Transcript (raw sales call):
            {transcript}

            ---

            ### 2. Framework Prompt (report rules and schema guidance):
            {framework_prompt}

            {tool_instructions}
        """
        logger.debug(f"prompt: {prompt}")
        return prompt

    def get_close_forecast_tool_instructions(self) -> str:
        """
        Returns tool call instructions for close forecast reports.
        """
        from textwrap import dedent
        return dedent("""
            ### TOOL INSTRUCTIONS FOR CLOSE FORECAST REPORTS:

            <TOOL CALL>
            Use 'generate_deal_forecast_intelligence' tool function to save important metrics /
            information in database. Follow the instructions below to pass the data in
            the tool.

            MAP the information like this:
            - Current Deal Stage -> current_deal_stage
            - Forecasted Close Window -> forecasted_close_window_start_date, forecasted_close_window_end_date
            - Final Win Probability -> final_win_probability
            - Key Deal Signals -> key_deal_signals (Important Note: 🟢 ,⚠️, 🔴 must include these icons before the actual signals)
            - Risk Exposure Summary -> risk_exposure_summary
            
            **CRITICAL CONSISTENCY REQUIREMENT:**
                - The 'final_win_probability' value MUST be EXACTLY the same as the win probability percentage 
                  shown in the Close Forecast Brief report content
                - Do NOT recalculate or modify the probability when calling the tool
                - Use the identical probability value that appears in the generated report
            MUST call the tool ('generate_deal_forecast_intelligence') function with above mapped values
            </TOOL CALL>
        """
    )

    def generate_report(self, transcript: str, report_instance=None):
        """
        Generate a structured report from a given transcript using streaming for better quality.
        Uses synchronous streaming via self.run_stream() — no async logic required.
        """
        self.report_instance = report_instance

        # Add tool call instructions if this is a close forecast brief
        tool_instructions = ""
        if self.template and self.template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF:
            tool_instructions = self.get_close_forecast_tool_instructions()

        # Construct the final LLM prompt
        prompt = self.get_final_prompt(transcript, self.framework_prompt, tool_instructions)

        try:
            accumulated_content = ""

            # First: Generate the main report
            for chunk in self.agent.run(prompt, stream=True):
                if hasattr(chunk, "content") and chunk.content and chunk.event == "RunResponseContent":
                    accumulated_content += chunk.content
                    logger.info(accumulated_content)

                # Handle any direct tool calls from the first agent run
                self._handle_tool_call(chunk)

            # Second: Extract intelligence data using dedicated agent
            if self.template and self.template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF:
                logger.info("Using dedicated extraction agent with schema validation...")

                try:

                    extraction_agent = DealForecastExtractionAgent()
                    validated_forecast_data = extraction_agent.extract_forecast_data(accumulated_content)

                    # Convert to dict for database storage
                    forecast_data_dict = validated_forecast_data.dict()

                    logger.info(f"Successfully extracted and validated forecast data")

                    # Create/update forecast intelligence
                    self._create_forecast_intelligence(validated_forecast_data)

                except Exception as extraction_error:
                    logger.error(f"Extraction agent failed: {extraction_error}")

            return accumulated_content

        except Exception as e:
            raise RuntimeError(f"Processing error: {str(e)}") from e

    def _handle_tool_call(self, chunk):
        """"""
        result_json = {}
        event_type = getattr(chunk, "event", None)
        if event_type == "ToolCallCompleted":
            logger.info("Chunk for Tool:", chunk)
            try:
                tool = getattr(chunk, "tool")
                tool_name = getattr(tool, "tool_name", None)
                result = getattr(tool, "result", None)
                # Convert to JSON if needed
                if isinstance(result, str):
                    try:
                        result_json = json.loads(result)
                    except json.JSONDecodeError:
                        result_json = {"raw_result": result}
                else:
                    result_json = result

                logger.info(f"Template Name: {self.template}, Tool Name: {tool_name}")
                if self.template and self.template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF and tool_name == "generate_deal_forecast_intelligence":
                    logger.info(f"Deal FOrcast saving in DB: {tool_name}")
                    self._create_forecast_intelligence(result_json)
            except Exception as e:
                print(f"❌ Tool parsing error: {e}")

        return result_json

    def _create_forecast_intelligence(self, result):
        """
        Create or update DealForecastIntelligence record(s) from agent response.
        Handles both single transcript and additional_transcripts cases.
        Sets company from client or report_instance for proper multi-tenant scoping.
        """
        logger.info("Create Forecast Intelligence initialized")

        try:
            forecast_data = result
            logger.info(f"forecast_data ==============> {forecast_data.dict()}")

            start_date = datetime.strptime(
                forecast_data.forecasted_close_window.start_date, "%Y-%m-%d"
            ).date()
            close_date = datetime.strptime(
                forecast_data.forecasted_close_window.end_date, "%Y-%m-%d"
            ).date()

            if not self.report_instance:
                logger.warning("⚠️ report_instance is None — skipping forecast intelligence creation.")
                return None

            # Get company from report_instance (most reliable source)
            company = getattr(self.report_instance, 'company', None)

            # Gather all related transcripts
            related_transcripts = []
            if getattr(self.report_instance, "transcript", None):
                related_transcripts.append(self.report_instance.transcript)
            if hasattr(self.report_instance, "additional_transcripts"):
                related_transcripts.extend(list(self.report_instance.additional_transcripts.all()))

            if not related_transcripts:
                logger.warning("⚠️ No transcripts found for this report instance.")
                return None

            created_instances = []
            seen_clients = set()

            # Loop through transcripts and collect unique clients
            for transcript in related_transcripts:
                if getattr(transcript, "client", None):
                    client = transcript.client
                    if client and client.id not in seen_clients:
                        seen_clients.add(client.id)

                        # Determine company: prefer report_instance.company, fallback to client.company
                        forecast_company = company or getattr(client, 'company', None)

                        forecast_instance, created = DealForecastIntelligence.objects.update_or_create(
                            client=client,
                            defaults={
                                "company": forecast_company,
                                "current_deal_stage": forecast_data.current_deal_stage,
                                "start_date": start_date,
                                "close_date": close_date,
                                "risk_level": forecast_data.risk_level.risk_level,
                                "final_win_probability": forecast_data.final_win_probability,
                                "key_deal_signals": forecast_data.key_deal_signals,
                                "risk_exposure_summary": forecast_data.risk_exposure_summary,
                                "deal_saving_move": forecast_data.deal_saving_move,
                            },
                        )
                        created_instances.append(forecast_instance)
                        logger.info(
                            f"✅ Forecast intelligence {'created' if created else 'updated'} for client: {client} (company: {forecast_company})")

            if not created_instances:
                logger.warning("⚠️ No valid clients found in transcripts — forecast intelligence not created.")
                return None

            return created_instances if len(created_instances) > 1 else created_instances[0]

        except Exception as e:
            logger.error(f"❌ Error processing forecast data: {e}", exc_info=True)
            return None

    async def generate_report_stream(self, transcript: str, report_instance=None):
        """
        Generate a structured report from a given transcript with streaming support.
        :param transcript: The raw sales call transcript
        :param report_instance: Optional report instance for linking
        :yield: Dictionary chunks containing content and event information
        """
        # Add tool call instructions for close forecast reports
        tool_instructions = ""
        print(f"Template Key: {self.template.key} & Report Type: { ReportTypeChoices.CLOSE_FORECAST_BRIEF}")
        logger.info(f"Template Key: {self.template.key} & Report Type: { ReportTypeChoices.CLOSE_FORECAST_BRIEF}")
        if self.template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF:
            tool_instructions = self.get_close_forecast_tool_instructions()
        print("Tools Intructions:  ", tool_instructions)

        prompt = f"""
            You are provided with two inputs:

            ### 1. Transcript (raw sales call):
            {transcript}

            ---

            ### 2. Framework Prompt (report rules and schema guidance):
            {self.framework_prompt}

            {tool_instructions}

           
        """

        final_response = None
        accumulated_content = ""

        try:
            response = await self.agent.arun_stream(prompt)
            
            async for chunk in response:
                if hasattr(chunk, 'content') and chunk.content:
                    accumulated_content += chunk.content
                    chunk_json = {
                        "content": chunk.content, 
                        "event": getattr(chunk, 'event', 'chunk'),
                        "accumulated_content": accumulated_content
                    }
                    yield chunk_json
                
                # Keep track of the final response for post-processing
                final_response = chunk
            
            # Handle forecast intelligence creation if this is a close forecast brief
            if self.template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF and final_response:
                self._create_forecast_intelligence(final_response, report_instance)
                
            yield {
                "event": "complete",
                "content": "",
                "accumulated_content": accumulated_content
            }

        except ValidationError as e:
            error_messages = [f"{'.'.join(map(str, err['loc']))}: {err['msg']}" for err in e.errors()]
            yield {
                "event": "error",
                "content": "",
                "error": {"schema_errors": error_messages}
            }
        except Exception as e:
            yield {
                "event": "error", 
                "content": "",
                "error": f"Processing error: {str(e)}"
            }


# apps/ai_agents/services/extraction_agent.py
from django.conf import settings
from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.models.anthropic import Claude
from textwrap import dedent
from pydantic import ValidationError as PydanticValidationError

from apps.report_management.pydantic_models.close_forcast_intellegence_brief import DealForecastIntelligenceSchema


class DealForecastExtractionAgent:
    AGENT_NAME = "Deal Forecast Intelligence Extractor"
    AGENT_ROLE = dedent("""\
        You are a Deal Forecast Intelligence Extractor — an AI agent specialized in 
        extracting structured deal forecast data EXACTLY as it appears in generated sales reports.
    """)

    AGENT_SYSTEM_PROMPT = dedent("""
        ## Objective:
        Extract structured deal forecast intelligence data from generated sales reports 
        and return it in EXACTLY the same format and wording as it appears in the report.

        ## CRITICAL REQUIREMENTS:
        - Extract values EXACTLY as they appear in the report
        - DO NOT modify, rephrase, or reinterpret any content
        - Copy Key Deal Signals EXACTLY (same icons, same wording, same order)
        - Copy Risk Exposure Summary EXACTLY (word-for-word)
        - Use the EXACT win probability percentage shown
        - Use the EXACT dates shown in the report
        - Use the EXACT deal stage terminology from the report

        ## Output Requirements:
        - Return valid JSON that matches the exact schema requirements
        - Dates must be in YYYY-MM-DD format as shown in report
        - Win probability must be the exact number from the report (0-100)
        - Key deal signals must be identical to report (same 🟢, ⚠️, 🔴 icons and text)
        - Risk exposure summary must be identical to report wording

        ## Risk Level Calculation:
        - Below 60%: "high" risk (Red)
        - 60-79%: "medium" risk (Yellow)  
        - 80%+: "low" risk (Green)

        ## Output Format:
        Return ONLY the JSON object, no additional text or explanations.
    """)

    # Default IDs (can be overridden by settings)
    CLAUDE_MODEL_ID = "claude-sonnet-4-5-20250929"
    OPENAI_MODEL_ID = 'gpt-4o'

    def __init__(self):
        # Detect available provider
        anthropic_key = getattr(settings, 'ANTHROPIC_API_KEY', None)
        openai_key = getattr(settings, 'OPENAI_API_KEY', None)

        # Optional overrides from settings
        settings_claude_id = getattr(settings, 'ANTHROPIC_MODEL_ID', None)
        settings_openai_id = getattr(settings, 'OPENAI_MODEL_ID', None)

        # Choose provider: prefer Anthropic if configured; else OpenAI; else error
        model_obj = None
        if anthropic_key:
            model_id = settings_claude_id or self.CLAUDE_MODEL_ID
            model_obj = Claude(id=model_id)
        elif openai_key:
            model_id = settings_openai_id or self.OPENAI_MODEL_ID
            model_obj = OpenAIChat(id=model_id)
        else:
            raise ValueError("No LLM API key configured. Set ANTHROPIC_API_KEY or OPENAI_API_KEY in environment.")

        self.output_instructions = "A valid JSON object containing extracted deal forecast intelligence data EXACTLY as it appears in the report."

        self.agent = Agent(
            model=model_obj,
            tools=[],
            show_tool_calls=False,
            name=self.AGENT_NAME,
            role=self.AGENT_ROLE,
            description=self.AGENT_SYSTEM_PROMPT,
            instructions=[],
            expected_output=self.output_instructions,
            response_model=DealForecastIntelligenceSchema,
            add_datetime_to_instructions=True,
            markdown=True,
            debug_mode=True,
            telemetry=False
        )

    def get_extraction_prompt(self, generated_report: str) -> str:
        """
        Returns the prompt for extracting deal forecast intelligence data.
        """
        return dedent(f"""
            ### EXTRACT DEAL FORECAST INTELLIGENCE DATA

            You are given a generated Close Forecast Brief report. Extract the following specific values 
            **EXACTLY AS THEY APPEAR** in the report content:

            **Generated Report:**
            {generated_report}

            **CRITICAL REQUIREMENT: Extract values EXACTLY as they appear in the report above**

            **Values to Extract:**
            1. **Current Deal Stage** - Extract the current stage of the deal EXACTLY as written in the report (e.g., 'Prospecting', 'Discovery', 'Negotiation', etc.)
            2. **Forecasted Close Dates** - Extract both start and end dates EXACTLY as shown in the report (format: YYYY-MM-DD)
            3. **Final Win Probability** - Extract the win probability percentage EXACTLY as shown in the report (0-100)
            4. **Risk Level** - Determine risk level based on the EXACT win probability from the report:
               - Below 60%: "high" risk
               - 60-79%: "medium" risk  
               - 80%+: "low" risk
            5. **Key Deal Signals** - Extract key deal signals EXACTLY as they appear in the report (include the SAME 🟢, ⚠️, 🔴 icons and wording)
            6. **Risk Exposure Summary** - Extract the risk exposure summary EXACTLY as written in the report
            7. **Deal-Saving Move** - Extract the content from the last section of the report named "Deal-Saving Move" without any heading, just content EXACTLY as written in the report

            **Output Format (JSON):**
            {{
                "current_deal_stage": "extracted deal stage EXACTLY as shown",
                "forecasted_close_window": {{
                    "start_date": "YYYY-MM-DD EXACTLY as shown",
                    "end_date": "YYYY-MM-DD EXACTLY as shown"
                }},
                "final_win_probability": 75.0, // EXACT number from report
                "risk_level": {{
                    "risk_level": "high/medium/low based on EXACT probability",
                    "color": "Red/Yellow/Green based on EXACT probability"
                }},
                "key_deal_signals": ["signal 1 EXACTLY as shown", "signal 2 EXACTLY as shown", ...], // MUST match report EXACTLY
                "risk_exposure_summary": "extracted risk summary EXACTLY as written" // MUST match report EXACTLY
                "deal_saving_move": "Pick the last section of the report named "Deal-Saving Move" without any heading, just content EXACTLY as written in the report // MUST match report EXACTLY"
            }}

            **IMPORTANT EXTRACTION RULES:**
            - Extract ONLY from the provided report content
            - DO NOT modify, rephrase, or reinterpret any values
            - Copy Key Deal Signals EXACTLY as they appear (same icons, same wording, same order)
            - Copy Risk Exposure Summary EXACTLY as written (word-for-word)
            - Use the EXACT win probability percentage shown in the report
            - Use the EXACT dates shown in the report
            - Use the EXACT deal stage terminology from the report
            - Risk level should be calculated based on the EXACT win probability from the report
            - Return valid JSON only, no additional text

            **EXACT MATCH REQUIREMENTS:**
            - Key Deal Signals: MUST be identical to what's in the report (same emojis, same text)
            - Risk Exposure Summary: MUST be identical to what's in the report (same wording)
            - Win Probability: MUST be the exact number from the report
            - Dates: MUST be the exact dates from the report
            - Deal Stage: MUST be the exact stage name from the report
            - Deal saving move: MUST be the exact same content from the last section of the report [Deal-Saving Move]
        """)

    def extract_forecast_data(self, generated_report: str) -> DealForecastIntelligenceSchema:
        """
        Extract and validate deal forecast intelligence data from generated report.
        """
        import logging

        logger = logging.getLogger(__name__)

        try:
            # Get extraction prompt
            prompt = self.get_extraction_prompt(generated_report)

            # Run the extraction agent
            extraction_response = self.agent.run(prompt, stream=False)

            # With response_model, the agent should return the validated Pydantic model directly
            if isinstance(extraction_response, DealForecastIntelligenceSchema):
                validated_data = extraction_response
                logger.info(f"Directly validated extraction data: {validated_data.dict()}")

                # Log critical fields to verify exact matching
                logger.info(f" Extracted Key Deal Signals: {validated_data.key_deal_signals}")
                logger.info(f" Extracted Risk Exposure Summary: {validated_data.risk_exposure_summary}")
                logger.info(f"Extracted Win Probability: {validated_data.final_win_probability}")

                return validated_data
            else:
                # If it's not the Pydantic model, it might be the raw response that needs parsing
                logger.info("Response is not Pydantic model, parsing as raw response")
                return self._parse_raw_response(extraction_response)

        except Exception as e:
            logger.error(f"Extraction error: {e}")
            raise ValueError(f"Extraction failed: {e}")

    def _parse_raw_response(self, extraction_response) -> DealForecastIntelligenceSchema:
        """
        Parse raw response when response_model doesn't return Pydantic model directly.
        """
        import json
        import logging
        import re

        logger = logging.getLogger(__name__)

        try:
            # Handle different response types
            if hasattr(extraction_response, 'content'):
                extraction_content = extraction_response.content
            elif isinstance(extraction_response, str):
                extraction_content = extraction_response
            else:
                # If it's already a Pydantic model or other object, try to convert
                extraction_content = str(extraction_response)

            logger.info(f"📊 Raw extraction response: {extraction_content}")

            # If it's already a Pydantic model, return it directly
            if isinstance(extraction_content, DealForecastIntelligenceSchema):
                return extraction_content

            # Clean the extraction content if it's a string
            if isinstance(extraction_content, str):
                cleaned_content = extraction_content.strip()
                if cleaned_content.startswith('```json'):
                    cleaned_content = cleaned_content[7:]
                if cleaned_content.endswith('```'):
                    cleaned_content = cleaned_content[:-3]
                cleaned_content = cleaned_content.strip()

                # Parse JSON
                try:
                    extraction_data = json.loads(cleaned_content)
                except json.JSONDecodeError:
                    # Try to find JSON in the content using regex
                    json_match = re.search(r'\{.*\}', cleaned_content, re.DOTALL)
                    if json_match:
                        extraction_data = json.loads(json_match.group())
                    else:
                        raise ValueError("No valid JSON found in extraction response")

                logger.info(f"Parsed extraction data: {extraction_data}")

                # Validate against Pydantic schema
                validated_data = DealForecastIntelligenceSchema(**extraction_data)

                # Log critical fields to verify exact matching
                logger.info(f"Extracted Key Deal Signals: {validated_data.key_deal_signals}")
                logger.info(f"Extracted Risk Exposure Summary: {validated_data.risk_exposure_summary}")
                logger.info(f"Extracted Win Probability: {validated_data.final_win_probability}")

                return validated_data
            else:
                raise ValueError(f"Unexpected response type: {type(extraction_content)}")

        except Exception as e:
            logger.error(f"Response parsing failed: {e}")
            raise

    async def extract_forecast_data_async(self, generated_report: str) -> DealForecastIntelligenceSchema:
        """
        Async version of extract_forecast_data.
        """
        import logging

        logger = logging.getLogger(__name__)

        try:
            # Get extraction prompt
            prompt = self.get_extraction_prompt(generated_report)

            # Run the extraction agent asynchronously
            extraction_response = await self.agent.arun(prompt)

            # Handle async response - collect all content
            extraction_content = ""
            async for chunk in extraction_response:
                if hasattr(chunk, 'content') and chunk.content:
                    extraction_content += chunk.content

            logger.info(f"📊 Raw async extraction response: {extraction_content}")

            # Use parsing for async
            return self._parse_raw_response(extraction_content)

        except Exception as e:
            logger.error(f"Async extraction error: {e}")
            raise ValueError(f"Async extraction failed: {e}")
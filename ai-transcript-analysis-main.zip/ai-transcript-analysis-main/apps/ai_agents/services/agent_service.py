from django.conf import settings
from agno.agent import Agent
from agno.models.openai import OpenAIChat, OpenAIResponses
from agno.models.anthropic import Claude
from textwrap import dedent
from agno.tools.calculator import CalculatorTools
from apps.report_management.helpers.report_choices import ReportTypeChoices


# **Highlight Classes for Key Information ONLY:**
# * Financial data: <div class="financial-highlight"> or <div class="cost-calculation">
# * ROI/positive metrics: <div class="roi-highlight">
# * Client quotes: <div class="quote-highlight"> or <div class="priority-quote">
# * Key insights: <div class="highlight-callout">
# * Risks/concerns: <div class="risk-item">
# * Strategic points: <div class="strategy-highlight"> or <div class="win-thesis">
# * Important metrics: <div class="metric-emphasis">
# * Key takeaways: <div class="key-info">
def generate_deal_forecast_intelligence(
        current_deal_stage: str,
        forecasted_close_window_start_date: str,
        forecasted_close_window_end_date: str,
        final_win_probability: float,
        risk_exposure_summary: str,
        key_deal_signals: list[str]
) -> str:
    """
    Generates deal forecast intelligence data to be saved in the database and used by AI Agent.

    Args:
        current_deal_stage (str): The current stage of the deal (e.g. 'Prospecting', 'Negotiation', etc.)
        forecasted_close_window_start_date (str - yyyy-mm-dd): Expected close date of the deal
        forecasted_close_window_end_date (str - yyyy-mm-dd): Expected close date of the deal
        final_win_probability (float): Success probability percentage between 0-100
        risk_exposure_summary (str): Summary of risk exposures identified in the deal
        key_deal_signals (list): List of signals detected by AI analysis

    Returns:
        str: A JSON-formatted string containing the deal forecast intelligence data
    """
    import json

    risk_level = None
    if final_win_probability < 60:
        risk_level = {
            "risk_level": "high",
            "color": "Red"
        }
    elif final_win_probability >= 60 and final_win_probability <= 79:
        risk_level = {
            "risk_level": "medium",
            "color": "Yellow"
        }
    else:
        risk_level = {
            "risk_level": "low",
            "color": "Green"
        }

    data = {
        'current_deal_stage': current_deal_stage,
        'forecasted_close_window': {
            'start_date': forecasted_close_window_start_date,
            'end_date': forecasted_close_window_end_date
        },
        'final_win_probability': final_win_probability,
        'key_deal_signals': key_deal_signals,
        'risk_level': risk_level,
        'risk_exposure_summary': risk_exposure_summary
    }
    return json.dumps(data)


class SalesAgent:
    AGENT_NAME = "Sales Calls Report Generator"
    AGENT_ROLE = dedent("""\
      You are a Sales Call Insights Generator — an analytical AI agent trained to 
      convert unstructured sales call transcripts into structured, professional business reports.
    """)
    AGENT_SYSTEM_PROMPT = dedent("""

      ## Objective:
      Generate accurate, context-rich reports that support decision-making for sales, marketing, and executive teams. Every field must be populated based on transcript content and aligned.
      Make sure, each section should be linguistically correct.
      Make sure, each section transition to next section logically.
      important: Logical flow must be maintained from top to bottom.    

      Given the following structure, fill it with professional, flowing, and human-sounding content.
      Make sure each field sounds natural and readable like a real paragraph.                                                  

      ## Output Format (Strict):
      - Start the output with report output, NEVER add any other text (Let me do..., looking at the transcript...)
      - Generate ONLY the HTML content (no DOCTYPE, html, head, or body tags). Generate div content only.
      - Output clean, semantic HTML with standardized CSS classes for professional formatting
      - Must add dot, comma, dash, colon, semicolon in sentence wherever needed.
      - DO NOT use icons in headings.

      **Document Structure & Flow:**
      - Ensure logical heading hierarchy (h1 → h2 → h3 → h4) 
      - Add proper spacing between sections for professional appearance
      - Use semantic HTML structure for accessibility
      - Use <b> or strong tag to bold inline heading. DO NOT use stars "**"

      **HTML Elements:**
        * Headers: <h1>, <h2>, <h3>, <h4> for section hierarchy
        * DO NOT use icon like (📊, 💼, 🎯, 🔄, 📋, etc) or symbols elements in headings.
        * Lists: <ul> and <ol> (DO NOT add highlight classes to bullet points or list items)
        * Paragraphs: <p> for text content
        * Tables: <table> with <thead>, <tbody> structure
        * Add dots, dashes, semicolon, colon or other separators as needed for clarity.
        * MUST Wrap amount, dates, currency, percentages in <strong> tags for emphasis.

      **Important Guidelines:**
      - NEVER apply highlight classes to list items (<li>) or bullet points
      - Use highlight classes ONLY for important callouts, not regular content
      - Add section breaks between major topics for better readability
      - Use proper heading hierarchy for professional document structure
      - Currency fields must be formatted as: `$X,XXX`
      - Ensure content flows logically from section to section
      - Never rename, omit, or restructure content sections
      - Maintain grammatical correctness and readability
      - Use li or ol list to maintain hierarchy of the content.
      - Use <p> tags for paragraphs, <ul> for unordered lists, and <ol> for ordered lists
      - All [List of str] content must go inside <ul> li or <ol> li tags. 
      - DO NOT use recurring <p> tags for each line, use <li> instead.

      ## 📌 Contextual Reasoning:
      - If info is implied, **infer and write it clearly**.
      - If vague, **translate into specific business terms**.
      - Include **verbatim buyer quotes** where needed.
      - Prioritize **latest conversation points** if multiple transcripts are provided.

      ## 📌 Data Sources:
      - Your only input is the **call transcript** (text).

      Your output must be accurate, structured, and client-ready.

      <TOOL USAGE>
        Always use calculator tool (add, subtract, multiply, divide, percentage, etc.) when you need to calculate the numbers.
      </TOOL USAGE>
      """)

    AGENT_INSTRUCTIONS = []
    # Default IDs (can be overridden by settings)
    CLAUDE_MODEL_ID = "claude-sonnet-4-5-20250929"
    OPENAI_MODEL_ID = 'gpt-4o'

    def set_followup_agent_mode(self):
        """
        Configure the agent for follow-up email generation mode.
        Updates agent name, role, and system prompt for email generation tasks.
        """
        self.AGENT_NAME = "Follow-up Email Generator"
        self.AGENT_ROLE = dedent("""\
          You are a Follow-up Email Generator — an AI agent specialized in 
          crafting professional follow-up emails based on sales call transcripts.
        """)
        self.AGENT_SYSTEM_PROMPT = dedent("""
          ## Objective:
          Generate professional, personalized follow-up emails based on sales call transcripts.
          Focus on maintaining conversation context and driving next steps.

          ## Output Format (Strict):
          - Start the output with the email content, NEVER add any other helper text
          - Generate ONLY the HTML content (no DOCTYPE, html, head, or body tags). Generate div content only.
          - Output clean, semantic HTML with standardized CSS classes for professional formatting
          - Use proper punctuation in sentences (dot, comma, dash, colon, semicolon)
          - DO NOT wrap the entire email in Markdown or code fences

          **HTML Elements:**
            * Headers: <h1>, <h2>, <h3>, <h4> for section hierarchy as needed
            * Paragraphs: <p> for text content
            * Lists: <ul> and <ol> for bullet points when appropriate
            * Tables: <table> with <thead>, <tbody> if you need tabular data
            * Use <strong> to emphasize inline items like amounts, dates, currency, percentages
            * DO NOT use icons or emoji in headings

          **Important Guidelines:**
          - Maintain professional yet personable tone; keep email structure (greeting, body, closing)
          - Reference specific points discussed in the call
          - Include clear next steps or a call-to-action
          - Keep logical flow from greeting to closing
          - NEVER output Markdown headings (###), backticks, or ``` blocks
        """)

    def __init__(self, template=None):
        # Detect available provider
        anthropic_key = getattr(settings, 'ANTHROPIC_API_KEY', None)
        openai_key = getattr(settings, 'OPENAI_API_KEY', None)

        # Optional overrides from settings
        settings_claude_id = getattr(settings, 'ANTHROPIC_MODEL_ID', None)
        settings_openai_id = getattr(settings, 'OPENAI_MODEL_ID', None)

        # Choose provider: prefer Anthropic if configured; else OpenAI; else error
        provider = None
        model_obj = None
        if anthropic_key:
            provider = 'anthropic'
            model_id = settings_claude_id or self.CLAUDE_MODEL_ID
            model_obj = Claude(id=model_id)
        elif openai_key:
            provider = 'openai'
            model_id = settings_openai_id or self.OPENAI_MODEL_ID
            model_obj = OpenAIChat(id=model_id)
        else:
            raise ValueError("No LLM API key configured. Set ANTHROPIC_API_KEY or OPENAI_API_KEY in environment.")

        template_key = template.key if template else "output"
        self.output_instructions = f"A nice well structured {template_key} in HTML format."

        tools_list = [CalculatorTools()]
        if template and template.key and template.key == ReportTypeChoices.CLOSE_FORECAST_BRIEF:
            tools_list = [CalculatorTools(), generate_deal_forecast_intelligence]

        # Avoid synchronous DB access in async contexts when checking email category
        try:
            if template and template.is_email_category():
                self.set_followup_agent_mode()
        except Exception:
            # In async streaming, accessing related fields can raise SynchronousOnlyOperation.
            # Fallback: skip email mode if category cannot be resolved safely.
            pass

        self.agent = Agent(
            model=model_obj,
            tools=tools_list,
            show_tool_calls=True,
            name=self.AGENT_NAME,
            role=self.AGENT_ROLE,
            description=self.AGENT_SYSTEM_PROMPT,
            instructions=self.AGENT_INSTRUCTIONS,
            expected_output=self.output_instructions,
            add_datetime_to_instructions=True,
            markdown=True,
            debug_mode=True,
            telemetry=False
        )

    def run(self, prompt, stream=False):
        if stream:
            # For streaming, we need to handle the response differently
            # The AGNO library should support streaming responses
            return self.agent.run(prompt, stream=True)
        return self.agent.run(prompt)

    async def arun_stream(self, prompt):
        return await self.agent.arun(prompt, stream=True)


from rest_framework import serializers

from apps.report_management.models import ReportFormation
from apps.sale_rooms.models import Comment


class CommentSerializer(serializers.ModelSerializer):
    author_name = serializers.SerializerMethodField()
    author_initial = serializers.SerializerMethodField()
    author_color = serializers.SerializerMethodField()
    author_avatar = serializers.SerializerMethodField()  # New field
    replies = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = '__all__'
        extra_fields = ('author_name', 'author_initial', 'author_color', 'author_avatar', 'replies')

    def get_author_name(self, obj):
        if obj.created_by_user:
            return obj.created_by_user.get_full_name() or obj.created_by_user.username
        elif obj.created_by_guest:
            return obj.created_by_guest.name
        return "Anonymous"

    def get_author_initial(self, obj):
        name = self.get_author_name(obj)
        return name[0].upper() if name else "?"

    def get_author_color(self, obj):
        # You can make this consistent by hashing the user ID
        colors = ['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-yellow-500']
        if obj.created_by_user:
            return colors[hash(obj.created_by_user.id) % len(colors)]
        elif obj.created_by_guest:
            return colors[hash(obj.created_by_guest.id) % len(colors)]
        return colors[0]

    def get_author_avatar(self, obj):
        if obj.created_by_user and obj.created_by_user.profile_picture:
            return obj.created_by_user.profile_picture.url
        return None

    def get_replies(self, obj):
        replies = obj.replies.all()
        return CommentSerializer(replies, many=True).data
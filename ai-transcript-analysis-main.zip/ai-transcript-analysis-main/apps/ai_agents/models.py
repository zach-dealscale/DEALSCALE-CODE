import uuid
from django.db import models

from django.apps import AppConfig


class ReportManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.report_management'

    def ready(self):
        import apps.report_management.signals

import traceback
from datetime import timedelta

from django.db import models
from django.utils import timezone
from django.template.loader import render_to_string
import os
import logging
logger = logging.getLogger(__name__)

from django.conf import settings
from apps.authentication.models import Client, GuestUser, Company
from apps.report_management.helpers.file_to_text import FileToTextConverter
from apps.report_management.helpers.report_choices import ReportTypeChoices, ReportStatusChoices, PlatformChoices
import striprtf
from django.utils.safestring import mark_safe
import html
from django.utils.safestring import mark_safe
from apps.report_management.helpers.format_json_report import format_markdown, format_html, structured_to_editorjs
from django.contrib.auth import get_user_model
import markdown
from apps.report_management.helpers.pydantic_to_docs import format_pydantic_model_to_text_html, format_for_quill_js  # Import the formatter
from django.conf import settings


User = get_user_model()

def rtf_to_text(rtf_content):
    """Convert RTF content to plain text (basic implementation)."""
    try:

        return striprtf.striprtf(rtf_content)
    except ImportError:
        return "RTF Parsing library not installed"


class Transcript(models.Model):
    title = models.CharField(max_length=200, null=True, blank=True)
    text= models.TextField(null=True, blank=True)
    file = models.FileField(upload_to="transcripts/", null=True, blank=True)
    url = models.URLField(null=True, blank=True)
    zoom_id = models.CharField(max_length=200, null=True, blank=True, unique=True)
    platform = models.CharField(max_length=100, null=True, blank=True, choices=PlatformChoices.choices, default=PlatformChoices.ZOOM)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='transcripts',
        null=True,
        blank=True
    )

    # ✅ NEW: Track who uploaded this transcript
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='uploaded_transcripts'
    )

    def __str__(self):
        return f"Transcript - {self.created_at.strftime('%Y-%m-%d %H:%M')}"

    def save(self, *args, **kwargs):
        """
        Override save method to extract text content from uploaded files
        and auto-generate a title like 'Transcript No. X'.
        """

        # ✅ NEW: Auto-set company from client or user
        if not self.company:
            if self.client and self.client.company:
                self.company = self.client.company
            elif self.user and self.user.company:
                self.company = self.user.company

        # ✅ NEW: Auto-set uploaded_by if not set
        if not self.uploaded_by and self.user:
            self.uploaded_by = self.user

        if not self.title:
            last_transcript = Transcript.objects.order_by('-id').first()
            if last_transcript and last_transcript.title and last_transcript.title.startswith("Transcript No."):
                try:
                    last_number = int(last_transcript.title.split("Transcript No.")[1].strip())
                    self.title = f"Transcript No. {last_number + 1}"
                except:
                    self.title = "Transcript No. 1"
            else:
                self.title = "Transcript No. 1"

        # 🚫 Avoid converting if file is empty OR already set from merged result
        if self.file and hasattr(self.file, "name") and not self.text:
            try:
                file_to_text = FileToTextConverter(self.file)
                self.text = file_to_text.convert()
            except Exception as e:
                self.text = f"Error processing file: {str(e)}"

        super().save(*args, **kwargs)

    def get_all_documents(self):
        """Get all documents across all reports for this transcript"""
        return ReportDocument.objects.filter(report__transcript=self)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Transcript"
        verbose_name_plural = "Transcripts"
        indexes = [
            models.Index(fields=['company', 'created_at'], name='ts_company_created_idx'),
            models.Index(fields=['company', 'uploaded_by'], name='ts_company_uploader_idx'),
        ]


class Category(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True)
    order = models.IntegerField(default=1)
    is_collapsible = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.name

class SubCategory(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name


class ReportTemplateManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_active=True)

class ReportTemplate(models.Model):
    key = models.CharField(max_length=100, unique=True, choices=ReportTypeChoices.choices, blank=True, null=True, help_text="Leave blank for custom report types")
    title = models.CharField(max_length=200)
    description = models.TextField()
    json_schema = models.JSONField(blank=True, null=True)  # For future use, not needed now
    created_at = models.DateTimeField(auto_now_add=True)
    is_pinned = models.BooleanField(default=False)
    last_used = models.DateTimeField(null=True, blank=True)
    usage_count = models.IntegerField(default=0)
    category = models.ForeignKey(SubCategory, on_delete=models.CASCADE, null=True, blank=True)
    framework_prompt = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    order = models.IntegerField(default=1)



    objects = ReportTemplateManager()
    all_objects = models.Manager()  # Use this for accessing all records including inactive
    
    def is_email_category(self):
        EMAIL_CATEGORY_NAME = getattr(settings, 'EMAIL_CATEGORY_NAME', 'Emails')
        sub_category = self.category
        if sub_category:
            category = sub_category.category
            if category:
                return category.name == EMAIL_CATEGORY_NAME
        return False

    def is_custom_report(self):
        """
        Returns True if this is a custom report type (key is null/blank).
        """
        return not self.key
    
    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.title


class ReportFormation(models.Model):
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE, related_name="templates")
    transcript = models.ForeignKey(Transcript, on_delete=models.SET_NULL, related_name="reports", null=True, blank=True)
    additional_transcripts = models.ManyToManyField(Transcript, blank=True, related_name="additional_reports")
    status = models.CharField(max_length=20, choices=ReportStatusChoices.choices, default="pending")
    output_data = models.JSONField(blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True, blank=True)
    user=models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='report_formations',
        null=True,
        blank=True
    )

    # ✅ NEW: Track who created this report formation
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_report_formations'
    )


    def __str__(self):
        return f"{self.template.title} Report - {self.created_at.strftime('%Y-%m-%d %H:%M')}"

    class Meta:
        indexes = [
            models.Index(fields=['company', 'created_at'], name='repform_company_created_idx'),
            models.Index(fields=['company', 'status'], name='repform_company_status_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from transcript, client, or user if not already set."""
        if not self.company:
            if self.transcript and self.transcript.company:
                self.company = self.transcript.company
            elif self.client and self.client.company:
                self.company = self.client.company
            elif self.user and self.user.company:
                self.company = self.user.company
        if not self.created_by and self.user:
            self.created_by = self.user
        super().save(*args, **kwargs)

    def get_transcript(self):
        main_text = self.transcript.text if self.transcript else ""
        additional_texts = []

        for transcript in self.additional_transcripts.all():
            if transcript.text:
                additional_texts.append(f"\n\n--- {transcript.title or 'Additional Transcript'} ---\n{transcript.text}")

        return main_text + "".join(additional_texts)

    def get_template_path(self):
        """Returns the template name that Django can resolve"""
        template_files = {
            # Sales Enablement Reports
            'demo_strategy_brief': 'demo_strategy_brief.html',

            # Financial Impact Reports
            'cost_of_inaction': 'cost_of_inaction.html',
            'business_case': 'business_case.html',

            # Executive Reports
            'executive_summary_wrapper': 'executive_summary.html',
            'medippc_report': 'medippc_report.html',

            # Deal Analysis Reports
            'close_forecast_brief': 'close_forecast_brief.html',
            'pipeline_threat_intelligence_brief': 'pipeline_threat_intelligence_brief.html',

            # Action Plans
            'mutual_action_plan': 'mutual_action_plan.html',
            'internal_team_brief': 'internal_team_brief.html',

            # Buyer Insights
            'buyer_decision_map': 'buyer_decision_map.html',
            'sales_performance_report': 'sales_performance_report.html',

            # Account Growth
            'account_expansion_oppertunity_map': 'account_expansion_oppertunity_map.html',

            # Competitive Intelligence
            'competitive_attack_brief_marketing': 'competitor_attack_brief.html',
            'competitor_win_report': 'competitor_win_report.html',

            # Marketing Reports
            'cold_outreach_angle_report': 'cold_outreach_angle_report.html',
            'marketing_intelligence_brief': 'marketing_intelligence_report.html',

            # Persona Analysis
            'persona_pulse_report': 'persona_pulse_report.html',

            'competitive_messaging_brief': 'competitive_messaging_brief.html',
            
            # General template for any report type
            'general': 'general.html',
        }

        # if self.template.key in template_files:
        if True:
            # template_name = f"report_templates/{template_files[self.template.key]}"
            template_name = f"report_templates/{template_files['general']}"
            logger.info(f"Looking for template: {template_name}")
            return template_name

        logger.warning(f"No template mapping found for report type: {self.template.key}")
        return None

    def get_content(self):
        """
        Converts output_data JSON into a human-readable plain text or HTML format.
        First tries to use a template file if available, falls back to generic formatting.
        """
        if not self.output_data:
            return "No report content available."

        template_path = self.get_template_path()
        if template_path:
            try:
                html_content = render_to_string(template_path, {'data': self.output_data})
                return mark_safe(html_content)
            except Exception as e:
                pass

        html_content = format_pydantic_model_to_text_html(
            self.output_data,
            title=self.template.title
        )
        return mark_safe(html_content)
    
    

    def get_editor_content(self, to_print=False):
        """
        Converts output_data JSON into a format suitable for rich text editors like Quill.js.
        First tries to use a template file if available, falls back to generic formatting.
        """
        if not self.output_data:
            return "No report content available."

        template_path = self.get_template_path()
        if template_path:
            try:
                logger.debug(
                    f"Attempting to render template: {template_path}\n"
                    f"Output data being passed: {self.output_data}\n"
                    f"Data type: {type(self.output_data)}"
                )
                print(f"rendering new content")
                # Data is already HTML from the agent, just mark it safe
                context_data = {
                    'data': mark_safe(self.output_data['data']),
                    'to_print': to_print
                }
                editor_content = render_to_string(
                    template_path, context_data
                )

                logger.debug(
                    f"Successfully rendered template: {template_path}\n"
                    f"Rendered content length: {len(editor_content) if editor_content else 0}"
                )
                return mark_safe(editor_content)

            except Exception as e:
                logger.error(
                    f"Failed to render template: {template_path}\n"
                    f"Error type: {type(e).__name__}\n"
                    f"Error message: {str(e)}\n"
                    f"Output data that caused error: {self.output_data}\n"
                    f"Stack trace: {traceback.format_exc()}"
                )
                raise

        editor_content = format_pydantic_model_to_text_html(
            self.output_data,
            title=self.template.title
        )
        return mark_safe(editor_content)
    

class ReportDocument(models.Model):
    report = models.ForeignKey(
        ReportFormation,
        on_delete=models.CASCADE,
        related_name="documents",
        null=True,
        blank=True
    )
    title = models.CharField(max_length=200)
    sales_room= models.ForeignKey('sale_rooms.SalesRoom', on_delete=models.CASCADE, related_name="sales_room_reports", null=True, blank=True)
    version = models.CharField(max_length=20, default="v1")
    content = models.TextField(blank=True, null=True)  # editable content (richtext editor)
    created_at = models.DateTimeField(default=timezone.now)
    file = models.FileField(upload_to='documents/pdfs/', null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=True, blank=True)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="report_documents",
        null=True,
        blank=True
    )
    is_shareble = models.BooleanField(default=False)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='report_documents',
        null=True,
        blank=True
    )

    # ✅ NEW: Track who created this report document
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_reports'
    )

    def get_editor_content(self):
        """
        Return the document's own content if present;
        otherwise, fallback to the linked report content.
        """
        return self.content or self.report.get_editor_content()

    def save(self, *args, **kwargs):
        """Auto-set company and created_by if not already set."""
        # Auto-set company from report relationship
        if not self.company:
            if hasattr(self, 'report') and self.report:
                if self.report.company:
                    self.company = self.report.company
                elif self.report.transcript and self.report.transcript.company:
                    self.company = self.report.transcript.company

        # Auto-set created_by from user field
        if not self.created_by and self.user:
            self.created_by = self.user

        super().save(*args, **kwargs)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=['company', 'created_by'], name='reportdoc_company_creator_idx'),
            models.Index(fields=['company', 'created_at'], name='reportdoc_company_created_idx'),
        ]

    def __str__(self):
        return f"{self.title} ({self.version})"

    @property
    def file_type(self):
        file_name = self.file.name
        file_extension = file_name.split('.')[-1].lower()
        return file_extension

class DocumentViewLog(models.Model):
    document = models.ForeignKey(ReportDocument, on_delete=models.CASCADE)
    guest_user = models.ForeignKey(GuestUser, on_delete=models.CASCADE)
    views = models.PositiveIntegerField(default=1)
    time_spent = models.CharField(max_length=20, null=True, blank=True)
    last_viewed = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-last_viewed']


class PromptHistory(models.Model):
    """
    Tracks historical versions of ReportTemplate prompts for the playground.
    Used to maintain prompt versioning and allow reverting to previous versions.
    """
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE, related_name='prompt_history')
    prompt_text = models.TextField(help_text="Historical version of the framework prompt")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    version_note = models.CharField(max_length=200, blank=True, null=True, help_text="Optional note about this version")
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Prompt History"
        verbose_name_plural = "Prompt Histories"
    
    def __str__(self):
        return f"{self.template.title} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"


class PromptExperiment(models.Model):
    """
    Temporary storage for prompt experiments in the playground.
    Not committed to production until user confirms.
    """
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE)
    transcript = models.ForeignKey(Transcript, on_delete=models.CASCADE)
    experimental_prompt = models.TextField(help_text="The experimental version of the prompt being tested")
    generated_output = models.TextField(blank=True, null=True, help_text="AI-generated output for this experiment")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_satisfactory = models.BooleanField(default=False, help_text="Whether user is satisfied with this result")
    
    class Meta:
        ordering = ['-updated_at']
        verbose_name = "Prompt Experiment"
        verbose_name_plural = "Prompt Experiments"
    
    def __str__(self):
        return f"Experiment: {self.template.title} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"


class PinnedReportTemplate(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="pinned_templates")
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE, related_name="pinned_by_users")
    pinned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'template')



class TranscriptMedia(models.Model):
    transcript = models.ForeignKey("Transcript", on_delete=models.CASCADE, related_name="transcript_media_files")
    original_file = models.FileField(upload_to="transcripts/originals/")
    original_filename = models.CharField(max_length=255, blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.original_filename and self.original_file:
            self.original_filename = self.original_file.name
        super().save(*args, **kwargs)

    def __str__(self):
        return self.original_filename or self.original_file.name

GENERAL_INSTRUCTIONS = [
    "Validate all fields against pydantic model types and reject invalid data.",
    "Return '[DATA NOT AVAILABLE]' for missing data with an explanation.",
    "Preserve exact field names, structure, and formatting as per the model.",
    "Format dates as YYYY-MM-DD and time estimates with units. Ensure future dates for close dates.",
    "Include currency units and use consistent decimal precision for financials.",
    "Use formal, objective business language with evidence-based claims.",
    "Support claims with data, citing industry benchmarks when applicable.",
    "Flag assumptions and distinguish facts from projections. Indicate confidence levels.",
    "Redact PII and mask sensitive financial details. Never expose internal identifiers.",
    "Use consistent bullet points, status indicators, and prioritize actionable recommendations."
]
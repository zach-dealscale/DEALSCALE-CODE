import json
from django.views.decorators.http import require_POST
from django.http import JsonResponse

import mimetypes
from io import BytesIO
from django.utils.safestring import mark_safe
from django.http import FileResponse
from urllib.parse import unquote
from django.conf import settings
from django.views import View
from collections import defaultdict
import json
from django.contrib import messages
from django.shortcuts import redirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin

from .models import ReportTemplate, ReportFormation, PinnedReportTemplate, TranscriptMedia
from .forms import ReportCreateForm
from django.http import HttpResponse, Http404
from django.contrib.auth.mixins import LoginRequiredMixin
# from weasyprint import HTML
from django.core.files.base import ContentFile
from .models import ReportDocument, Category, SubCategory
import os
from django.contrib.auth.mixins import LoginRequiredMixin
import tempfile
from django.http import HttpResponseRedirect
from django.core.files.base import ContentFile
from django.shortcuts import redirect, get_object_or_404
from django.urls.base import reverse_lazy, reverse
from django.views import View
from django.http import HttpResponse, Http404
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from .models import ReportDocument
from django.views.generic.detail import DetailView
from django.views.generic.edit import DeleteView, UpdateView, FormView
import logging
from django.contrib import messages
from django.views.generic import ListView
from apps.report_management.forms import ReportCreateForm, TranscriptEditForm, TranscriptForm
from apps.report_management.helpers.report_choices import PlatformChoices
from ..authentication.models import Client
from ..core.utils import merge_files, ThumbnailService
from ..core.mixins import RoleBasedClientAccessMixin
from ..sale_rooms.forms import SalesRoomForm
from ..sale_rooms.models import SalesRoomMedia, SalesRoom

logger = logging.getLogger(__name__)
from apps.report_management.models import ReportTemplate
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from apps.report_management.models import Transcript, ReportFormation
from django.views.generic import TemplateView
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET
from django.db.models import Count, Q
from django.shortcuts import render
import html
from django.utils import timezone
from django.utils.text import slugify
from datetime import timedelta
import re
from apps.ai_agents.tasks import generate_report_task, generate_report_task_streaming
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.http import StreamingHttpResponse
import redis
from datetime import datetime
from django.conf import settings
from weasyprint import HTML


class DownloadFile(View):
    def get(self, request, file_name):
        file_name = unquote(file_name)
        file_path = os.path.join(settings.MEDIA_ROOT, file_name)

        if not os.path.exists(file_path):
            return HttpResponse("File not found", status=404)

        # Dynamically guess content type using mimetypes
        content_type, _ = mimetypes.guess_type(file_path)

        if not content_type:
            return HttpResponse("Unsupported file type", status=400)

        response = FileResponse(open(file_path, 'rb'), content_type=content_type)
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'
        return response


class TranscriptDetailView(LoginRequiredMixin, DetailView):
    """
    View for displaying the details of a specific transcript with related report formations and templates.
    """
    model = Transcript
    template_name = 'transcripts/transcript_detail.html'
    context_object_name = 'transcript'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        transcript = self.get_object()
        report_formations = ReportFormation.objects.filter(transcript=transcript)

        context['report_templates'] = ReportTemplate.objects.all()
        context['report_formations'] = report_formations

        return context

class TranscriptEditView(LoginRequiredMixin, UpdateView):
    """
    View for editing the transcript title using a form.
    """
    model = Transcript
    form_class = TranscriptEditForm  # Use the custom form class
    template_name = 'transcripts/edit_transcript.html'

    def get_object(self, queryset=None):
        return get_object_or_404(Transcript, pk=self.kwargs.get('pk'))

    def form_valid(self, form):
        self.object = form.save()
        messages.success(self.request, 'Transcript updated successfully.')
        deal_id = self.object.client.id
        return redirect('deal_detail', pk=deal_id)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['transcript'] = self.get_object()
        return context


class TranscriptsView(LoginRequiredMixin, ListView):
    model = Transcript
    template_name = 'transcripts/transcripts_list.html'
    context_object_name = 'transcripts'
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset().filter(user=self.request.user).order_by('-created_at')

        # Platform filter
        slug_to_platform = {
            "zoom": PlatformChoices.ZOOM,
            "google-meet": PlatformChoices.GOOGLE_MEET,
            "ms-teams": PlatformChoices.MS_TEAMS,
        }
        platform_slug = self.request.GET.get("platform")
        if platform_slug:
            platform_value = slug_to_platform.get(platform_slug.lower())
            if platform_value:
                queryset = queryset.filter(platform=platform_value)

        # Date filter
        date_filter = self.request.GET.get("date")
        now = timezone.now()

        if date_filter == "today":
            queryset = queryset.filter(created_at__date=now.date())
        elif date_filter == "week":
            start_of_week = now - timedelta(days=now.weekday())
            queryset = queryset.filter(created_at__gte=start_of_week)
        elif date_filter == "month":
            start_of_month = now.replace(day=1)
            queryset = queryset.filter(created_at__gte=start_of_month)

        # Search filter
        search_filter = self.request.GET.get("q")
        if search_filter:
            queryset = queryset.filter(title__icontains=search_filter)

        return queryset

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        paginator = Paginator(queryset, self.paginate_by)
        page_number = self.request.GET.get("page")

        try:
            page_obj = paginator.page(page_number)
        except PageNotAnInteger:
            page_obj = paginator.page(1)
        except EmptyPage:
            page_obj = paginator.page(1)  # Fallback to page 1 if out of range

        context = {
            'page_obj': page_obj,
            'transcripts': page_obj.object_list,
            'current_filters': {
                'platform': self.request.GET.get('platform', ''),
                'date': self.request.GET.get('date', ''),
                'q': self.request.GET.get('q', ''),
                'page': page_obj.number,
            }
        }

        return render(request, self.template_name, context)

#
# class ReportsView(LoginRequiredMixin, TemplateView):
#     """
#     View for displaying a list of reports with optional filters for platform and status.
#     Includes pagination.
#     """
#     template_name = 'reports/reports_list.html'
#     paginate_by = 10  # Items per page
#
#     def get_filtered_queryset(self):
#         reports = ReportFormation.objects.filter(user=self.request.user).order_by('-created_at')
#
#         slug_to_platform = {
#             "zoom": PlatformChoices.ZOOM,
#             "google-meet": PlatformChoices.GOOGLE_MEET,
#             "ms-teams": PlatformChoices.MS_TEAMS,
#         }
#
#         platform_slug = self.request.GET.get("platform")
#         if platform_slug:
#             platform = slug_to_platform.get(platform_slug.lower())
#             if platform:
#                 reports = reports.filter(transcript__platform=platform)
#
#         meeting = self.request.GET.get("meeting_id")
#         if meeting:
#             reports = reports.filter(transcript=meeting)
#
#         search_filter = self.request.GET.get("q")
#         if search_filter:
#             reports = reports.filter(template__title__icontains=search_filter)
#
#         return reports
#
#     def get(self, request, *args, **kwargs):
#         reports = self.get_filtered_queryset()
#
#         paginator = Paginator(reports, self.paginate_by)
#         page_number = self.request.GET.get('page')
#
#         try:
#             paginated_reports = paginator.page(page_number)
#         except PageNotAnInteger:
#             paginated_reports = paginator.page(1)
#         except EmptyPage:
#             paginated_reports = paginator.page(1)  # fallback to first page
#
#         context = {
#             'reports': paginated_reports,
#             'page_range': paginator.get_elided_page_range(paginated_reports.number, on_each_side=1, on_ends=1),
#             'transcripts': Transcript.objects.filter(user=self.request.user).order_by("-created_at"),
#             'current_filters': {
#                 'platform': self.request.GET.get('platform', ''),
#                 'meeting_id': self.request.GET.get('meeting_id', ''),
#                 'q': self.request.GET.get('q', ''),
#                 'page': paginated_reports.number,
#             }
#         }
#
#         return render(request, self.template_name, context)
#
# class ReportDetailView(LoginRequiredMixin, DetailView):
#     """
#     View for displaying the details of a specific report.
#     """
#     model = ReportFormation
#     template_name = 'reports/report_detail.html'
#     context_object_name = 'report'
#
#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         documents = ReportDocument.objects.filter(report=self.object)
#         context['documents'] = documents
#         print(self.object.output_data)
#         return context
#

class TranscriptDeleteView(LoginRequiredMixin, DeleteView):
    """
    View for deleting a specific transcript.
    """
    model = Transcript
    template_name = 'transcripts/confirm_delete.html'
    context_object_name = 'transcript'

    def get_success_url(self):
        messages.success(self.request, "Transcript deleted successfully.")
        if hasattr(self.object, 'client') and self.object.client:
            try:
                deal_id = self.object.client.id
                return reverse('deal_detail', kwargs={'pk': deal_id})
            except:
                pass
        return reverse('transcript_list')
#
# class ReportCreateView(LoginRequiredMixin, TemplateView):
#     """
#     View for creating a new report.
#     Handles both GET and POST requests.
#     """
#     template_name = "reports/create_report.html"
#
#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         transcript_id = self.request.GET.get("transcript")
#         selected_transcript = Transcript.objects.filter(id=transcript_id).first()
#
#         selected_transcript_json = None
#         if selected_transcript:
#             selected_transcript_json = {
#                 'id': selected_transcript.id,
#                 'title': selected_transcript.title,
#                 'platform': selected_transcript.platform,
#                 'created_at': selected_transcript.created_at.strftime('%B %d, %Y'),
#                 'client_name': selected_transcript.client.name if selected_transcript.client else '',
#                 'client_logo': selected_transcript.client.company_logo.url if selected_transcript.client and selected_transcript.client.company_logo else None
#             }
#
#         # Group templates by Category -> SubCategory
#         templates_by_category = defaultdict(lambda: defaultdict(list))
#         categories = Category.objects.prefetch_related(
#             'subcategory_set',
#             'subcategory_set__reporttemplate_set'
#         ).all()
#
#         for category in categories:
#             for subcategory in category.subcategory_set.all():
#                 for template in subcategory.reporttemplate_set.all():
#                     templates_by_category[category.name][subcategory.name].append(template)
#
#         first_category = categories[0].name if categories else ''
#         pinned_reports = ReportTemplate.objects.filter(
#             pinned_by_users__user=self.request.user
#         ).distinct()
#
#         recent_reports = ReportTemplate.objects.filter(
#             templates__user=self.request.user
#         ).order_by('-last_used').distinct()[:2]
#         pinned_reports_ids = [t.id for t in pinned_reports]
#         context.update({
#             "selected_transcript": json.dumps(selected_transcript_json),
#             "templates_by_category": dict(templates_by_category),
#             "first_category": first_category,
#             "transcripts": Transcript.objects.filter(user=self.request.user).select_related('client'),
#             "categories": categories,  # Add this line to pass categories to template
#             "pinned_reports": pinned_reports,
#             "recent_reports": recent_reports,
#             "pinned_reports_ids":pinned_reports_ids
#         })
#         return context
#
#     def post(self, request, *args, **kwargs):
#         form = ReportCreateForm(request.POST)
#
#         if form.is_valid():
#             transcript = form.cleaned_data["transcript_id"]
#             templates = form.cleaned_data["templates"]
#             existing_reports = []
#             new_reports = []
#
#             for template in templates:
#                 existing_report = ReportFormation.objects.filter(
#                     template=template,
#                     transcript=transcript,
#                     user=request.user
#                 ).first()
#
#                 if existing_report:
#                     existing_reports.append(existing_report)
#                 else:
#                     report = ReportFormation.objects.create(
#                         template=template,
#                         transcript=transcript,
#                         user=request.user
#                     )
#                     new_document_title = f"{report.template.title} - {report.transcript.title} - {report.transcript.client.name}"
#                     ReportDocument(
#                         report=report,
#                         title=new_document_title,
#                         user=report.user,
#                         version="v1"
#                     )
#                     new_reports.append(report)
#
#             if report:
#                 messages.success(request, "Reports processed successfully.")
#                 return redirect("deal_documents", client_id=report[0].transcript.client.id)
#
#         context = self.get_context_data(form=form)
#         return self.render_to_response(context)


#
# class ReportFormationDeleteView(LoginRequiredMixin, DeleteView):
#     """
#     View for deleting the report
#     """
#     model = ReportFormation
#     template_name = 'reports/report_confirm_delete.html'
#     context_object_name = 'report'
#
#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context['page_title'] = "Delete Report"
#         context['page_subtitle'] = "Are you sure you want to delete this report?"
#         return context
#
#     def get_success_url(self):
#         messages.success(self.request, "Report deleted successfully.")
#         return reverse_lazy('')

#
# class ExportReportPDFView(LoginRequiredMixin, View):
#     """
#     View which handle the export the report in to the form of pdf
#     """
#     def get(self, request, pk):
#         try:
#             report = ReportFormation.objects.get(pk=pk)
#         except ReportFormation.DoesNotExist:
#             raise Http404("Report not found.")
#
#         context = {
#             'content': report.get_content()
#         }
#
#         html = render_to_string("report_pdf_template.html", context)
#         response = HttpResponse(content_type='application/pdf')
#         response['Content-Disposition'] = f'attachment; filename="report_{pk}.pdf"'
#
#         pisa_status = pisa.CreatePDF(html, dest=response)
#
#         if pisa_status.err:
#             return HttpResponse("Error creating PDF", status=500)
#
#         return response
#


class DownloadDocumentPDFView(LoginRequiredMixin, View):
    """
    View to download document as PDF with enhanced styling and structure.
    Maintains original content while adding professional document formatting.
    """

    def get(self, request, pk):
        try:
            document = ReportDocument.objects.get(pk=pk)
        except ReportDocument.DoesNotExist:
            raise Http404("Document not found.")

        # Use the same general template for PDF as we use in the editor
        title = html.escape(getattr(document, 'title', 'Untitled Document'))
        
        # Generate PDF using the same template and styling as the document editor
        from django.template.loader import render_to_string
        from django.utils.safestring import mark_safe
        
        # Render using general.html template with to_print=True for PDF-specific adjustments
        full_html = render_to_string('report_templates/general.html', {
            'data': mark_safe(document.report.output_data['data']),
            'to_print': True
        })

        try:
            pdf_file = HTML(
                string=full_html,
                base_url=request.build_absolute_uri('/')
            ).write_pdf()

            # Create response
            response = HttpResponse(pdf_file, content_type='application/pdf')
            response['Content-Disposition'] = (
                f'attachment; filename="{slugify(title)}_report.pdf"'
            )

            # Save the generated PDF back to the document if needed
            if hasattr(document, 'file'):
                document.file.save(
                    f"{slugify(title)}_report.pdf",
                    ContentFile(pdf_file),
                    save=True
                )

            return response

        except Exception as e:
            logger.error(f"PDF generation failed: {str(e)}")
            return HttpResponse(
                "Failed to generate PDF. Please try again later.",
                status=500
            )


class DocumentDeleteView(LoginRequiredMixin, DeleteView):
    """
    View for deleting a specific document.
    """
    model = ReportDocument
    template_name = 'documents/confirm_delete.html'
    context_object_name = 'document'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Delete Document"
        context['page_subtitle'] = "Are you sure you want to delete this document?"
        return context

    def form_valid(self, form):
        # Save client_id before deletion
        self.client_id = self.object.client_id
        return super().form_valid(form)

    def get_success_url(self):
        messages.success(self.request, "Document deleted successfully.")
        # Redirect to the client's documents page if client exists
        if hasattr(self, 'client_id') and self.client_id:
            return reverse_lazy('deal_documents_list', kwargs={'client_id': self.client_id})
        return reverse_lazy('document_deals_list')

class DocumentEditView(LoginRequiredMixin, View):
    """
    View for editing a document.
    """
    template_name = "documents/documents_edit.html"

    def embed_line_break(self, content):
        content = re.sub(r'(?i)<h2(?:\s[^>]*)?>', r'<hr>\g<0>', content)

        # Optional: Remove any duplicate <hr> tags that might occur
        # This handles cases where <hr> might already exist before <h2>
        content = re.sub(r'<hr>\s*<hr>', '<hr>', content)

        # Optional: Remove <hr> if it's at the very beginning of content
        # content = re.sub(r'^<hr>\s*', '', content)
        print(content)
        return content


    def get(self, request, pk):
        document = get_object_or_404(ReportDocument, pk=pk)
        return render(
            request, 
            self.template_name, 
            {
                "document": document,
                "content": document.report.get_editor_content(to_print=True)
            }
        )

    def post(self, request, pk):
        document = get_object_or_404(ReportDocument, pk=pk)
        content = request.POST.get("content", "").strip()
        if content:
            content_with_line_breaks = self.embed_line_break(content)
            document.content = content_with_line_breaks
            document.save()

        # Redirect back to the same edit page instead of document list
        return redirect('documents_edit', pk=pk)


class DocumentRegenerateView(LoginRequiredMixin, View):
    """
    View to regenerate a failed document.
    """
    def post(self, request, pk):
        try:
            document = get_object_or_404(ReportDocument, pk=pk)
            
            # Reset the report status to pending
            document.report.status = 'pending'
            document.report.save(update_fields=['status'])
            
            # Clear the document content and file
            document.content = ''
            document.file = None
            document.save()
            
            from apps.ai_agents.tasks import generate_report_task
            task = generate_report_task.delay(document.report.id, report_document_id=document.id)
            
            return JsonResponse({
                "status": "success",
                "message": "Document regeneration started",
                "task_id": task.id
            })
            
        except Exception as e:
            return JsonResponse({
                "status": "error",
                "message": str(e)
            }, status=500)


def document_stream_view(request, pk):
    """
    SSE view to stream AI report generation in real-time.
    """
    # Check authentication
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Authentication required"}, status=401)
    
    document = get_object_or_404(ReportDocument, pk=pk)
    
    def event_stream():
        """Generator function for Server-Sent Events"""
        try:
            channel_name = f"report_generation_{document.id}"
            
            # Send initial connection message
            yield f"data: {json.dumps({'type': 'connected', 'message': 'Streaming connection established'})}\n\n"
            
            # Subscribe to Redis channel and stream updates
            redis_client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=0,
                decode_responses=True
            )
            
            pubsub = redis_client.pubsub()
            pubsub.subscribe(channel_name)
            
            try:
                for message in pubsub.listen():
                    if message['type'] == 'message':
                        data = json.loads(message['data'])
                        
                        # Send the data as SSE
                        yield f"data: {json.dumps(data)}\n\n"
                        
                        # If generation is complete or error, close the stream
                        if data.get('type') in ['complete', 'error']:
                            break
                            
            finally:
                pubsub.unsubscribe(channel_name)
                pubsub.close()
                
        except Exception as e:
            # Send error message
            error_data = {
                'type': 'error',
                'message': f'Streaming error: {str(e)}',
                'timestamp': str(datetime.now())
            }
            yield f"data: {json.dumps(error_data)}\n\n"
    
    response = StreamingHttpResponse(event_stream(), content_type="text/event-stream")
    response["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response["Pragma"] = "no-cache"
    response["Expires"] = "0"
    response["X-Accel-Buffering"] = "no"
    response["Access-Control-Allow-Origin"] = "*"
    return response


class DownloadTranscriptPDFView(LoginRequiredMixin, View):
    """
    View for download the transcript in the form of Pdf
    """
    def get(self, request, pk):
        try:
            transcript = Transcript.objects.get(pk=pk)
        except Transcript.DoesNotExist:
            raise Http404("Document not found.")

        context = {
            "title": transcript.title,
            "content": transcript.text
        }

        html = render_to_string("transcripts/transcript_pdf_template.html", context)
        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = f"attachment; filename=transcript_{transcript.title}_{pk}.pdf"

        pisa_status = pisa.CreatePDF(html, dest=response)

        if pisa_status.err:
            return HttpResponse("Error generating PDF", status=500)

        return response


class DocumentsListView(LoginRequiredMixin, RoleBasedClientAccessMixin, ListView):
    model = ReportDocument
    template_name = 'documents/deal_documents_list.html'
    context_object_name = 'documents'
    paginate_by = 10

    def get_queryset(self):
        """
        Filters ReportDocuments for accessible clients based on user's role.
        Uses RoleBasedClientAccessMixin for company-wide access control.
        Shows ALL documents for accessible clients (not just user's own).
        """
        user = self.request.user

        # Get accessible clients based on role (admin sees all, manager sees team's, rep sees own)
        accessible_clients = self.get_accessible_clients(user)

        # Get all documents for accessible clients (regardless of who created them)
        queryset = ReportDocument.objects.filter(
            Q(client__in=accessible_clients) |
            Q(report__transcript__client__in=accessible_clients) |
            Q(report__additional_transcripts__client__in=accessible_clients)
        ).distinct()

        client_id = self.kwargs.get('client_id') or self.request.GET.get("client_id")
        if client_id:
            # Verify user has access to this specific client
            if not accessible_clients.filter(id=client_id).exists():
                # User doesn't have access to this client - return empty queryset
                return ReportDocument.objects.none()

            queryset = queryset.filter(
                Q(client_id=client_id) |
                Q(report__transcript__client_id=client_id) |
                Q(report__additional_transcripts__client_id=client_id)
            )

        search_filter = self.request.GET.get("q")
        if search_filter:
            queryset = queryset.filter(title__icontains=search_filter)

        report_id = self.request.GET.get("report_id")
        if report_id:
            queryset = queryset.filter(report__id=report_id)

        return queryset.order_by('-created_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        # Get accessible clients based on role
        accessible_clients = self.get_accessible_clients(user)

        client_id = self.kwargs.get('client_id') or self.request.GET.get("client_id")

        # Verify selected client is accessible
        selected_client = None
        if client_id:
            selected_client = accessible_clients.filter(id=client_id).first()
            if not selected_client:
                # Client not accessible - this will show empty documents
                messages.error(self.request, "You don't have access to this deal.")

        documents_with_thumbnails = []
        for doc in context['page_obj']:
            if not doc.id:
                continue

            thumbnail_url = None
            if doc.file:
                try:
                    file_ext = os.path.splitext(doc.file.name)[1][1:].lower()
                    thumbnail_url = ThumbnailService.generate_thumbnail(doc.file, file_ext)
                except Exception as e:
                    print(f"Error generating thumbnail for {doc.file.name}: {str(e)}")

            documents_with_thumbnails.append({
                'object': doc,
                'thumbnail_url': thumbnail_url,
                'file_type': os.path.splitext(doc.file.name)[1][1:].lower() if doc.file else None,
            })

        context.update({
            'reports': ReportFormation.objects.filter(user=user),
            'clients': accessible_clients,  # Use role-based accessible clients
            'selected_client': selected_client,
            'documents_with_thumbnails': documents_with_thumbnails,
            'current_filters': {
                'q': self.request.GET.get('q', ''),
                'report_id': self.request.GET.get('report_id', ''),
                'client_id': client_id,
                'page': context['page_obj'].number,
            },
            # Add role-based context
            'user_role': user.role,
            'is_admin': user.role and user.role.can_view_all_data,
        })
        return context


@method_decorator(csrf_exempt, name='dispatch')
class UpdateDocumentShareView(View):
    def post(self, request, document_id):
        try:
            document = ReportDocument.objects.filter(id=document_id).first()
            if not document:
                return JsonResponse({
                    'success': False,
                    'error': 'Document not found'
                }, status=404)

            # Toggle the sharing status
            document.is_shareble = not document.is_shareble
            document.save()

            return JsonResponse({
                'success': True,
                'is_shareble': document.is_shareble,
                'status_text': 'Shared' if document.is_shareble else 'Private'
            })

        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)


class TranscriptCreateView(LoginRequiredMixin, TemplateView):
    template_name = "transcripts/create_transcript.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        client_id = self.request.GET.get("company")
        initial_client = None

        if client_id:
            try:
                client = Client.objects.filter(id=client_id, user=self.request.user).first()
                if client:
                    initial_client = {
                        'id': client.id,
                        'name': client.name,
                        'industry': client.industry or 'No industry specified'
                    }
            except (ValueError, Client.DoesNotExist):
                pass

        form = TranscriptForm(user=self.request.user)
        if self.request.method == 'POST':
            form = TranscriptForm(self.request.POST, self.request.FILES, user=self.request.user)

        context.update({
            "clients": Client.objects.filter(user=self.request.user),
            "initial_client": json.dumps(initial_client) if initial_client else None,
            "form": form
        })
        return context

    def post(self, request, *args, **kwargs):
        form = TranscriptForm(request.POST, request.FILES, user=request.user)

        if form.is_valid():
            uploaded_files = request.FILES.getlist('file')
            text_content = form.cleaned_data.get('text', '')

            transcript = form.save(commit=False)
            transcript.created_at = timezone.now()
            transcript.user = self.request.user

            # Handle text content
            if text_content:
                transcript.text = text_content

            # Save transcript first to get an ID
            transcript.save()

            # Handle file uploads
            if uploaded_files:
                try:
                    # Create media objects for each uploaded file
                    for f in uploaded_files:
                        TranscriptMedia.objects.create(
                            transcript=transcript,
                            original_file=f,
                            original_filename=f.name,
                        )

                    # Merge files and save to transcript
                    merged_file = merge_files(uploaded_files)
                    if merged_file:
                        transcript.file.save(merged_file.name, merged_file, save=False)
                        transcript.save()

                except Exception as e:
                    messages.error(request, f"Error processing files: {e}")
                    context = self.get_context_data(form=form)
                    return self.render_to_response(context)

            messages.success(request, "Transcript created successfully.")
            return HttpResponseRedirect(
                reverse("deal_detail", kwargs={"pk": transcript.client.id}) + f"?transcript={transcript.id}"
            )
        else:
            print("Form errors:", form.errors)
            messages.error(request, "Please correct the errors below.")
            context = self.get_context_data(form=form)
            return self.render_to_response(context)


class MediaGalleryView(LoginRequiredMixin, View):
    def get(self, request, uuid, *args, **kwargs):
        """
        View for the Media Gallery for User room page
        """
        sales_room = get_object_or_404(SalesRoom, uuid=uuid)

        media_files_queryset = SalesRoomMedia.objects.filter(sales_room=sales_room).exclude(file__isnull=True).exclude(
            file='')
        documents_queryset = ReportDocument.objects.filter(
            report__transcript__client=sales_room.client
        ).exclude(file__isnull=True).exclude(file='')

        search_q = request.GET.get("q") or request.GET.get("media_q")
        if search_q:
            media_files_queryset = media_files_queryset.filter(file__icontains=search_q)
            documents_queryset = documents_queryset.filter(file__icontains=search_q)

        all_files = []

        for file in media_files_queryset:
            file_ext = file.file.name.split('.')[-1].lower()
            thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
            all_files.append({
                'id': file.id,
                'name': os.path.basename(file.file.name),
                'file': file.file.url if file.file else None,
                'file_type': file_ext,
                'thumbnail_url': thumbnail_url,
                'uploaded_by_user': file.uploaded_by_user.first_name if file.uploaded_by_user else None,
                'uploaded_by_user_profile_picture': file.uploaded_by_user.profile_picture.url if file.uploaded_by_user and file.uploaded_by_user.profile_picture else None,
                'uploaded_by_guest': file.uploaded_by_guest.name if file.uploaded_by_guest else None,
                'uploaded_at': file.uploaded_at.strftime("%Y-%m-%d %H:%M:%S"),
            })

        for file in documents_queryset:
            file_ext = file.file.name.split('.')[-1].lower()
            thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
            all_files.append({
                'id': file.id,
                'name': file.title,
                'file': file.file.url if file.file else None,
                'file_type': file_ext,
                'thumbnail_url': thumbnail_url,
                'uploaded_at': file.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                'uploaded_by_user': file.user.first_name,
                'uploaded_by_user_profile_picture': file.user.profile_picture.url if file.user and file.user.profile_picture else None,
                'uploaded_by_guest': None
            })

        user_data = {
            "name": request.user.username,
            "email": request.user.email,
            "first_name": request.user.get_full_name(),
            "profile_picture": request.user.profile_picture.url if request.user.profile_picture else None
        }

        print("all_files", all_files)

        context = {
            'all_files': json.dumps(all_files),
            'sales_room_uuid': uuid,
            'sales_room': sales_room,
        }
        return render(request, 'media_and_document/media_gallery.html', context)

@require_POST
def toggle_pin_report(request, template_id):
    template = get_object_or_404(ReportTemplate, id=template_id)
    user = request.user


    pinned_obj = PinnedReportTemplate.objects.filter(user=user, template=template).first()

    if pinned_obj:
        pinned_obj.delete()
        is_pinned = False
    else:
        new_pin = PinnedReportTemplate.objects.create(user=user, template=template)
        is_pinned = True

    return JsonResponse({
        'status': 'success',
        'is_pinned': is_pinned,
        'template_id': template_id
    })


class DocumentDealsList(LoginRequiredMixin, RoleBasedClientAccessMixin, View):
    template_name = 'documents/document_deals.html'


    def get(self, request):
        # Use role-based access control to filter clients
        user = request.user
        accessible_clients = self.get_accessible_clients(user).order_by('-created_at')

        context = {
            'clients': accessible_clients,
            'selected_client': None,
            # Add role-based context
            'user_role': user.role,
            'is_admin': user.role and user.role.can_view_all_data,
            'user_subordinates': user.subordinates.filter(is_active_in_company=True) if user.subordinates.exists() else None,
        }

        return render(request, self.template_name, context)


def get_template_prompt_query(request):
    """API endpoint to get a template's framework prompt via query parameter"""
    try:
        template_id = request.GET.get('template_id')
        
        if not template_id:
            return JsonResponse({
                'success': False,
                'error': 'template_id query parameter is required'
            })
            
        template = get_object_or_404(ReportTemplate, id=template_id)
        return JsonResponse({
            'success': True,
            'framework_prompt': template.framework_prompt or '',
            'title': template.title
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


def report_document_status(request, document_id):
    """
    Check if a report document is ready (has file or content)
    """
    document = get_object_or_404(ReportDocument, id=document_id)

    # Check if document is ready (has either file or content)
    is_ready = bool(document.file or document.content)

    return JsonResponse({
        'ready': is_ready,
        'document_id': document.id,
        'has_file': bool(document.file),
        'has_content': bool(document.content),
        'title': document.title
    })


@login_required
@require_GET
def check_existing_report(request):
    """
    Check if a report already exists for the given transcript and template combination
    Only checks for existing reports when ONLY main transcript is provided (no additional transcripts)
    """
    try:
        main_transcript_id = request.GET.get('main_transcript_id')
        template_id = request.GET.get('template_id')
        additional_transcript_ids = request.GET.getlist('additional_transcript_ids')

        if not main_transcript_id or not template_id:
            return JsonResponse({'error': 'Missing required parameters: main_transcript_id and template_id'},
                                status=400)

        additional_ids = [int(id) for id in additional_transcript_ids if id]

        if not additional_ids:
            existing_report = ReportFormation.objects.filter(
                transcript_id=main_transcript_id,
                template_id=template_id,
                user=request.user
            ).first()

            print(f"Only main transcript provided - checking existing report: {existing_report}")

            return JsonResponse({
                'exists': existing_report is not None,
                'report_id': existing_report.id if existing_report else None,
                'status': existing_report.status if existing_report else None,
                'message': 'Checked existing report (no additional transcripts)'
            })
        else:
            print(f"Additional transcripts provided - skipping existing report check")

            return JsonResponse({
                'exists': False,
                'report_id': None,
                'status': None,
                'message': 'Skipped existing report check (additional transcripts provided)'
            })

    except Exception as e:
        print(f"Error in check_existing_report: {str(e)}")
        return JsonResponse({'error': 'Internal server error'}, status=500)

def regenerate_document(request, document_id):
    """
    Regenerate a document
    """
    if request.method == 'POST':
        document = get_object_or_404(ReportDocument, id=document_id)

        return JsonResponse({
            'status': 'success',
            'message': 'Document regeneration started',
            'document_id': document.id
        })

    return JsonResponse({
        'status': 'error',
        'message': 'Only POST requests allowed'
    }, status=405)

# Import playground views
from .playground_views.views import (
    PromptPlaygroundView,
    PromptGenerateView,
    CreateExperimentView,
    PromptCommitView,
    sse_stream_view,
    PromptHistoryView
)
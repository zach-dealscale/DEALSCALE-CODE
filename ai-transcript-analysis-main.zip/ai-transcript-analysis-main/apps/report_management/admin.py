from django.contrib import admin
from apps.report_management.models import ReportTemplate, ReportFormation, Transcript, ReportDocument, Category, \
    SubCategory, TranscriptMedia, DocumentViewLog


# Register your models here.

@admin.register(ReportTemplate)
class ReportTemplateAdmin(admin.ModelAdmin):
    list_display = ('id', 'order', 'title', 'key', 'report_type_display', 'is_active', 'created_at')
    list_editable = ('order',)
    search_fields = ('key', 'title', 'description')
    list_filter = ('is_active', 'created_at', 'key')
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'order', 'description', 'category')
        }),
        ('Report Type', {
            'fields': ('key',),
            'description': 'Select a predefined report type, or leave blank to create a custom report type.'
        }),
        ('Configuration', {
            'fields': ('framework_prompt', 'json_schema', 'is_pinned', 'is_active'),
            'classes': ('collapse',)
        }),
    )
    
    def report_type_display(self, obj):
        if obj.key:
            return f"Predefined ({obj.get_key_display()})"
        return "Custom Report"
    report_type_display.short_description = 'Type'
    
    def get_queryset(self, request):
        return self.model.all_objects.get_queryset()

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'order', 'name', 'is_collapsible')
    list_editable = ('order',)
    search_fields = ('name',)
    list_filter = ('is_collapsible',)
    ordering = ('order',)

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'order'),
            'description': 'Set the display name and order of this category.'
        }),
        ('Configuration', {
            'fields': ('is_collapsible',),
            'description': 'Toggle whether this category section should be collapsible in the UI.',
            'classes': ('collapse',),
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request)


admin.site.register(ReportFormation)
admin.site.register(Transcript)
admin.site.register(ReportDocument)
admin.site.register(SubCategory)
admin.site.register(TranscriptMedia)
admin.site.register(DocumentViewLog)
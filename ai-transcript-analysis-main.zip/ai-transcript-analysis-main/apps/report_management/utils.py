from django.template.loader import render_to_string
# from weasyprint import HTML
from io import BytesIO
import os
from django.conf import settings
import logging
logger = logging.getLogger(__name__)
from django.core.files.base import ContentFile
from apps.sale_rooms.models import SalesRoom, SalesRoomMedia
from weasyprint import HTML


def link_document_to_salesroom(instance, created=False):
    """
    Signal: Automatically link ReportDocument to the appropriate SalesRoom.
    Handles both single-transcript and many-to-many (additional_transcripts) cases.
    """
    logger.info(f"[Signal] Linking ReportDocument {instance.id} to SalesRoom")

    report = instance.report
    client = None

    if hasattr(report, "transcript") and report.transcript:
        client = report.transcript.client
    elif hasattr(report, "additional_transcripts") and report.additional_transcripts.exists():
        first_transcript = report.additional_transcripts.first()
        client = first_transcript.client if first_transcript else None

    if not client:
        print("Test Report,", report)
        logger.info("Test Report,", report)
        logger.warning(f"[Signal] No client found for ReportDocument {instance.id}")
        return


    # Link to the SalesRoom
    sales_room = SalesRoom.objects.filter(client=client).first()
    if sales_room:
        instance.sales_room = sales_room
        instance.save(update_fields=["sales_room"])

        # Attach to SalesRoomMedia entries that are missing a document
        updated_count = SalesRoomMedia.objects.filter(
            sales_room=sales_room,
            document__isnull=True
        ).update(document=instance)

        logger.info(f"[Signal] Linked to {updated_count} SalesRoomMedia entries for client '{client.name}'")
    else:
        logger.warning(f"[Signal] No SalesRoom found for client {getattr(client, 'name', 'Unknown')}")



def save_pdf_with_fallbacks(doc, pdf_content):
    """Save PDF with versioned filename"""
    try:
        # Use the document's version string directly
        filename = f"documents/pdfs/document_{doc.pk}_version_{doc.version}.pdf"
        logger.info(f"[Verification] Attempting to save PDF as {filename}")

        # Method 1: Direct save
        try:
            # Delete existing file if it exists
            if doc.file:
                old_file = doc.file.name
                old_size = doc.file.size
                doc.file.delete()
                logger.info(f"[Verification] Deleted old file: {old_file} ({old_size} bytes)")

            # Save new file
            doc.file.save(filename, ContentFile(pdf_content), save=True)
            logger.info(f"[Verification] Direct save successful - File: {doc.file.name}, Size: {doc.file.size}")
            return True

        except (PermissionError, OSError) as e:
            logger.warning(f"[Verification] Direct save failed: {str(e)}")
            return False

    except Exception as e:
        logger.error(f"[Verification] Failed to save PDF for document {doc.id}: {str(e)}", exc_info=True)
        return False
    




def generate_and_save_pdf(doc):
    """Robust PDF generation using WeasyPrint"""
    try:
        logger.info(f"[Verification] Starting PDF generation for document {doc.id}")

        context = {"title": doc.title, "content": doc.content}
        logger.debug(
            f"[Verification] PDF context - Title: {context['title']}, Content length: {len(context['content'])}"
        )

        html_content = render_to_string("documents/document_pdf_template.html", context)
        logger.debug(f"[Verification] Rendered HTML length: {len(html_content)} chars")

        pdf_buffer = BytesIO()
        HTML(string=html_content, base_url=settings.BASE_DIR).write_pdf(target=pdf_buffer)
        logger.info(f"[Verification] PDF generated successfully - Size: {pdf_buffer.tell()} bytes")

        pdf_dir = os.path.join(settings.MEDIA_ROOT, 'documents/pdfs')
        os.makedirs(pdf_dir, exist_ok=True)
        logger.debug(f"[Verification] PDF target directory: {pdf_dir}")

        save_pdf_with_fallbacks(doc, pdf_buffer.getvalue())
        logger.info(f"[Verification] PDF saved successfully for document {doc.id}")

        link_document_to_salesroom(doc, created=True)
        logger.info(f"[Verification] Salesroom linking completed for document {doc.id}")

    except Exception as e:
        logger.error(f"[Verification] PDF generation error for document {doc.id}: {str(e)}", exc_info=True)
        raise

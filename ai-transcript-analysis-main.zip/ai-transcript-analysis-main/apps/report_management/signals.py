from io import BytesIO

from django.db.models.signals import post_save
from django.dispatch.dispatcher import receiver

from apps.report_management.models import ReportFormation, ReportDocument
import logging
from apps.report_management.utils import link_document_to_salesroom



logger = logging.getLogger(__name__)

@receiver(post_save, sender=ReportFormation)
def report_formation_post_save(sender, instance, created, **kwargs):
    if created:
        logger.info(f"New ReportFormation instance created: {instance.id}")
        from apps.ai_agents.tasks import generate_report_task
        generate_report_task.delay(instance.id)



@receiver(post_save, sender=ReportDocument)
def report_document_post_save(sender, instance, created, **kwargs):
    if created:
        link_document_to_salesroom(instance, created)
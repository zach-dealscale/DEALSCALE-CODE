from django.urls import path, re_path
from . import views

urlpatterns = [

    # Transcript Related URLs
    path('', views.TranscriptsView.as_view(), name='transcripts_list'),
    path('create', views.TranscriptCreateView.as_view(), name='create-transcript'),
    path('<int:pk>/detail', views.TranscriptDetailView.as_view(), name='transcripts_detail'),
    path("<int:pk>/edit", views.TranscriptEditView.as_view(), name='transcripts_edit'),
    path('<int:pk>/delete', views.TranscriptDeleteView.as_view(), name='transcripts_delete'),
    path('<int:pk>/download', views.DownloadTranscriptPDFView.as_view(), name='transcripts_download'),
    
    
    # Report Related URLs 
    # path('reports', views.ReportsView.as_view(), name='reports_list'),
    # path('reports/create', views.ReportCreateView.as_view(), name='reports_create'),
    # path('reports/<int:pk>', views.ReportDetailView.as_view(), name='reports_detail'),
    # path('reports/<int:pk>/delete', views.ReportFormationDeleteView.as_view(), name='reports_delete'),
    # path('reports/<int:pk>/export-pdf', views.ExportReportPDFView.as_view(), name='reports_export_pdf'),
    path('reports/check-existing/', views.check_existing_report, name='reports_export_pdf'),

    # Document related URLs
    path('documents/<int:pk>/edit', views.DocumentEditView.as_view(), name='documents_edit'),
    path('documents/<int:pk>/stream/', views.document_stream_view, name='documents_stream'),
    path('documents/<int:pk>/delete', views.DocumentDeleteView.as_view(), name='documents_delete'),
    path('documents/<int:pk>/download', views.DownloadDocumentPDFView.as_view(), name='documents_download_pdf'),
    path('documents/<int:pk>/regenerate/', views.DocumentRegenerateView.as_view(), name='documents_regenerate'),
    path('documents/client/<int:client_id>/', views.DocumentsListView.as_view(), name='deal_documents'),
    path('documents/update_document_share/<int:document_id>/', views.UpdateDocumentShareView.as_view(), name='update_document_share'),
    path('documents/deals/', views.DocumentDealsList.as_view(), name='document_deals_list'),
    path('documents/deals/<int:client_id>/', views.DocumentsListView.as_view(), name='deal_documents_list'),

    # File handling URLs
    re_path(r'^download-file/(?P<file_name>.+)/$', views.DownloadFile.as_view(), name='download_file'),


    #pin reports template
    path('reports/toggle-pin/<int:template_id>/', views.toggle_pin_report, name='toggle_pin_report'),

    # Playground URLs
    path('playground/', views.PromptPlaygroundView.as_view(), name='playground'),
    path('playground/generate/', views.PromptGenerateView.as_view(), name='playground_generate'),
    path('playground/create-experiment/', views.CreateExperimentView.as_view(), name='playground_create_experiment'),
    path('playground/stream/', views.sse_stream_view, name='playground_stream'),
    path('playground/commit/', views.PromptCommitView.as_view(), name='playground_commit'),
    path('playground/history/<int:template_id>/', views.PromptHistoryView.as_view(), name='playground_history'),
    
    # API endpoints
    path('api/get-template-prompt/', views.get_template_prompt_query, name='get_template_prompt_query'),
    path('reports/status/<int:document_id>/', views.report_document_status, name='report_document_status'),

]
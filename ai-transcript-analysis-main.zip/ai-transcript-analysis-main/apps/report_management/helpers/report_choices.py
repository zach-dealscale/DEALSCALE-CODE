from django.db import models
from apps.report_management.pydantic_models import (

    DealAnalysisWrapper,
    AiSalesPerformanceReportWrapper,
    MutualActionPlanReport,
    SummaryCLevelStakeholdersWrapper,
    CostOfInactionReport,
    SalesEngineeringDemoBriefWrapper,
    ExecutiveSummaryReport,
    ObjectionTrackerWrapper,
    DealScorecardWrapper, MEDDPICCReport,
    SalesPerformanceCoachReport,
    CompetitiveMessagingBrief,
    PersonaMessagingBrief
)
from apps.report_management.pydantic_models.account_expansion_oppertunity_map import AccountExpansionOpportunityMap
from apps.report_management.pydantic_models.bussiness_case import BusinessCaseReport
from apps.report_management.pydantic_models.buyer_decision_map import BuyerDecisionMap
from apps.report_management.pydantic_models.close_forecast_brief import CloseForecastBrief
from apps.report_management.pydantic_models.cold_outreach_angle_report import ColdOutreachAngleReport
from apps.report_management.pydantic_models.competitive_attack_brief_marketing import CompetitiveAttackBrief
from apps.report_management.pydantic_models.competitor_win_report import CompetitorWinIntelligence
from apps.report_management.pydantic_models.demo_strategy_brief import DemoStrategyBrief
from apps.report_management.pydantic_models.internal_team_breif import InternalDealTeamBrief
from apps.report_management.pydantic_models.marketing_intelligence_brief import MarketingIntelligenceBrief
from apps.report_management.pydantic_models.medippc_report import MEDDPICCReport
from apps.report_management.pydantic_models.perosne_pulse_report import PersonaPulseReport
from apps.report_management.pydantic_models.pipeline_threat_intelligence_brief import PipelineThreatBrief
from apps.report_management.pydantic_models.sales_performance_report import SalesPerformanceCoachReport


class ReportStatusChoices(models.TextChoices):
    PENDING = "pending", "Pending"
    PROCESSING = "processing", "Processing"
    COMPLETED = "completed", "Completed"
    FAILED = "failed", "Failed"

class ReportTypeChoices(models.TextChoices):
    """
    Choices for the type of report to generate.
    """
    SALES_ENGINEERING_DEMO_BRIEF = "sales_engineering_demo_brief", "Sales Engineering Demo Brief"
    COST_OF_INACTION = "cost_of_inaction", "Cost of Inaction"
    EXECUTIVE_SUMMARY_WRAPPER = "executive_summary_wrapper", "Executive Summary Wrapper"
    MEDIPPC_REPORT = "medippc_report", "MedIPPC Report",
    CLOSE_DATE_PREDICTOR_ANALYSIS = "close_date_predictor_analysis", "Close Date Predictor Analysis"
    AI_SALES_COACH = "ai_sales_coach", "AI Sales Coach",
    MUTUAL_ACTION_PLAN = "mutual_action_plan", "Mutual Action Plan"
    SUMMARY_FOR_C_LEVEL_STAKHOLDERS = "summary_for_c_level_stakeholders", "Summary for C-Level Stakeholders"
    TOP_OBJECTION_TRACKER = "top_objection_tracker", "Top Objection Tracker"
    WIN_PROBABILITY_SCORING = "win_probability_scoring", "Win Probability Scoring"
    BUSINESS_CASE = "business_case", "Business Case"
    COLD_OUTREACH_ANGLE_REPORT = "cold_outreach_angle_report", "Cold Out Reach Angle Report"
    INTERNAL_TEAM_BRIEF="internal_team_brief", "Internal Team Brief"
    BUYER_DECISION_MAP = "buyer_decision_map", "Buyer Decision Map"
    ACCOUNT_EXPANSION_OPPERTUNITY_MAP = "account_expansion_oppertunity_map", "Account Expansion Oppertunity Map"
    DEMO_STRATEGY_BRIEF = "demo_strategy_brief","Demo Strategy Brief",
    PIPELINE_THREAT_INTELLIGENCE_BRIEF= "pipeline_threat_intelligence_brief", "Pipeline Threat Intelligence Brief",
    COMPETITIVE_ATTACK_BRIEF_MARKETING= "competitive_attack_brief_marketing", "Competitive Attack Brief Marketing",
    CLOSE_FORECAST_BRIEF = "close_forecast_brief", "Close Forecast Brief",
    COMPETITOR_WIN_REPORT = "competitor_win_report", "Competitor Win Report",
    MARKETING_INTELLIGENCE_BRIEF = "marketing_intelligence_brief", "Marketing Intelligence Brief"
    PERSONA_PULSE_REPORT = "persona_pulse_report","Persona Pulse Report",
    SALES_PERFORMANCE_REPORT = "sales_performance_report", "Sales Performance Report",
    COMPETITIVE_MESSAGING_BRIEF = "competitive_messaging_brief", "Competitive Messaging Brief"
    PERSONA_MESSAGING_BRIEF = "persona_messaging_brief", "Persona Messaging Brief"

    @classmethod
    def get_pydantic_model(cls, key):
        mapping = {
            cls.SALES_ENGINEERING_DEMO_BRIEF: SalesEngineeringDemoBriefWrapper,
            cls.COST_OF_INACTION: CostOfInactionReport,
            cls.EXECUTIVE_SUMMARY_WRAPPER: ExecutiveSummaryReport,
            cls.MEDIPPC_REPORT: MEDDPICCReport,
            cls.CLOSE_DATE_PREDICTOR_ANALYSIS: DealAnalysisWrapper,
            cls.AI_SALES_COACH: AiSalesPerformanceReportWrapper,
            cls.MUTUAL_ACTION_PLAN:MutualActionPlanReport,
            cls.SUMMARY_FOR_C_LEVEL_STAKHOLDERS:SummaryCLevelStakeholdersWrapper,
            cls.TOP_OBJECTION_TRACKER: ObjectionTrackerWrapper,
            cls.WIN_PROBABILITY_SCORING: DealScorecardWrapper,
            cls.BUSINESS_CASE:BusinessCaseReport,
            cls.COLD_OUTREACH_ANGLE_REPORT: ColdOutreachAngleReport,
            cls.INTERNAL_TEAM_BRIEF : InternalDealTeamBrief,
            cls.BUYER_DECISION_MAP:BuyerDecisionMap,
            cls.ACCOUNT_EXPANSION_OPPERTUNITY_MAP : AccountExpansionOpportunityMap,
            cls.DEMO_STRATEGY_BRIEF: DemoStrategyBrief,
            cls.PIPELINE_THREAT_INTELLIGENCE_BRIEF: PipelineThreatBrief,
            cls.COMPETITIVE_ATTACK_BRIEF_MARKETING: CompetitiveAttackBrief,
            cls.CLOSE_FORECAST_BRIEF :CloseForecastBrief,
            cls.COMPETITOR_WIN_REPORT:CompetitorWinIntelligence,
            cls.MARKETING_INTELLIGENCE_BRIEF:MarketingIntelligenceBrief,
            cls.PERSONA_PULSE_REPORT: PersonaPulseReport,
            cls.SALES_PERFORMANCE_REPORT : SalesPerformanceCoachReport,
            cls.COMPETITIVE_MESSAGING_BRIEF: CompetitiveMessagingBrief,
            cls.PERSONA_MESSAGING_BRIEF: PersonaMessagingBrief
        }
        return mapping.get(key)
    
    @staticmethod
    def get_expected_output(response_model):
        expected_output_instructions = []

        for name, field in response_model.model_fields.items():  # For Pydantic v2
            field_info = field
            name = name.replace("_", " ").capitalize()
            required = "Required" if field_info.is_required() else f"Optional (Default: {field_info.default})"
            description = field_info.description or "No description provided."
            expected_output_instructions.append(f"- **{name}** ({required}): {description}")

        return "\n".join(expected_output_instructions)


class PlatformChoices(models.TextChoices):
    ZOOM = "Zoom", "Zoom"
    GOOGLE_MEET = "Google Meet", "Google Meet"
    MS_TEAMS = "Microsoft Teams", "Microsoft Teams"



class Stage(models.TextChoices):
    """
    Centralized Stage definitions for Deal/Client pipeline.
    This is the single source of truth for all stage-related information.

    Use Stage.get_all_stages() to get complete metadata for frontend use.
    """
    DISCOVERY = 'discovery', 'Discovery'
    EVALUATION = 'evaluation', 'Evaluation'
    VALIDATION = 'validation', 'Validation'
    PROCUREMENT = 'procurement', 'Procurement'
    CLOSED_WON = 'closed_won', 'Closed Won'
    CLOSED_LOST = 'closed_lost', 'Closed Lost'

    @classmethod
    def get_all_stages(cls):
        """
        Returns all stages with complete metadata for frontend use.

        Returns:
            list: List of dicts with keys: value, label, subtitle, badge_class, dot_class
        """
        stages_metadata = {
            'discovery': {
                'label': 'Discovery',
                'subtitle': 'Identify pain points, goals, and fit. Build early champion interest.',
                'badge_class': 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300',
                'dot_class': 'bg-blue-600',
            },
            'evaluation': {
                'label': 'Evaluation',
                'subtitle': 'Show solution value through demos and ROI. Confirm success criteria.',
                'badge_class': 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300',
                'dot_class': 'bg-purple-600',
            },
            'validation': {
                'label': 'Validation',
                'subtitle': 'Prove technical, security, and stakeholder alignment.',
                'badge_class': 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300',
                'dot_class': 'bg-yellow-600',
            },
            'procurement': {
                'label': 'Procurement',
                'subtitle': 'Finalize pricing, legal, and contract terms.',
                'badge_class': 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300',
                'dot_class': 'bg-orange-600',
            },
            'closed_won': {
                'label': 'Closed Won',
                'subtitle': 'Deal signed. Move to onboarding.',
                'badge_class': 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300',
                'dot_class': 'bg-green-600',
            },
            'closed_lost': {
                'label': 'Closed Lost',
                'subtitle': 'Opportunity ended. Capture reason for loss.',
                'badge_class': 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200',
                'dot_class': 'bg-gray-600',
            },
        }

        return [
            {
                'value': stage_value,
                'label': stages_metadata[stage_value]['label'],
                'subtitle': stages_metadata[stage_value]['subtitle'],
                'badge_class': stages_metadata[stage_value]['badge_class'],
                'dot_class': stages_metadata[stage_value]['dot_class'],
            }
            for stage_value in cls.values
        ]

    @classmethod
    def get_stage_metadata(cls, stage_value):
        """
        Get metadata for a specific stage.

        Args:
            stage_value: The stage value (e.g., 'discovery', 'evaluation')

        Returns:
            dict: Stage metadata with label, subtitle, badge_class, dot_class
        """
        stages_metadata = {
            'discovery': {
                'label': 'Discovery',
                'subtitle': 'Identify pain points, goals, and fit. Build early champion interest.',
                'badge_class': 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300',
                'dot_class': 'bg-blue-600',
            },
            'evaluation': {
                'label': 'Evaluation',
                'subtitle': 'Show solution value through demos and ROI. Confirm success criteria.',
                'badge_class': 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300',
                'dot_class': 'bg-purple-600',
            },
            'validation': {
                'label': 'Validation',
                'subtitle': 'Prove technical, security, and stakeholder alignment.',
                'badge_class': 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300',
                'dot_class': 'bg-yellow-600',
            },
            'procurement': {
                'label': 'Procurement',
                'subtitle': 'Finalize pricing, legal, and contract terms.',
                'badge_class': 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300',
                'dot_class': 'bg-orange-600',
            },
            'closed_won': {
                'label': 'Closed Won',
                'subtitle': 'Deal signed. Move to onboarding.',
                'badge_class': 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300',
                'dot_class': 'bg-green-600',
            },
            'closed_lost': {
                'label': 'Closed Lost',
                'subtitle': 'Opportunity ended. Capture reason for loss.',
                'badge_class': 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200',
                'dot_class': 'bg-gray-600',
            },
        }
        return stages_metadata.get(stage_value, {})

    @classmethod
    def get_stage_label(cls, stage_value):
        """Get the display label for a stage."""
        metadata = cls.get_stage_metadata(stage_value)
        return metadata.get('label', stage_value)

    @classmethod
    def get_stage_subtitle(cls, stage_value):
        """Get the subtitle for a stage."""
        metadata = cls.get_stage_metadata(stage_value)
        return metadata.get('subtitle', '')

    @classmethod
    def get_badge_class(cls, stage_value):
        """Get the badge CSS class for a stage."""
        metadata = cls.get_stage_metadata(stage_value)
        return metadata.get('badge_class', 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200')

    @classmethod
    def get_dot_class(cls, stage_value):
        """Get the dot CSS class for a stage."""
        metadata = cls.get_stage_metadata(stage_value)
        return metadata.get('dot_class', 'bg-gray-600')
import os
import re

from docx import Document
import PyPDF2


class FileToTextConverter:
    """
    Convert uploaded files to plain text.
    """
    def __init__(self, file):
        self.file = file

    def get_file_extension(self):
        """
        Get the file extension of the uploaded file.
        """
        return os.path.splitext(self.file.name)[1].lower()

    def from_txt_file(self):
        """
        Extract text content from TXT
        """
        self.file.seek(0)

        # Try different encodings to handle potential encoding issues
        encodings = ["utf-8", "latin-1", "windows-1252"]
        for encoding in encodings:
            try:
                return self.file.read().decode(encoding)
            except UnicodeDecodeError:
                continue  # Try the next encoding if a UnicodeDecodeError occurs

    def from_docx_file(self):
        """
        Extract text content from DOCX
        """
        self.file.seek(0)
        doc = Document(self.file)
        return '\n'.join([para.text for para in doc.paragraphs if para.text])

    def from_vtt_file(self):
        """
        Extract readable text from VTT file, skipping timestamps, digits, and 'WEBVTT'.
        """
        self.file.seek(0)
        content = self.file.read().decode('utf-8')

        lines = content.splitlines()
        text_lines = []

        for line in lines:
            line = line.strip()
            if not line:
                continue  # Skip empty lines
            if line.upper() == "WEBVTT":
                continue  # Skip WEBVTT header
            if re.match(r'^\d{2}:\d{2}:\d{2}\.\d{3}', line):
                continue
            if line.isdigit():
                continue  # Skip sequence numbers
            text_lines.append(line)

        return '\n'.join(text_lines)

    def from_pdf_file(self):
        """
        Extract text content from PDF
        """
        self.file.seek(0)
        reader = PyPDF2.PdfReader(self.file)
        extracted_text = [page.extract_text() for page in reader.pages if page.extract_text()]
        return '\n'.join(extracted_text) if extracted_text else "No extractable text"

    def rtf_to_text(rtf_content):
        """Convert RTF content to plain text (basic implementation)."""
        try:
            import striprtf
            return striprtf.striprtf(rtf_content)
        except ImportError:
            return "RTF Parsing library not installed"
    def from_rtf_file(self):
        """
        Convert RTF content to plain text.
        """
        self.file.seek(0)
        rtf_text = self.file.read().decode("utf-8")
        return self.rtf_to_text(rtf_text)

    def convert(self):
        """
        Convert the file content to plain text.
        """
        file_extension = self.get_file_extension()
        if file_extension == '.txt':
            return self.from_txt_file()
        elif file_extension == '.docx':
            return self.from_docx_file()
        elif file_extension == '.pdf':
            return self.from_pdf_file()
        elif file_extension == '.rtf':
            return self.from_rtf_file()
        elif file_extension == '.vtt':
            return self.from_vtt_file()
        else:
            return "Unsupported file format"

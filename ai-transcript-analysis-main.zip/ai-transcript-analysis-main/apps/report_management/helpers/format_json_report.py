import re, time
import html

def snake_to_title(text):
    return re.sub(r'_', ' ', text).title()

def format_markdown(data, level=1):
    markdown = ""
    
    if isinstance(data, dict):
        for key, value in data.items():
            title = snake_to_title(str(key))
            if level == 1:
                markdown += f"\n\n## 📝 {title}\n"
            elif level == 2:
                markdown += f"\n\n### 🎯 {title}\n"
            elif level == 3:
                markdown += f"\n\n#### {title}\n"
            else:
                markdown += f"\n\n**{title}**\n"

            markdown += format_markdown(value, level + 1)

    elif isinstance(data, list):
        if all(isinstance(i, dict) for i in data):
            # If list of dicts, display as table
            keys = list(data[0].keys())
            markdown += "\n" + "\t".join(snake_to_title(k) for k in keys) + "\n"
            markdown += "\t".join(["---"] * len(keys)) + "\n"
            for item in data:
                row = "\t".join(str(item.get(k, "")) for k in keys)
                markdown += row + "\n"
        else:
            # Bullet points
            for item in data:
                markdown += f"- {item}\n"

    else:
        # Normal value
        markdown += f"{data}\n"

    return markdown.strip()

def is_flat_kv_dict(d):
    return isinstance(d, dict) and all(isinstance(v, (str, int, float)) for v in d.values())

def format_html(data, level=1):
    html_output = ""

    heading_tag = {1: "h1", 2: "h2", 3: "h3", 4: "h4"}.get(level, "h5")
    indent_class = f"indent-level-{level}" if level > 2 else ""

    if isinstance(data, dict):
        if is_flat_kv_dict(data):

            ordered_list = f'<ol class="section-block {indent_class}">\n'
            for key, value in data.items():
                title = snake_to_title(str(key))
                single_item = f'<li><strong>{html.escape(str(title))}:</strong> {html.escape(str(value))}</li>\n'
                ordered_list += single_item
            ordered_list += '</ol>\n'
            html_output += ordered_list
        else:
            for key, value in data.items():
                title = snake_to_title(str(key))
                html_output += f'<div class="section-block {indent_class}">\n'
                html_output += f'<{heading_tag}>{title}</{heading_tag}>\n'
                if heading_tag == "h1":                        
                    html_output += '<hr>\n'
                
                html_output += format_html(value, level + 1)
                html_output += '</div>\n'

    elif isinstance(data, list):
        if len(data) == 0:
            html_output += f'<p class="{indent_class}"><em>No data available.</em></p>\n'
        elif all(isinstance(item, dict) for item in data):
            html_output += f'<div class="section-block {indent_class}">\n'
            keys = list(data[0].keys())
            html_output += '<table border="1" cellspacing="0" cellpadding="6">\n<thead><tr>'
            for key in keys:
                html_output += f'<th>{snake_to_title(key)}</th>'
            html_output += '</tr></thead><tbody>\n'
            for row in data:
                html_output += '<tr>'
                for key in keys:
                    html_output += f'<td>{html.escape(str(row.get(key, "")))}</td>'
                html_output += '</tr>\n'
            html_output += '</tbody></table>\n</div>\n'
        else:
            html_output += f'<ul class="section-block {indent_class}">\n'
            for item in data:
                html_output += f'<li>{html.escape(str(item))}</li>\n'
            html_output += '</ul>\n'

    else:
        html_output += f'<p class="{indent_class}">{html.escape(str(data))}</p>\n'

    return html_output.strip()


def structured_to_editorjs(data, level=2):
    blocks = []

    def add_header(text, lvl):
        blocks.append({
            "type": "header",
            "data": {"text": text, "level": lvl}
        })

    def add_paragraph(text):
        blocks.append({
            "type": "paragraph",
            "data": {"text": text}
        })

    def add_list(items):
        blocks.append({
            "type": "list",
            "data": {"style": "unordered", "items": items}
        })

    def walk(d, lvl):
        if isinstance(d, dict):
            for key, value in d.items():
                add_header(snake_to_title(key), lvl)
                walk(value, lvl + 1)
        elif isinstance(d, list):
            if all(isinstance(i, str) for i in d):
                add_list(d)
            elif all(isinstance(i, dict) for i in d):
                for item in d:
                    paragraph = " | ".join(f"<strong>{k}:</strong> {v}" for k, v in item.items())
                    add_paragraph(paragraph)
        else:
            add_paragraph(str(d))

    walk(data, level)

    return {
        "time": int(time.time() * 1000),
        "blocks": blocks,
        "version": "2.27.0"
    }
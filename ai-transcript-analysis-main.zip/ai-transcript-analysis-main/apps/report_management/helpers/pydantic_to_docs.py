import html
import re
from typing import Any, Dict, List, Union
from datetime import datetime, date
from decimal import Decimal

class TextBasedHTMLFormatter:
    """
    A text-based HTML formatter for Pydantic models that generates clean, semantic HTML
    suitable for Quill.js and external CSS styling. No inline styles, CSS classes, or tables.
    """
    
    def __init__(self, max_depth=8):
        """
        Initialize the formatter with configuration options.
        
        Args:
            max_depth: Maximum nesting depth to prevent infinite recursion
        """
        self.max_depth = max_depth
        self.current_depth = 0
        
    def format_to_html(self, data: Any, title: str = None) -> str:
        """
        Main entry point to format data to clean HTML.
        
        Args:
            data: The data structure to format
            title: Optional title for the document
            
        Returns:
            Clean HTML string without styling or classes
        """
        self.current_depth = 0
        
        html_content = self._format_recursive(data, level=1, is_root=True)
        
        # Wrap in a simple container with title if provided
        # if title:
        #     html_content = f'<h1>{html.escape(title)}</h1>\n<hr>\n{html_content}'
            
        return html_content
    
    def _format_recursive(self, data: Any, level: int = 1, key: str = None, is_root: bool = False) -> str:
        """
        Recursively format data structure to clean HTML.
        """
        if self.current_depth > self.max_depth:
            return '<p><em>Maximum nesting depth reached</em></p>'
        
        self.current_depth += 1
        
        try:
            if data is None:
                result = self._format_none()
            elif isinstance(data, dict):
                result = self._format_dict(data, level, key, is_root)
            elif isinstance(data, list):
                result = self._format_list(data, level, key)
            elif isinstance(data, (str, int, float, bool, Decimal)):
                result = self._format_primitive(data, level, key)
            elif isinstance(data, (datetime, date)):
                result = self._format_datetime(data, level, key)
            else:
                # Handle any other object by converting to string
                result = self._format_primitive(str(data), level, key)
        finally:
            self.current_depth -= 1
            
        return result
    
    def _format_dict(self, data: Dict, level: int, key: str = None, is_root: bool = False) -> str:
        """Format dictionary data with proper heading hierarchy."""
        if not data:
            return '<p><em>No data available</em></p>'

        print(level)
        # Check if this is a flat key-value dictionary (should be rendered as definition list)
        if self._is_flat_dict(data):
            # If we have a key (this dict is nested), create a heading for the section
            if key and not is_root:
                section_title = self._format_key(key)
                heading_level = min(level, 6)
                
                html_parts = []
               
                html_parts.append(f'<h{heading_level}>{section_title}</h{heading_level}>')
                html_parts.append(self._format_flat_dict(data))
              
                return '\n'.join(html_parts)
            else:
                # Root level flat dict, no heading needed
                return self._format_flat_dict(data)
        
        # Regular nested dictionary formatting with proper headings
        html_parts = []
        
        for dict_key, value in data.items():
            section_title = self._format_key(dict_key)
            
            # Determine heading level (h1-h6)
            heading_level = min(level, 6)

            
            # Check if the value is a flat dict - if so, don't create redundant heading
            if isinstance(value, dict) and self._is_flat_dict(value):
                # Create heading and format flat dict content directly
                html_parts.append(f'<h{heading_level}>{section_title}</h{heading_level}>')
                html_parts.append(self._format_flat_dict(value))
            else:
                # Add section header for non-flat content
                html_parts.append(f'<h{heading_level}>{section_title}</h{heading_level}>')
                
                # Format the value
                content = self._format_recursive(value, level + 1, dict_key)
                html_parts.append(content)
            
            # Add spacing between sections at same level
            if level <= 3:
                html_parts.append('')  # Empty line for spacing
        
        return '\n'.join(html_parts)
    
    def _format_list(self, data: List, level: int, key: str = None) -> str:
        """Format list data as structured lists."""
        if not data:
            return '<p><em>No items available</em></p>'
        
        # Check if it's a simple list of primitives
        if all(isinstance(item, (str, int, float, bool)) for item in data):
            return self._format_simple_list(data)
        
        # Check if all items are dictionaries - format as definition lists
        if all(isinstance(item, dict) for item in data):
            return self._format_dict_list(data, level)
        
        # Complex list with mixed or nested items
        return self._format_complex_list(data, level)
    
    def _format_flat_dict(self, data: Dict) -> str:
        """Format a flat dictionary as structured paragraphs."""
        html_parts = []
        
        for key, value in data.items():
            formatted_key = self._format_key(key)
            formatted_value = self._format_value(value)
            
            # Use paragraphs with strong emphasis for keys
            # if len(formatted_value) >= 50:
            #     # If value is long, use a definition list style
            #     html_parts.append(f'<p><strong>{formatted_key}</strong></p>')
            #     html_parts.append(f'<p>{formatted_value}</p>')
            # else:
            html_parts.append(f'<p><strong>{formatted_key}:</strong> {formatted_value}</p>')
        
        return '\n'.join(html_parts)

    def _format_dict_list(self, data: List[Dict], level: int) -> str:
        """Format list of dictionaries as a table if all dicts are flat, else as ordered sections."""
        if all(self._is_flat_dict(item) for item in data):
            # Get all unique keys across all dicts to build the table header
            all_keys = set()
            for item in data:
                all_keys.update(item.keys())
            sorted_keys = list(data[0].keys())
            
            html_parts = ['<table border="1" cellspacing="0" cellpadding="4">']
            html_parts.append('<thead><tr>')
            for key in sorted_keys:
                html_parts.append(f'<th>{self._format_key(key)}</th>')
            html_parts.append('</tr></thead><tbody>')

            for item in data:
                html_parts.append('<tr>')
                for key in sorted_keys:
                    value = item.get(key, None)
                    html_parts.append(f'<td>{self._format_value(value)}</td>')
                html_parts.append('</tr>')

            html_parts.append('</tbody></table>')
            return '\n'.join(html_parts)

        # Fallback to original ol/li rendering if dicts are nested
        html_parts = ['<ol>']
        for item in data:
            html_parts.append('<li>')
            content = self._format_recursive(item, level + 1)
            html_parts.append(content)
            html_parts.append('</li>')
        html_parts.append('</ol>')
        return '\n'.join(html_parts)

    def _format_simple_list(self, data: List) -> str:
        """Format simple list of primitives as unordered list."""
        html_parts = ['<ul>']
        
        for item in data:
            formatted_item = self._format_value(item)
            html_parts.append(f'<li>{formatted_item}</li>')
        
        html_parts.append('</ul>')
        return '\n'.join(html_parts)
    
    def _format_complex_list(self, data: List, level: int) -> str:
        """Format complex list with nested items using ordered list."""
        html_parts = ['<ol>']
        
        for item in data:
            html_parts.append('<li>')
            content = self._format_recursive(item, level + 1)
            html_parts.append(content)
            html_parts.append('</li>')
        
        html_parts.append('</ol>')
        return '\n'.join(html_parts)
    
    def _format_primitive(self, data: Any, level: int, key: str = None) -> str:
        """Format primitive values as clean text."""
        if key:
            formatted_key = self._format_key(key)
            formatted_value = self._format_value(data)
            return f'<p>{formatted_value}</p>'
        else:
            return f'<p>{self._format_value(data)}</p>'
    
    def _format_datetime(self, data: Union[datetime, date], level: int, key: str = None) -> str:
        """Format datetime/date objects."""
        if isinstance(data, datetime):
            formatted_date = data.strftime("%B %d, %Y at %I:%M %p")
        else:
            formatted_date = data.strftime("%B %d, %Y")
        
        return self._format_primitive(formatted_date, level, key)
    
    def _format_none(self) -> str:
        """Format None values."""
        return '<p><em>Not specified</em></p>'
    
    def _format_key(self, key: str) -> str:
        """Format dictionary keys to human-readable format."""
        # Convert snake_case to Title Case
        formatted = re.sub(r'_', ' ', str(key))
        formatted = re.sub(r'([a-z])([A-Z])', r'\1 \2', formatted)  # Handle camelCase
        return formatted.title()
    
    def _format_value(self, value: Any) -> str:
        """Format individual values with proper escaping."""
        if value is None:
            return '<em>Not specified</em>'
        elif isinstance(value, bool):
            return f'<strong>{str(value)}</strong>'
        elif isinstance(value, (int, float, Decimal)):
            return str(value)
        elif isinstance(value, str):
            # Handle special cases
            if value.upper() in ['[DATA NOT AVAILABLE]', 'N/A', 'NULL', '']:
                return '<em>Not available</em>'
            # Check if it's a URL
            if value.startswith(('http://', 'https://')):
                return f'<a href="{html.escape(value)}">{html.escape(value)}</a>'
            # Check if it's an email
            if '@' in value and '.' in value and len(value.split('@')) == 2:
                return f'<a href="mailto:{html.escape(value)}">{html.escape(value)}</a>'
            return html.escape(str(value))
        else:
            return html.escape(str(value))
    
    def _is_flat_dict(self, data: Dict) -> bool:
        """Check if dictionary contains only primitive values."""
        return all(isinstance(v, (str, int, float, bool, type(None), datetime, date, Decimal)) or 
                  (isinstance(v, str) and v in ['[DATA NOT AVAILABLE]', 'N/A', 'NULL', ''])
                  for v in data.values())


# Usage function for Django views
def format_pydantic_model_to_text_html(model_data: Union[Dict, Any], title: str = None) -> str:
    """
    Convenience function to format Pydantic model data to clean, text-based HTML.
    
    Args:
        model_data: Pydantic model instance, dictionary, or JSON data
        title: Optional title for the HTML document
        
    Returns:
        Clean HTML string suitable for Quill.js and external CSS styling
    """
    formatter = TextBasedHTMLFormatter()
    
    # Convert Pydantic model to dict if needed
    if hasattr(model_data, 'model_dump'):
        data = model_data.model_dump()
    elif hasattr(model_data, 'dict'):
        data = model_data.dict()
    else:
        data = model_data
    
    return formatter.format_to_html(data, title)


# Extended formatter specifically optimized for Quill.js compatibility
class QuillJSCompatibleFormatter(TextBasedHTMLFormatter):
    """
    Extended formatter specifically optimized for Quill.js compatibility.
    Ensures all HTML elements are supported by Quill.js editor.
    """
    
    def format_to_html(self, data: Any, title: str = None) -> str:
        """Format data with Quill.js compatible HTML elements only."""
        html_content = super().format_to_html(data, title)
        
        # Ensure compatibility with Quill.js supported elements
        # Quill supports: h1-h6, p, strong, em, u, s, a, ol, ul, li
        return html_content
    
    def _format_none(self) -> str:
        """Format None values using Quill-compatible elements."""
        return '<p><em>Not specified</em></p>'
    
    def _format_value(self, value: Any) -> str:
        """Override to ensure Quill.js compatibility."""
        result = super()._format_value(value)
        
        # Replace any unsupported HTML tags if they exist
        # Quill.js doesn't support <span> well, so avoid it
        result = re.sub(r'<span[^>]*>(.*?)</span>', r'\1', result)
        
        return result


def format_for_quill_js(model_data: Union[Dict, Any], title: str = None) -> str:
    """
    Format data specifically for Quill.js editor compatibility.
    
    Args:
        model_data: Data to format
        title: Optional title
        
    Returns:
        Quill.js compatible HTML string
    """
    formatter = QuillJSCompatibleFormatter()
    
    if hasattr(model_data, 'model_dump'):
        data = model_data.model_dump()
    elif hasattr(model_data, 'dict'):
        data = model_data.dict()
    else:
        data = model_data
    
    return formatter.format_to_html(data, title)
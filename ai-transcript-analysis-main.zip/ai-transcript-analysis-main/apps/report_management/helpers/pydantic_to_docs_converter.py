from pydantic import BaseModel
from typing import get_args, get_origin, Literal
import inspect
import markdown
from markdown.extensions import Extension
from markdown.extensions.extra import ExtraExtension


class DocBuilder:
    @staticmethod
    def get_expected_output_model(model):
        expected_output_structure = DocBuilder.get_expected_output(model)
        
        expected_output = "Result should be markdown professional document with:\n"
        title = "Main heading"
        content_structure = expected_output_structure

        final_expected_output = expected_output + f"\n# {title}\n\n{content_structure}"
        return final_expected_output

    @staticmethod
    def get_expected_output(model, level=0):
        if not inspect.isclass(model) or not issubclass(model, BaseModel):
            return ""

        lines = []
        indent = "  " * level

        for name, field in model.model_fields.items():
            field_info = field
            field_type = field.annotation
            field_name = name.replace("_", " ").capitalize()
            required = "Required" if field_info.is_required() else f"Optional (Default: {field_info.default})"
            description = field_info.description or "No description provided."

            origin = get_origin(field_type)
            args = get_args(field_type)

            # Type string (human readable)
            type_str = DocBuilder.get_type_str(field_type)

            # Handle nested BaseModel
            if inspect.isclass(field_type) and issubclass(field_type, BaseModel):
                lines.append(f"{indent}- **{field_name}** ({required}, type: `{type_str}`): {description}")
                lines.append(DocBuilder.get_expected_output(field_type, level + 1))

            # Handle List[BaseModel]
            elif origin == list and args and inspect.isclass(args[0]) and issubclass(args[0], BaseModel):
                lines.append(f"{indent}- **{field_name}** ({required}, type: `List[{args[0].__name__}]`): {description}")
                lines.append(DocBuilder.get_expected_output(args[0], level + 1))

            # Handle simple fields
            else:
                lines.append(f"{indent}- **{field_name}** ({required}, type: `{type_str}`): {description}")

        return "\n".join(lines)

    @staticmethod
    def get_type_str(tp):
        """Convert a type annotation to a readable string"""
        origin = get_origin(tp)
        args = get_args(tp)

        if origin is list and args:
            return f"List[{DocBuilder.get_type_str(args[0])}]"
        elif origin is Literal:
            return f"Literal[{', '.join(map(str, args))}]"
        elif hasattr(tp, '__name__'):
            return tp.__name__
        elif tp is None:
            return "None"
        return str(tp)
    

    @staticmethod
    def render_markdown_as_html(markdown_text: str) -> str:
        """
        Converts markdown text into sanitized, styled HTML.
        Useful for rendering professional previews in Django templates.
        """
        html = markdown.markdown(
            markdown_text,
            extensions=[
                ExtraExtension(),  # Handles tables, definition lists, etc.
                'markdown.extensions.smarty',
                'markdown.extensions.sane_lists',
            ],
            output_format='html5'
        )
        return html
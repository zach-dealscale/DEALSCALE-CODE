import json
import logging
import traceback
import asyncio
from collections import defaultdict

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import TemplateView
from django.http import JsonResponse, StreamingHttpResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.utils.decorators import method_decorator
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.views.decorators.cache import never_cache
from asgiref.sync import sync_to_async

from apps.authentication.models import Client
from apps.report_management.models import (
    Transcript, ReportTemplate, ReportFormation, 
    PromptExperiment, PromptHistory, Category
)
from apps.ai_agents.utils.ai_report_generator import ReportGenerator

logger = logging.getLogger(__name__)
User = get_user_model()


class StaffRequiredMixin(UserPassesTestMixin):
    """Mixin to ensure only staff/admin users can access the playground"""
    
    def test_func(self):
        return self.request.user.is_staff or self.request.user.is_superuser


class PromptPlaygroundView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    """
    Playground view for staff/admin users to experiment with prompts in real-time.
    Features split-screen layout with synchronous execution.
    """
    template_name = "report_management/playground.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Get all transcripts for selection
        transcripts = Transcript.objects.all().order_by('-created_at')[:50]  # Limit for performance
        context['transcripts'] = transcripts
        
        # Get all templates organized by category
        templates_by_category = defaultdict(lambda: defaultdict(list))
        categories = Category.objects.prefetch_related(
            'subcategory_set',
            'subcategory_set__reporttemplate_set'
        ).all()
        
        for category in categories:
            for subcategory in category.subcategory_set.all():
                for template in subcategory.reporttemplate_set.all():
                    templates_by_category[category.name][subcategory.name].append(template)
        
        # Fallback: If no categorized templates, get all templates without category organization
        if not templates_by_category:
            all_templates = ReportTemplate.objects.all()
            if all_templates:
                templates_by_category["All Templates"]["General"] = list(all_templates)
        
        context['templates_by_category'] = templates_by_category
        context['categories'] = categories
        context['all_templates'] = ReportTemplate.objects.all()  # Add this for debugging
        print("all_templates", context['all_templates'])
        print("templates_by_category", templates_by_category)
        # Get selected transcript and template from URL params
        transcript_id = self.request.GET.get('transcript_id')
        template_id = self.request.GET.get('template_id')
        
        selected_transcript = None
        selected_template = None
        
        if transcript_id:
            selected_transcript = Transcript.objects.filter(id=transcript_id).first()
            if selected_transcript:
                context['selected_transcript'] = {
                    'id': selected_transcript.id,
                    'title': selected_transcript.title,
                    'client_name': selected_transcript.client.name if selected_transcript.client else '',
                    'platform': selected_transcript.platform,
                    'created_at': selected_transcript.created_at.strftime('%B %d, %Y')
                }
        
        if template_id:
            selected_template = ReportTemplate.objects.filter(id=template_id).first()
            if selected_template:
                context['selected_template'] = {
                    'id': selected_template.id,
                    'title': selected_template.title,
                    'description': selected_template.description,
                    'framework_prompt': selected_template.framework_prompt or ''
                }
        
        # Get recent experiments for this user
        recent_experiments = PromptExperiment.objects.filter(
            user=self.request.user
        ).select_related('template', 'transcript').order_by('-updated_at')[:10]
        context['recent_experiments'] = recent_experiments
        
        return context


@method_decorator(csrf_exempt, name='dispatch')
class PromptGenerateView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    """
    AJAX endpoint to generate report content synchronously using experimental prompt.
    """
    
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            print("input data for generate report", data)
            transcript_id = data.get('transcript_id')
            template_id = data.get('template_id')
            experimental_prompt = data.get('experimental_prompt', '').strip()
            
            if not all([transcript_id, template_id]):
                return JsonResponse({
                    'success': False,
                    'error': 'Missing required parameters: transcript_id or template_id'
                })
            
            # Get transcript and template
            transcript = get_object_or_404(Transcript, id=transcript_id)
            template = get_object_or_404(ReportTemplate, id=template_id)
            
            # Use template's framework prompt if experimental_prompt is empty
            if not experimental_prompt:
                experimental_prompt = template.framework_prompt or ''
                if not experimental_prompt:
                    return JsonResponse({
                        'success': False,
                        'error': 'No framework prompt available for this template'
                    })
            
            # Save/update the experiment
            experiment, created = PromptExperiment.objects.update_or_create(
                template=template,
                transcript=transcript,
                user=request.user,
                defaults={
                    'experimental_prompt': experimental_prompt,
                    'generated_output': '',  # Will be filled after generation
                    'is_satisfactory': False,
                    'updated_at': timezone.now()
                }
            )
            
            logger.info(f"Starting synchronous report generation for experiment {experiment.id}")
            
            # Temporarily override the template's framework_prompt
            original_prompt = template.framework_prompt
            template.framework_prompt = experimental_prompt
            
            try:
                # Generate report synchronously using ReportGenerator
                report_generator = ReportGenerator(template_object=template)
                transcript_output_data = report_generator.generate_report(
                    transcript=transcript.text,
                    report_instance=None  # Don't pass report instance to avoid DB issues
                )
                
                if transcript_output_data and hasattr(transcript_output_data, 'content'):
                    # Clean HTML content from LLM response, removing conversational text
                    from apps.ai_agents.utils.html_extractor import clean_llm_html_response
                    output_json = clean_llm_html_response(transcript_output_data.content)
                    
                    # Create the same data structure as tasks.py
                    output_data = {'data': output_json}
                    
                    # Store the generated output in the experiment (optional for history)
                    experiment.generated_output = json.dumps(output_data)
                    experiment.save()
                    
                    # Create temporary report formation for rendering only (not saved to DB)
                    temp_report = ReportFormation(
                        template=template,
                        transcript=transcript,
                        user=request.user,
                        status="completed"
                    )
                    temp_report.output_data = output_data
                    
                    # Get rendered HTML content (similar to DocumentEditView)
                    rendered_content = temp_report.get_editor_content()
                    print("rendered_content", rendered_content)
                    
                    return JsonResponse({
                        'success': True,
                        'html_content': rendered_content,
                        'experiment_id': experiment.id,
                        'message': 'Report generated successfully!'
                    })
                else:
                    raise Exception("Invalid output data structure")
                    
            except Exception as generation_error:
                error_msg = f"Generation failed: {str(generation_error)}"
                logger.error(f"Report generation error: {error_msg}")
                logger.error(traceback.format_exc())
                
                # Store error in experiment
                experiment.generated_output = json.dumps({'error': error_msg})
                experiment.save()
                
                return JsonResponse({
                    'success': False,
                    'error': error_msg,
                    'experiment_id': experiment.id
                })
            
            finally:
                # Restore original prompt
                template.framework_prompt = original_prompt
                template.save()
                
        except Exception as e:
            logger.error(f"Playground generation error: {str(e)}")
            logger.error(traceback.format_exc())
            return JsonResponse({
                'success': False,
                'error': f"Server error: {str(e)}"
            })


@method_decorator(csrf_exempt, name='dispatch')
class PromptCommitView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    """
    AJAX endpoint to commit successful experimental prompt to production.
    """
    
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            experiment_id = data.get('experiment_id')
            version_note = data.get('version_note', '').strip()
            current_prompt = data.get('current_prompt', '').strip()  # Get current textarea content

            print("data for commit", data)
            
            if not experiment_id:
                return JsonResponse({
                    'success': False,
                    'error': 'Missing experiment_id'
                })
            
            if not current_prompt:
                return JsonResponse({
                    'success': False,
                    'error': 'Missing current_prompt - cannot commit empty prompt'
                })
            
            # Get the experiment
            experiment = get_object_or_404(PromptExperiment, id=experiment_id, user=request.user)
            
            # Save current prompt to history before updating
            if experiment.template.framework_prompt:
                PromptHistory.objects.create(
                    template=experiment.template,
                    prompt_text=experiment.template.framework_prompt,
                    user=request.user,
                    version_note=f"Auto-saved before playground commit: {version_note}" if version_note else "Auto-saved before playground commit"
                )
            
            # Update experiment with current prompt (in case it was modified)
            experiment.experimental_prompt = current_prompt
            experiment.save()
            
            # Update template with current prompt from textarea
            experiment.template.framework_prompt = current_prompt
            experiment.template.save()
            
            # Mark experiment as satisfactory
            experiment.is_satisfactory = True
            experiment.save()
            
            logger.info(f"Committed experimental prompt from experiment {experiment.id} to template {experiment.template.id}")
            
            print("experiment", experiment)

            return JsonResponse({
                'success': True,
                'message': f'Prompt successfully committed to "{experiment.template.title}" template!'
            })
            
        except Exception as e:
            logger.error(f"Prompt commit error: {str(e)}")
            logger.error(traceback.format_exc())
            return JsonResponse({
                'success': False,
                'error': f"Commit failed: {str(e)}"
            })


class PromptHistoryView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    """
    View to display prompt history for a specific template.
    """
    template_name = "report_management/prompt_history.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        template_id = kwargs.get('template_id')
        template = get_object_or_404(ReportTemplate, id=template_id)
        
        history = PromptHistory.objects.filter(
            template=template
        ).select_related('user').order_by('-created_at')
        
        context['template'] = template
        context['history'] = history
        
        return context



@method_decorator(csrf_exempt, name='dispatch')
class CreateExperimentView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    """
    API endpoint to create/update PromptExperiment and return experiment_id
    """
    
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            transcript_id = data.get('transcript_id')
            template_id = data.get('template_id')
            experimental_prompt = data.get('experimental_prompt', '').strip()
            
            if not all([transcript_id, template_id]):
                return JsonResponse({
                    'success': False,
                    'error': 'Missing required parameters: transcript_id or template_id'
                })
            
            # Get transcript and template
            transcript = get_object_or_404(Transcript, id=transcript_id)
            template = get_object_or_404(ReportTemplate, id=template_id)
            
            # Use template's framework prompt if experimental_prompt is empty
            if not experimental_prompt:
                experimental_prompt = template.framework_prompt or ''
                if not experimental_prompt:
                    return JsonResponse({
                        'success': False,
                        'error': 'No framework prompt available for this template'
                    })
            
            # Create/update the experiment
            experiment, created = PromptExperiment.objects.update_or_create(
                template=template,
                transcript=transcript,
                user=request.user,
                defaults={
                    'experimental_prompt': experimental_prompt,
                    'generated_output': '',  # Will be filled during streaming
                    'is_satisfactory': False,
                    'updated_at': timezone.now()
                }
            )
            
            logger.info(f"{'Created' if created else 'Updated'} experiment {experiment.id} for user {request.user.id}")
            
            return JsonResponse({
                'success': True,
                'experiment_id': experiment.id,
                'message': f'Experiment {"created" if created else "updated"} successfully'
            })
            
        except Exception as e:
            logger.error(f"Create experiment error: {str(e)}")
            logger.error(traceback.format_exc())
            return JsonResponse({
                'success': False,
                'error': f"Server error: {str(e)}"
            })



from django.http import StreamingHttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.cache import never_cache
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import get_object_or_404
import json
import time
import sys

def staff_required(user):
    return user.is_staff or user.is_superuser

import asyncio
from asgiref.sync import sync_to_async

async def sse_stream_view(request):
    """
    Async SSE streaming endpoint that uses experiment_id to fetch data from PromptExperiment
    """
    
    if request.method != "GET":
        return JsonResponse({"error": "Only GET is allowed"}, status=405)


    experiment_id = request.GET.get("experiment_id")
    if not experiment_id:
        return JsonResponse({"error": "Missing experiment_id parameter"}, status=400)

    # Store user info synchronously
    user = request.user

    async def experiment_event_stream():
        # try:
        # Lazy imports
        from apps.ai_agents.services.agent_service import SalesAgent
        from apps.ai_agents.utils.ai_report_generator import ReportGenerator
        from apps.report_management.models import PromptExperiment

        # Get experiment data async using the stored user
        # Get experiment data async using the stored user with related objects
        try:
            experiment = await sync_to_async(
                lambda: get_object_or_404(
                    PromptExperiment.objects.select_related(
                        'transcript',
                        'template',
                        'template__category',
                        'template__category__category'
                    ), 
                    id=experiment_id, user=user
                )
            )()
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': f'Experiment not found: {str(e)}'})}\n\n"
            return

        # Now these will work without additional DB queries
        transcript = experiment.transcript
        template = experiment.template
        experimental_prompt = experiment.experimental_prompt

        # Initialize components
        report_generator = ReportGenerator(template_object=template)
        final_prompt = await sync_to_async(report_generator.get_final_prompt)(
            transcript=transcript.text,
            framework_prompt=experimental_prompt
        )
        
        agent = SalesAgent(template=template)

        print(f"ASYNC SERVER: Starting SSE stream for experiment {experiment_id}")
        print(f"ASYNC SERVER: Final prompt: {(final_prompt or '')[:200]}")

        # Send initial connection confirmation
        start_data = {
            "type": "start",
            "message": f'Starting generation for "{transcript.title}" using "{template.title}"',
            "experiment_id": experiment.id,
            "transcript_id": transcript.id,
            "template_id": template.id,
            "transcript_title": transcript.title,
            "template_title": template.title,
        }
        yield f"data: {json.dumps(start_data)}\n\n"
        
        # Reset for AI chunks
        accumulated_content = ""
        chunk_count = 0

        # Stream AI agent chunks using async method
        try:
            # Use the async streaming method
            async_generator = await agent.arun_stream(final_prompt)
            
            # Verify we have an async generator
            import inspect
            if not inspect.isasyncgen(async_generator):
                error_msg = f"Expected async generator, got {type(async_generator).__name__}"
                print(f"ASYNC SERVER ERROR: {error_msg}")
                yield f"data: {json.dumps({'type': 'error', 'message': error_msg})}\n\n"
                return
            
            print(f"ASYNC SERVER: Valid async generator confirmed, starting iteration...")
            
            async for chunk in async_generator:
                chunk_count += 1
                piece = getattr(chunk, "content", str(chunk))
                
                # Handle None values to prevent concatenation errors
                if piece is not None:
                    accumulated_content += piece
                    
                    chunk_data = {
                        "type": "chunk",
                        "content": piece,
                        "chunk_number": chunk_count,
                    }
                    yield f"data: {json.dumps(chunk_data)}\n\n"
        
        except Exception as stream_error:
            error_msg = f"Streaming error: {str(stream_error)}"
            print(f"ASYNC SERVER ERROR: {error_msg}")
            import traceback
            traceback.print_exc()
            yield f"data: {json.dumps({'type': 'error', 'message': error_msg})}\n\n"
            return

   

        # Send completion
        final_data = {
            "type": "complete",
            "html_content": accumulated_content,
            "experiment_id": experiment.id,
            "message": f"Async report generation completed for experiment {experiment.id}!",
        }
        yield f"data: {json.dumps(final_data)}\n\n"
        print(f"ASYNC SERVER: Stream completed for experiment {experiment.id}")


    response = StreamingHttpResponse(experiment_event_stream(), content_type="text/event-stream")
    response["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response["Pragma"] = "no-cache"
    response["Expires"] = "0"
    response["X-Accel-Buffering"] = "no"
    response["Access-Control-Allow-Origin"] = "*"
    return response
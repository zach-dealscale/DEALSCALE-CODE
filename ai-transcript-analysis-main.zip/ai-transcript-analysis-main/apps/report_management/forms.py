from urllib.parse import urlparse

from django.forms import FileInput
from django import forms
from django.forms import ClearableFileInput

from .models import Transcript, ReportTemplate

from django import forms

from ..authentication.models import Client
from ..sale_rooms.models import SalesRoomMedia, Comment, MutualActionItem, ClientContact
from ..sale_rooms.salesforce_integration_utils import RoleChoices


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput(attrs={'class': 'hidden', 'multiple': True}))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single_file_clean = super().clean
        if isinstance(data, (list, tuple)):
            result = [single_file_clean(d, initial) for d in data]
        else:
            result = [single_file_clean(data, initial)]
        return result

class TranscriptForm(forms.ModelForm):

    class Meta:
        model = Transcript
        fields = ['title', 'text', 'client']  # don't include 'file' here
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'w-full px-3 py-2 border rounded-md',
                'placeholder': 'Enter meeting title...'
            }),
            'text': forms.Textarea(attrs={
                'rows': 8,
                'class': 'w-full ...',
                'placeholder': 'Paste your transcript text here...'
            }),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        self.files = kwargs.get('files', None)  # manually pass files
        super().__init__(*args, **kwargs)

        if self.user:
            self.fields['client'].queryset = Client.objects.filter(user=self.user)

    def clean(self):
        cleaned_data = super().clean()
        text = cleaned_data.get('text')
        client = cleaned_data.get('client')
        files = self.files.getlist('file') if self.files else []

        if not text and not files:
            self.add_error('text', 'Please provide transcript text or upload at least one file.')
            raise forms.ValidationError('Either text or one or more files must be provided.')

        if not client:
            self.add_error('client', 'Please select a client.')
            raise forms.ValidationError('Client selection is required.')
        return cleaned_data


class ReportCreateForm(forms.Form):
    transcript_id= forms.ModelChoiceField(
        queryset=Transcript.objects.none(),
        required=True,
        label="Transcript",
        error_messages={"required": "Please select a transcript."}
    )
    templates = forms.ModelMultipleChoiceField(
        queryset=ReportTemplate.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=True,
        label="Report Templates",
        error_messages={"required": "Please select at least one report template."}
    )

    def __init__(self, *args, client=None, **kwargs):
        super().__init__(*args, **kwargs)
        if client:
            self.fields["transcript_id"].queryset = Transcript.objects.filter(client=client)
        self.fields["transcript_id"].queryset = Transcript.objects.all()


class TranscriptEditForm(forms.ModelForm):
    """
    Form for editing the title of a Transcript.
    """
    class Meta:
        model = Transcript
        fields = ['title']  # Only allow editing the title field

    title = forms.CharField(
        max_length=255,
        widget=forms.TextInput(attrs={
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white',
            'placeholder': 'Enter meeting title',
        })
    )


class MediaUploadForm(forms.ModelForm):
    class Meta:
        model = SalesRoomMedia
        fields = ['file']
        widgets = {
            'file': forms.FileInput(attrs={'class': 'form-control'})
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'})
        }

class ActionItemForm(forms.ModelForm):
    class Meta:
        model = MutualActionItem
        fields = ['task_detail', 'due_date', 'status']
        widgets = {
            'task_detail': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-control'})
        }


from django import forms
from django.core.validators import validate_email, URLValidator
from django.core.exceptions import ValidationError


class GuestAccessForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white',
            'placeholder': 'Enter your name',
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white',
            'placeholder': 'Enter your company email',
        })
    )

    def clean_email(self):
        email = self.cleaned_data['email'].lower().strip()
        try:
            validate_email(email)
        except ValidationError:
            raise forms.ValidationError("Please enter a valid email address")
        return email

class ClientContactForm(forms.ModelForm):
    class Meta:
        model = ClientContact
        fields = [
            'client', 'first_name', 'last_name', 'email',
            'phone', 'role',
            'notes'
        ]
        widgets = {
            'notes': forms.Textarea(attrs={
                'rows': 8,
                'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
            }),
        }

    def __init__(self, *args, **kwargs):
        super(ClientContactForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })
        self.fields['last_name'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })
        self.fields['email'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })
        self.fields['phone'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })
        self.fields['client'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })
        self.fields['role'].widget.attrs.update({
            'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
        })


class ClientCreateForm(forms.ModelForm):
    website = forms.CharField(required=False)
    class Meta:
        model = Client
        fields = ['name', 'industry', 'company_size', 'website', 'company_logo', 'notes','company_email']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['company_size'].required = True

        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-dark-hover text-gray-900 dark:text-white'
            })

    def clean_website(self):
        website = self.cleaned_data.get("website", "").strip()
        if not website:
            return ""

        parsed = urlparse(website)
        if not parsed.scheme:
            website = "https://" + website

        validator = URLValidator()
        print("Fixed website:", website)
        try:
            validator(website)
        except ValidationError:
            raise forms.ValidationError("This URL is not valid, even after fixing.")

        return website
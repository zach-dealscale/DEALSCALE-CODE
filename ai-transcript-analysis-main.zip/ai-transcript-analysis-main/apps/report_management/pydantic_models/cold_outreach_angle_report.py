from pydantic import BaseModel, Field, validator
from typing import List, Optional, Literal


# === REPORT HEADER ===

class ReportHeader(BaseModel):
    calls_analyzed: int = Field(..., description="Number of calls analyzed")
    date_range: str = Field(..., description="Date range of analyzed calls (e.g., 'July 15 – August 1, 2025')")
    target_segments: str = Field(..., description="Target segments, ICPs, or personas analyzed")


# === EXECUTIVE SUMMARY ===

class ExecutiveSummary(BaseModel):
    top_performing_hook: str = Field(..., description="Most effective cold messaging hook with performance data")
    most_cited_pain_point: str = Field(..., description="Most frequently mentioned buyer pain point with quote")
    words_to_avoid: str = Field(..., description="Words/phrases that triggered negative reactions")
    new_cold_hook_to_test: str = Field(..., description="Emerging hook opportunity from late-stage insights")
    suggested_persona_for_emailing: str = Field(..., description="Recommended persona/role for outreach")
    email_copy_testing_recommendation: str = Field(..., description="Specific A/B test recommendation with hooks and segments")


# === TOP MESSAGING ANGLES ===

class MessagingAngle(BaseModel):
    hook_angle: str = Field(..., description="Hook angle or messaging theme")
    buyer_pain_it_solves: str = Field(..., description="Specific buyer pain this hook addresses")
    real_quote_snippet: str = Field(..., description="Actual quote from transcript with attribution")
    suggested_subject_line: str = Field(..., description="Cold email subject line suggestion")

class TopMessagingAngles(BaseModel):
    messaging_angles: List[MessagingAngle] = Field(..., description="4-6 top messaging angles. Will be adjusted to 4-6.")

    @validator('messaging_angles')
    def ensure_messaging_angles(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(MessagingAngle(
                    hook_angle=f"Hook angle {len(v) + 1}",
                    buyer_pain_it_solves=f"Pain point {len(v) + 1}",
                    real_quote_snippet=f"Quote snippet {len(v) + 1}",
                    suggested_subject_line=f"Subject line {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === PERSONA-LANGUAGE MAP ===

class PersonaLanguageMapping(BaseModel):
    persona: str = Field(..., description="Persona or role (e.g., 'RevOps', 'Total Rewards')")
    common_pain_language: str = Field(..., description="Common pain phrases used by this persona")
    suggested_email_phrase: str = Field(..., description="Suggested email opening phrase for this persona")

class PersonaLanguageMap(BaseModel):
    persona_mappings: List[PersonaLanguageMapping] = Field(..., description="4-6 persona mappings. Will be adjusted to 4-6.")

    @validator('persona_mappings')
    def ensure_persona_mappings(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(PersonaLanguageMapping(
                    persona=f"Persona {len(v) + 1}",
                    common_pain_language=f"Pain language {len(v) + 1}",
                    suggested_email_phrase=f"Email phrase {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === MESSAGING HEATMAP ===

class MessagingTheme(BaseModel):
    theme: str = Field(..., description="Messaging theme or concept")
    resonance_level: Literal["🟢 High", "⚠️ Medium", "🧊 Cold", "🔴 Low"] = Field(..., description="Resonance level with emoji")
    action: str = Field(..., description="Recommended action for this theme")

class MessagingHeatmap(BaseModel):
    messaging_themes: List[MessagingTheme] = Field(..., description="5-8 messaging themes. Will be adjusted to 5-8.")

    @validator('messaging_themes')
    def ensure_messaging_themes(cls, v):
        if len(v) < 5:
            while len(v) < 5:
                v.append(MessagingTheme(
                    theme=f"Theme {len(v) + 1}",
                    resonance_level="⚠️ Medium",
                    action=f"Action for theme {len(v) + 1}"
                ))
        elif len(v) > 8:
            v = v[:8]
        return v


# === COPY BLOCK GENERATOR ===

class CopyBlock(BaseModel):
    hook: str = Field(..., description="Hook name or theme")
    email_line_template: str = Field(..., description="Ready-to-use email opening line template")

class CopyBlockGenerator(BaseModel):
    copy_blocks: List[CopyBlock] = Field(..., description="4-6 copy blocks. Will be adjusted to 4-6.")

    @validator('copy_blocks')
    def ensure_copy_blocks(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(CopyBlock(
                    hook=f"Hook {len(v) + 1}",
                    email_line_template=f"Email template {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === TACTICAL RECOMMENDATIONS ===

class TacticalRecommendations(BaseModel):
    recommendations: List[str] = Field(..., description="3-4 tactical recommendations. Will be adjusted to 3-4.")

    @validator('recommendations')
    def ensure_recommendations(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Tactical recommendation {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === EMAIL VARIANTS ===

class EmailVariant(BaseModel):
    variant_name: str = Field(..., description="Email variant name and target persona")
    subject_line: str = Field(..., description="Subject line for the email")
    email_body: str = Field(..., description="Complete email body content")
    ps_line: Optional[str] = Field(None, description="Optional P.S. line")

class ReadyToSendEmailVariants(BaseModel):
    email_variants: List[EmailVariant] = Field(..., description="Exactly 3 email variants. Will be adjusted to exactly 3.")

    @validator('email_variants')
    def ensure_three_variants(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(EmailVariant(
                    variant_name=f"Email Variant {len(v) + 1}",
                    subject_line=f"Subject line {len(v) + 1}",
                    email_body=f"Email body {len(v) + 1}",
                    ps_line=f"P.S. line {len(v) + 1}"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === FULL COLD OUTREACH ANGLE REPORT ===

class ColdOutreachAngleReport(BaseModel):
    header: ReportHeader
    executive_summary: ExecutiveSummary
    top_messaging_angles: TopMessagingAngles
    persona_language_map: PersonaLanguageMap
    messaging_heatmap: MessagingHeatmap
    copy_block_generator: CopyBlockGenerator
    tactical_recommendations: TacticalRecommendations
    email_variants: ReadyToSendEmailVariants
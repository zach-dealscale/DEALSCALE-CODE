from pydantic import BaseModel, Field, validator
from typing import List, Optional, Literal


# === EXECUTIVE SUMMARY ===

class ExecutiveMetrics(BaseModel):
    calls_processed: int = Field(..., description="Total number of calls processed")
    deals_with_competitor_mentions: int = Field(..., description="Number of deals mentioning competitors")
    top_competitors: str = Field(..., description="Top 3 competitors mentioned (comma-separated)")
    at_risk_deals_identified: int = Field(..., description="Number of deals at risk due to competitor pressure")
    stalls_attributed_to_competitors: int = Field(..., description="Number of deals stalled due to competitors")

class ExecutiveSummary(BaseModel):
    metrics: ExecutiveMetrics
    narrative_summary: str = Field(..., description="Comprehensive narrative analyzing competitive patterns, stages, and dynamics")


# === WHAT BUYERS SAY AND WHAT ACTUALLY WINS ===

class BuyerObjection(BaseModel):
    objection_theme: str = Field(..., description="Short phrase summarizing objection type")
    representative_buyer_quote: str = Field(..., description="Direct buyer quote capturing the objection")
    deals_impacted: str = Field(..., description="Number and type of deals affected (e.g., '2 enterprise deals')")
    stage: str = Field(..., description="Sales stage where objection typically occurs")
    what_actually_won: str = Field(..., description="Specific tactic/asset that successfully overcame this objection")

class WhatBuyersSaySection(BaseModel):
    buyer_objections: List[BuyerObjection] = Field(..., description="3-6 buyer objection patterns from transcript analysis")

    @validator('buyer_objections')
    def validate_buyer_objections_soft(cls, v):
        # Soft validation - accept what's provided but cap at maximum
        if len(v) < 3:
            print(f"Warning: Only {len(v)} buyer objections provided, minimum recommended is 3")
        if len(v) > 6:
            print(f"Warning: {len(v)} buyer objections provided, capping at maximum of 6")
            v = v[:6]
        return v


# === WHERE WE'RE LOSING AND WHY ===

class CompetitiveLoss(BaseModel):
    competitor: str = Field(..., description="Name of competitor that gained traction")
    who_blocked: str = Field(..., description="Buyer persona that raised the objection")
    what_they_said: str = Field(..., description="Real quote or summary of the objection")
    stage: str = Field(..., description="Deal stage when objection occurred")
    what_we_shouldve_done: str = Field(..., description="Proven tactic that has worked in similar situations")

class WhereWereLosingSection(BaseModel):
    competitive_losses: List[CompetitiveLoss] = Field(..., description="2-4 competitive loss analyses from transcript")

    @validator('competitive_losses')
    def validate_competitive_losses_soft(cls, v):
        # Soft validation - accept what's provided but cap at maximum
        if len(v) < 2:
            print(f"Warning: Only {len(v)} competitive losses provided, minimum recommended is 2")
        if len(v) > 4:
            print(f"Warning: {len(v)} competitive losses provided, capping at maximum of 4")
            v = v[:4]
        return v


# === DEALS AT RISK RIGHT NOW ===

class AtRiskDeal(BaseModel):
    deal_name: str = Field(..., description="Deal or company name")
    stage: str = Field(..., description="Current deal stage")
    competitor: str = Field(..., description="Competitor causing risk")
    risk_level: Literal["🔴 High", "🟠 Medium", "🟡 Low"] = Field(..., description="Risk level with emoji")
    suggested_intervention: str = Field(..., description="Specific intervention using proven tactics")

class DealsAtRiskSection(BaseModel):
    at_risk_deals: List[AtRiskDeal] = Field(..., description="2-3 at-risk deals with active competitive pressure")

    @validator('at_risk_deals')
    def validate_at_risk_deals_soft(cls, v):
        # Soft validation - accept what's provided but cap at maximum
        if len(v) < 2:
            print(f"Warning: Only {len(v)} at-risk deals provided, minimum recommended is 2")
        if len(v) > 3:
            print(f"Warning: {len(v)} at-risk deals provided, capping at maximum of 3")
            v = v[:3]
        return v


# === WINNING PLAYS FROM THE FIELD ===

class WinningPlay(BaseModel):
    tactic_name: str = Field(..., description="Name of the tactic or asset (in quotes)")
    description: str = Field(..., description="How and why it worked, with specific deal examples")

class WinningPlaysSection(BaseModel):
    winning_plays: List[WinningPlay] = Field(..., description="3-5 proven winning plays from successful competitive deals")

    @validator('winning_plays')
    def validate_winning_plays_soft(cls, v):
        # Soft validation - accept what's provided but cap at maximum
        if len(v) < 3:
            print(f"Warning: Only {len(v)} winning plays provided, minimum recommended is 3")
        if len(v) > 5:
            print(f"Warning: {len(v)} winning plays provided, capping at maximum of 5")
            v = v[:5]
        return v


# === FULL COMPETITOR WIN INTELLIGENCE ===

class CompetitorWinIntelligence(BaseModel):
    executive_summary: ExecutiveSummary
    what_buyers_say: WhatBuyersSaySection
    where_were_losing: WhereWereLosingSection
    deals_at_risk: DealsAtRiskSection
    winning_plays: WinningPlaysSection
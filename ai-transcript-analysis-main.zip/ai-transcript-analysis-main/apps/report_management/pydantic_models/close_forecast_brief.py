from pydantic import BaseModel, Field, validator
from typing import List, Optional
from enum import Enum


# === ENUMS FOR STRUCTURED VALUES ===

class DealStage(str, Enum):
    PROBLEM_DEFINITION = "Problem Definition"
    EVALUATION = "Evaluation"
    VALIDATION = "Validation"
    PROCUREMENT = "Procurement"

class RepAlignmentStatus(str, Enum):
    OVERCONFIDENT = "Overconfident"
    CALIBRATED = "Calibrated"
    MISALIGNED = "Misaligned"

class RiskType(str, Enum):
    STRUCTURAL = "Structural"
    BEHAVIORAL = "Behavioral"
    DECISION = "Decision"
    FINANCIAL = "Financial"
    STRATEGIC = "Strategic"
    EXTERNAL = "External"

class RiskPresence(str, Enum):
    YES = "YES"
    NO = "NO"

class ChampionMomentum(str, Enum):
    DORMANT = "Dormant"
    PASSIVE = "Passive"
    ACTIVE = "Active"
    EVANGELIST = "Evangelist"

class ConfidenceLevel(str, Enum):
    HIGH = "🟢 High"
    MEDIUM = "🟡 Medium"
    LOW = "🔴 Low"

class Priority(str, Enum):
    HIGH = "🔴 High"
    MEDIUM = "🟠 Medium"
    LOW = "🟡 Low"

class MilestoneStatus(str, Enum):
    YES = "YES"
    NO = "NO"


# === EXECUTIVE SUMMARY SECTION ===

class ExecutiveSummarySection(BaseModel):
    final_win_probability: int = Field(..., description="Final win probability percentage (e.g., 66)", ge=0, le=100)
    forecasted_close_window_start: str = Field(..., description="Start date of close window (e.g., 'Aug 19')")
    forecasted_close_window_end: str = Field(..., description="End date of close window (e.g., 'Oct 7')")
    close_duration_weeks: str = Field(..., description="Duration in weeks (e.g., '7 weeks')")
    current_deal_stage: DealStage = Field(..., description="Current deal stage")
    primary_risk_signal: str = Field(..., description="Primary risk signal identified")
    rep_alignment_status: RepAlignmentStatus = Field(..., description="Rep alignment assessment")


# === RISK INTELLIGENCE LAYER SECTION ===

class RiskIntelligenceItem(BaseModel):
    risk_category: str = Field(..., description="Risk category name")
    risk_type: RiskType = Field(..., description="Type of risk")
    is_present: RiskPresence = Field(..., description="Whether risk is present (header name: IS PRESENT?)")
    risk_status: str = Field(..., description="Risk status with emoji indicator")
    justification: str = Field(..., description="Justification for risk assessment")

class RiskIntelligenceSection(BaseModel):
    risk_items: List[RiskIntelligenceItem] = Field(..., description="9 standard risk categories. Will be adjusted to exactly 9.")
    key_deal_signals: List[str] = Field(..., description="Exactly 3 deal signals with emoji indicators. Will be adjusted to exactly 3.")
    risk_exposure_summary: str = Field(..., description="2-3 sentence summary of deal vulnerability")

    @validator('risk_items')
    def ensure_nine_risk_items(cls, v):
        standard_risks = [
            "Budget not confirmed",
            "Timeline slipping or vague", 
            "Legal/procurement delay expected",
            "Champion disengaged",
            "Buyer engagement fading",
            "Decision Maker not confirmed",
            "Economic Buyer not engaged",
            "Buying process unclear",
            "Competitive pressure present"
        ]
        
        if len(v) < 9:
            while len(v) < 9:
                risk_index = len(v)
                risk_name = standard_risks[risk_index] if risk_index < len(standard_risks) else f"Risk category {risk_index + 1}"
                v.append(RiskIntelligenceItem(
                    risk_category=risk_name,
                    risk_type=RiskType.STRUCTURAL,
                    is_present=RiskPresence.NO,
                    risk_status="✅ Not Present",
                    justification=f"Assessment for {risk_name}"
                ))
        elif len(v) > 9:
            v = v[:9]
        return v

    @validator('key_deal_signals')
    def ensure_three_signals(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"🔴 Deal Signal {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v


# === FORECAST CREDIBILITY CHECK SECTION ===

class ForecastCredibilitySection(BaseModel):
    table: str = Field(..., 
        description='''
        SHOW this in the table with following headers:
        - Signal
        - Status
        - Justification

        Following Signals record you MUST add in the forecast credibility check:
        1) signal (**Champion Momentum**), status allowed values (Dormant / Passive / Active / Evangelist)
        2) signal (**Rep Forecast Alignment**), status allowed values (Overconfident / Misaligned / Calibrated)
        NOTE: add justification for both rows
    '''
    )
    trust_index_verdict: str = Field(..., description="1-2 sentence summary of rep forecast alignment and buyer behavior")


# === CONFIDENCE MODEL BREAKDOWN SECTION ===

class ConfidenceFactor(BaseModel):
    factor_name: str = Field(..., description="Confidence factor name")
    score: str = Field(..., description="Score or assessment for the factor")
    notes: str = Field(..., description="Notes explaining the assessment")

class ConfidenceModelSection(BaseModel):
    deal_stage: DealStage = Field(..., description="Deal stage for confidence model")
    confidence_factors: List[ConfidenceFactor] = Field(..., description="6-8 confidence factors. Will be adjusted to 6-8.")
    final_win_probability: int = Field(..., description="Final win probability percentage (e.g 56%)", ge=0, le=100)
    confidence_verdict: str = Field(..., description="Summary of confidence assessment")

    @validator('confidence_factors')
    def ensure_confidence_factors(cls, v):
        if len(v) < 6:
            while len(v) < 6:
                v.append(ConfidenceFactor(
                    factor_name=f"Factor {len(v) + 1}",
                    score="Medium",
                    notes=f"Assessment notes {len(v) + 1}"
                ))
        elif len(v) > 8:
            v = v[:8]
        return v


# === CLOSE TIMELINE ANALYSIS SECTION ===

class TimelineStage(BaseModel):
    stage_motion: str = Field(..., description="Stage or motion name")
    base_duration: str = Field(..., description="Base duration (e.g., '2 weeks')")
    blocking_factor: int = Field(..., description="Blocking factor score 0-3", ge=0, le=3)
    confidence_level: ConfidenceLevel = Field(..., description="Confidence level with emoji")
    milestone_missing: MilestoneStatus = Field(..., description="Whether milestone is missing")
    notes: str = Field(..., description="Notes about the stage")

class CloseTimelineSection(BaseModel):
    timeline_stages: List[TimelineStage] = Field(..., description="4 timeline stages. Will be adjusted to exactly 4.")
    adjusted_close_range: str = Field(..., description="Adjusted close range (e.g., '7 weeks')")
    estimated_close_window: str = Field(..., description="Estimated close window start date to end date (e.g April 2024 -> May 2024)")
    timeline_assumption: str = Field("This assumes buyer motivation holds and no blockers emerge.",
            description="static sentence without heading 'This assumes buyer motivation holds and no blockers emerge.'"
        )

    @validator('timeline_stages')
    def ensure_four_stages(cls, v):
        standard_stages = [
            "Internal Buy-In",
            "Budget Confirmation", 
            "Legal / Procurement Review",
            "Final Decision & Signature"
        ]
        
        if len(v) < 4:
            while len(v) < 4:
                stage_index = len(v)
                stage_name = standard_stages[stage_index] if stage_index < len(standard_stages) else f"Stage {stage_index + 1}"
                v.append(TimelineStage(
                    stage_motion=stage_name,
                    base_duration="1 week",
                    blocking_factor=1,
                    confidence_level=ConfidenceLevel.MEDIUM,
                    milestone_missing=MilestoneStatus.NO,
                    notes=f"Notes for {stage_name}"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === SCENARIO SENSITIVITY MODEL SECTION ===

class ScenarioModel(BaseModel):
    scenario: str = Field(..., description="Scenario name (Best Case, Realistic, Worst Case)")
    estimated_close_window: str = Field(..., description="Close window date range")
    notes: str = Field(..., description="1 sentence explanation")

class ScenarioSensitivitySection(BaseModel):
    scenarios: List[ScenarioModel] = Field(..., description="3 scenarios. Will be adjusted to exactly 3.")

    @validator('scenarios')
    def ensure_three_scenarios(cls, v):
        scenario_names = ["Best Case", "Realistic", "Worst Case"]
        
        if len(v) < 3:
            while len(v) < 3:
                scenario_index = len(v)
                scenario_name = scenario_names[scenario_index] if scenario_index < len(scenario_names) else f"Scenario {scenario_index + 1}"
                v.append(ScenarioModel(
                    scenario=scenario_name,
                    estimated_close_window="Date range",
                    notes=f"Notes for {scenario_name}"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === STRATEGIC ACTION PATH SECTION ===

class StrategicAction(BaseModel):
    priority: Priority = Field(..., description="Priority level with emoji")
    action: str = Field(..., description="Strategic action description")
    trigger_condition: str = Field(..., description="Trigger condition for action")
    owner: str = Field(..., description="Owner of the action")

class StrategicActionSection(BaseModel):
    strategic_actions: List[StrategicAction] = Field(..., description="5 strategic actions. Will be adjusted to exactly 5.")
    deal_saving_move: str = Field(..., description="Top-priority deal-saving move description")

    @validator('strategic_actions')
    def ensure_five_actions(cls, v):
        if len(v) < 5:
            while len(v) < 5:
                v.append(StrategicAction(
                    priority=Priority.MEDIUM,
                    action=f"Strategic action {len(v) + 1}",
                    trigger_condition=f"Trigger condition {len(v) + 1}",
                    owner="AE"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === FULL CLOSE FORECAST BRIEF ===

class CloseForecastBrief(BaseModel):
    executive_summary: ExecutiveSummarySection
    risk_intelligence: RiskIntelligenceSection
    forecast_credibility_check: ForecastCredibilitySection
    confidence_model: ConfidenceModelSection
    close_timeline: CloseTimelineSection
    scenario_sensitivity: ScenarioSensitivitySection
    strategic_action: StrategicActionSection
from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === EXECUTIVE SUMMARY SECTION ===

class ExecutiveSummarySection(BaseModel):
    executive_summary_paragraph: str = Field(..., description="3-5 sentence executive summary following exact client pattern: cost exposure, solution investment %, exact ROI, strategic benefits, urgency")


# === RETENTION COST ANALYSIS SECTION ===

class RetentionCostAnalysisSection(BaseModel):
    # Industry Context
    average_salary: str = Field(..., description="Average salary per year (industry specific, e.g., 'CAD $85,000')")
    employee_turnover_rate: str = Field(..., description="Employee turnover rate with context (e.g., '18% (average for hybrid tech and manufacturing orgs)')")
    source_details: str = Field(..., description="Source citation (e.g., 'Conference Board of Canada, 2024')")
    
    # Annual Cost Calculation
    total_employees_estimated: int = Field(..., description="Total employee count")
    employees_at_risk_calculation: str = Field(..., description="Calculation description (e.g., '18% of 1,200')")
    employees_at_risk_number: int = Field(..., description="Number of employees at risk")
    cost_per_turnover_percentage: str = Field(..., description="Percentage of salary (e.g., '33% of salary')")
    cost_per_turnover_amount: str = Field(..., description="Cost per turnover amount (e.g., '$28,050')")
    potential_annual_turnover_cost: str = Field(..., description="Total annual turnover cost (e.g., '$6,063,000')")


# === HIRING COST ANALYSIS SECTION ===

class HiringCostAnalysisSection(BaseModel):
    # Industry Standards
    average_cost_per_hire: str = Field(..., description="Average cost-per-hire amount (e.g., '$6,000')")
    time_to_fill: str = Field(..., description="Time-to-fill in days (e.g., '42 days')")
    source_details: str = Field(..., description="Source citation (e.g., 'SHRM 2024, Workopolis Survey')")
    
    # Annual Hiring Cost Impact
    potential_annual_turnover: int = Field(..., description="Number of employees from retention analysis")
    direct_hiring_costs_calculation: str = Field(..., description="Direct hiring costs calculation (e.g., '216 × $6,000')")
    direct_hiring_costs_amount: str = Field(..., description="Direct hiring costs total (e.g., '$1,296,000')")
    lost_productivity_calculation: str = Field(..., description="Lost productivity calculation (e.g., '216 × 42 days × $340/day')")
    lost_productivity_amount: str = Field(..., description="Lost productivity total (e.g., '$3,086,880')")
    total_annual_hiring_impact: str = Field(..., description="Total hiring impact (e.g., '$4,382,880')")


# === MANUAL PROCESS COSTS SECTION ===

class ManualProcessCostsSection(BaseModel):
    # Current Administrative Burden
    average_time_manual_tasks: str = Field(..., description="Time spent on manual tasks (e.g., '~20 hours/month')")
    average_coordinator_rate: str = Field(..., description="Coordinator hourly rate (e.g., '$45/hour')")
    annual_administrative_cost_calculation: str = Field(..., description="Calculation (e.g., '20 × $45 × 12')")
    annual_administrative_cost_amount: str = Field(..., description="Administrative cost total (e.g., '$10,800')")
    
    # Additional Hidden Costs
    additional_hidden_costs: List[str] = Field(..., description="2-4 additional cost items with amounts. Will be adjusted to 2-4.")
    total_manual_process_cost: str = Field(..., description="Total manual process cost (e.g., '$35,000')")

    @validator('additional_hidden_costs')
    def ensure_hidden_costs(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Additional cost item {len(v) + 1}: $X,XXX/year")
        elif len(v) > 4:
            v = v[:4]
        return v


# === COST SUMMARY AND ROI ANALYSIS SECTION ===

class ROISavingsBreakdown(BaseModel):
    savings_description: str = Field(..., description="Savings description (e.g., '20% reduction in turnover cost')")
    savings_amount: str = Field(..., description="Savings amount (e.g., '$1,212,600')")

class CostSummaryROISection(BaseModel):
    # Current Annual Cost Exposure
    retention_risk: str = Field(..., description="Retention risk cost (e.g., '$6,063,000')")
    hiring_costs: str = Field(..., description="Hiring costs (e.g., '$4,382,880')")
    manual_process_costs: str = Field(..., description="Manual process costs (e.g., '$35,000')")
    total_annual_cost_exposure: str = Field(..., description="Total cost exposure (e.g., '$10,480,880')")
    
    # Proposed Solution Cost
    solution_name: str = Field(..., description="Solution name (e.g., 'Terryberry Plus Recognition Platform')")
    platform_fee_calculation: str = Field(..., description="Platform fee calculation (e.g., '$2.40/employee/month × 1,200 employees × 12 months = $34,560')")
    implementation_fee: str = Field(..., description="Implementation fee (e.g., '$995 (waivable for multi-year contract)')")
    total_year_investment: str = Field(..., description="Total investment (e.g., '$35,555')")
    
    # Potential ROI
    assumed_improvement_description: str = Field(..., description="Description of improvement assumptions")
    roi_savings_breakdown: List[ROISavingsBreakdown] = Field(..., description="2-4 savings categories. Will be adjusted to 2-4.")
    total_potential_savings: str = Field(..., description="Total savings amount (e.g., '$2,338,070')")
    roi_calculation_formula: str = Field(..., description="ROI calculation formula (e.g., 'ROI = (2,338,070 - 35,555) / 35,555 = 6475.7%')")
    
    # Summary
    current_exposure_summary: str = Field(..., description="Current exposure summary paragraph")
    investment_required_summary: str = Field(..., description="Investment required summary paragraph") 
    improved_roi_summary: str = Field(..., description="ROI summary paragraph")
    hidden_benefits: List[str] = Field(..., description="4-6 hidden benefits list. Will be adjusted to 4-6.")

    @validator('roi_savings_breakdown')
    def ensure_savings_breakdown(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(ROISavingsBreakdown(
                    savings_description=f"Savings category {len(v) + 1}",
                    savings_amount=f"$XXX,XXX"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('hidden_benefits')
    def ensure_hidden_benefits(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(f"Hidden benefit {len(v) + 1}")
        elif len(v) > 6:
            v = v[:6]
        return v


# === REFERENCES SECTION ===

class ReferencesSection(BaseModel):
    references_list: List[str] = Field(..., description="3-5 credible source references. Will be adjusted to 3-5.")

    @validator('references_list')
    def ensure_references(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Industry source reference {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === FULL COST OF INACTION REPORT ===

class CostOfInactionReport(BaseModel):
    company_name: str = Field(..., description="Company name for report header")
    
    executive_summary: ExecutiveSummarySection
    retention_cost_analysis: RetentionCostAnalysisSection
    hiring_cost_analysis: HiringCostAnalysisSection
    manual_process_costs: ManualProcessCostsSection
    cost_summary_roi_analysis: CostSummaryROISection
    references: ReferencesSection
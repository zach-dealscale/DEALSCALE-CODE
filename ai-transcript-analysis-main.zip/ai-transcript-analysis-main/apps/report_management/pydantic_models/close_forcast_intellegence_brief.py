from pydantic import BaseModel, Field
from typing import List, Optional
from enum import Enum

class RiskLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class RiskLevelWithColor(BaseModel):
    risk_level: RiskLevel
    color: str

class ForecastedCloseWindow(BaseModel):
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

class DealForecastIntelligenceSchema(BaseModel):
    current_deal_stage: str = Field(..., description="Current stage of the deal")
    forecasted_close_window: ForecastedCloseWindow
    final_win_probability: float = Field(..., ge=0, le=100, description="Win probability percentage between 0-100")
    key_deal_signals: List[str] = Field(..., description="List of key deal signals with icons")
    risk_level: RiskLevelWithColor
    risk_exposure_summary: str = Field(..., description="Summary of risk exposures")
    deal_saving_move: str = Field(..., description="Content from the 'Deal-Saving Move' section of the report")

    class Config:
        json_schema_extra = {
            "example": {
                "current_deal_stage": "Negotiation",
                "forecasted_close_window": {
                    "start_date": "2024-12-01",
                    "end_date": "2024-12-15"
                },
                "final_win_probability": 75.0,
                "key_deal_signals": [
                    "🟢 Strong budget alignment",
                    "⚠️ Multiple stakeholders involved",
                    "🔴 Competitor presence"
                ],
                "risk_level": {
                    "risk_level": "medium",
                    "color": "Yellow"
                },
                "risk_exposure_summary": "Moderate risk due to competitive landscape and stakeholder complexity",
                "deal_saving_move": "Pick exact same content of last section from the report."
            }
        }
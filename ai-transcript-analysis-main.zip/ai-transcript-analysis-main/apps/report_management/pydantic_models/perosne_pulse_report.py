from typing import List, Dict, Optional
from pydantic import BaseModel, Field


class PersonaEmotionEntry(BaseModel):
    persona: str = Field(..., description="The persona name")
    trigger_words_phrases: str = Field(..., description="Trigger words and phrases for this persona")
    emotional_signals: str = Field(..., description="Emotional signals exhibited by this persona")
    objection_pattern: str = Field(..., description="Common objection patterns from this persona")
    campaign_angle: str = Field(..., description="Recommended campaign angle for this persona")


class MessagingHeatZone(BaseModel):
    message_angle: str = Field(..., description="The message angle being tested")
    persona_response: str = Field(..., description="How personas responded to this message")
    signal_strength: str = Field(..., description="Strength of the signal (Low/Medium/High)")
    action: str = Field(..., description="Recommended action based on the response")


class EmergingShift(BaseModel):
    change_detected: str = Field(..., description="Description of the change detected")
    supporting_evidence: str = Field(..., description="Evidence supporting this change")
    strategic_implication: str = Field(..., description="Strategic implication of this change")


class CreativeBriefInput(BaseModel):
    tone: str = Field(..., description="Recommended tone for this persona")
    do_say: str = Field(..., description="Recommended phrases to use")
    dont_say: str = Field(..., description="Phrases to avoid")
    cta_words: str = Field(..., description="Recommended call-to-action words")
    ad_angle: str = Field(..., description="Recommended advertising angle")
    format_pref: str = Field(..., description="Preferred content formats")


class ExecutiveSummaryEntry(BaseModel):
    insight_type: str = Field(..., description="Type of insight")
    key_finding: str = Field(..., description="The key finding for this insight")


class PersonaPulseReport(BaseModel):
    period_analyzed: str = Field(..., description="The time period analyzed")
    calls_processed: int = Field(..., description="Number of calls processed")
    deals_covered: int = Field(..., description="Number of deals covered")
    target_segments: List[str] = Field(..., description="List of target personas/segments")

    executive_summary: List[ExecutiveSummaryEntry] = Field(
        ...,
        description="List of key executive summary insights"
    )

    persona_emotion_grid: List[PersonaEmotionEntry] = Field(
        ...,
        description="Grid of persona emotional triggers and responses"
    )

    messaging_heat_zones: List[MessagingHeatZone] = Field(
        ...,
        description="Analysis of message resonance with personas"
    )

    messaging_pro_tip: Optional[str] = Field(
        None,
        description="Professional tip about messaging"
    )

    emerging_shifts: List[EmergingShift] = Field(
        ...,
        description="List of emerging persona behavior shifts"
    )

    creative_brief_inputs: Optional[Dict[str, CreativeBriefInput]] = Field(
        None,
        description="Creative brief inputs keyed by persona name"
    )

    format_notes: List[str] = Field(
        ...,
        description="Notes about the report format and distribution"
    )

    generated_at: str = Field(..., description="Timestamp when report was generated")
    report_id: str = Field(..., description="Unique identifier for this report")

    class Config:
        json_schema_extra = {
            "required": [
                "period_analyzed",
                "calls_processed",
                "deals_covered",
                "target_segments",
                "executive_summary",
                "persona_emotion_grid",
                "messaging_heat_zones",
                "emerging_shifts",
                "format_notes",
                "generated_at",
                "report_id"
            ]
        }
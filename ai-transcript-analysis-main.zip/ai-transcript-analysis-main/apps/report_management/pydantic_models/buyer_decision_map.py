from pydantic import BaseModel, Field, validator
from typing import List, Optional
from enum import Enum


# === ENUMS FOR STRUCTURED VALUES ===

class InfluenceLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

class StakeholderStance(str, Enum):
    SUPPORTER = "Supporter"
    NEUTRAL = "Neutral"
    BLOCKER = "Blocker"
    UNKNOWN = "Unknown"

class StrengthLevel(str, Enum):
    STRONG = "Strong"
    MODERATE = "Moderate"
    WEAK = "Weak"

class RiskLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

class UrgencyLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


# === HEADER INFORMATION SECTION ===

class HeaderInformationSection(BaseModel):
    company_name: str = Field(..., description="Company name")
    opportunity_name: str = Field(..., description="Opportunity/deal name")
    call_date: str = Field(..., description="Date of call")
    ae_name: str = Field(..., description="Account executive name")
    call_context: str = Field(..., description="2-3 sentence overview of the call context and objectives")


# === BUYING COMMITTEE OVERVIEW SECTION ===

class BuyingCommitteeMember(BaseModel):
    name: str = Field(..., description="Stakeholder name")
    role_title: str = Field(..., description="Role/title of stakeholder")
    influence_level: InfluenceLevel = Field(..., description="Influence level: High, Medium, or Low")
    stance: StakeholderStance = Field(..., description="Stance: Supporter, Neutral, Blocker, or Unknown")
    notes_from_call: str = Field(..., description="Specific notes and observations from the call")

class BuyingCommitteeSection(BaseModel):
    committee_members: List[BuyingCommitteeMember] = Field(..., description="3-6 buying committee members. Will be adjusted to 3-6.")

    @validator('committee_members')
    def ensure_committee_members(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(BuyingCommitteeMember(
                    name=f"Stakeholder {len(v) + 1}",
                    role_title=f"Role {len(v) + 1}",
                    influence_level=InfluenceLevel.MEDIUM,
                    stance=StakeholderStance.NEUTRAL,
                    notes_from_call=f"Notes for stakeholder {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === CHAMPION STRENGTH ASSESSMENT SECTION ===

class ChampionAssessment(BaseModel):
    champion_name: str = Field(..., description="Champion name")
    strength_level: StrengthLevel = Field(..., description="Strength level: Strong, Moderate, or Weak")
    reason: str = Field(..., description="Detailed reason for strength assessment")

class ChampionStrengthSection(BaseModel):
    champion_assessments: List[ChampionAssessment] = Field(..., description="1-3 champion assessments. Will be adjusted to 1-3.")

    @validator('champion_assessments')
    def ensure_champions(cls, v):
        if len(v) < 1:
            v.append(ChampionAssessment(
                champion_name="Primary Champion",
                strength_level=StrengthLevel.MODERATE,
                reason="Champion assessment reason"
            ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === DECISION PROCESS INSIGHTS SECTION ===

class DecisionProcessInsight(BaseModel):
    insight: str = Field(..., description="Decision process insight or observation")
    supporting_quote: str = Field(..., description="Supporting quote from the call")
    risk_level: RiskLevel = Field(..., description="Risk level: High, Medium, or Low")

class DecisionProcessSection(BaseModel):
    process_insights: List[DecisionProcessInsight] = Field(..., description="2-5 decision process insights. Will be adjusted to 2-5.")

    @validator('process_insights')
    def ensure_insights(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(DecisionProcessInsight(
                    insight=f"Process insight {len(v) + 1}",
                    supporting_quote=f"Supporting quote {len(v) + 1}",
                    risk_level=RiskLevel.MEDIUM
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === TIMELINE PRESSURE POINTS SECTION ===

class TimelinePressurePoint(BaseModel):
    event_deadline: str = Field(..., description="Event or deadline description")
    impact_on_deal: str = Field(..., description="Impact on deal progression")
    urgency_level: UrgencyLevel = Field(..., description="Urgency level: High, Medium, or Low")

class TimelinePressureSection(BaseModel):
    pressure_points: List[TimelinePressurePoint] = Field(..., description="2-4 timeline pressure points. Will be adjusted to 2-4.")

    @validator('pressure_points')
    def ensure_pressure_points(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(TimelinePressurePoint(
                    event_deadline=f"Event/deadline {len(v) + 1}",
                    impact_on_deal=f"Deal impact {len(v) + 1}",
                    urgency_level=UrgencyLevel.MEDIUM
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === KEY OBJECTIONS SURFACED SECTION ===

class KeyObjection(BaseModel):
    objection: str = Field(..., description="Specific objection or concern raised")
    owner: str = Field(..., description="Who raised the objection")
    strategic_response_needed: str = Field(..., description="Strategic response or action needed")

class KeyObjectionsSection(BaseModel):
    key_objections: List[KeyObjection] = Field(..., description="2-5 key objections. Will be adjusted to 2-5.")

    @validator('key_objections')
    def ensure_objections(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(KeyObjection(
                    objection=f"Key objection {len(v) + 1}",
                    owner=f"Stakeholder {len(v) + 1}",
                    strategic_response_needed=f"Strategic response {len(v) + 1}"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === HIDDEN OBJECTIONS WATCHLIST SECTION ===

class HiddenObjectionsSection(BaseModel):
    hidden_concerns: List[str] = Field(..., description="2-4 hidden concerns or indirect resistance signals. Will be adjusted to 2-4.")

    @validator('hidden_concerns')
    def ensure_hidden_concerns(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Hidden concern {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === ACTIONABLE STAKEHOLDER STRATEGY SECTION ===

class StakeholderAction(BaseModel):
    stakeholder: str = Field(..., description="Stakeholder name")
    next_action: str = Field(..., description="Specific next action required")
    owner: str = Field(..., description="Who owns the action (typically AE/SE)")
    due_date: str = Field(..., description="Due date for action")

class ActionableStrategySection(BaseModel):
    stakeholder_actions: List[StakeholderAction] = Field(..., description="3-6 stakeholder actions. Will be adjusted to 3-6.")

    @validator('stakeholder_actions')
    def ensure_actions(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(StakeholderAction(
                    stakeholder=f"Stakeholder {len(v) + 1}",
                    next_action=f"Next action {len(v) + 1}",
                    owner="AE",
                    due_date="[Insert Date]"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === INTERNAL SELLING CONTENT AND RISK NOTES SECTION ===

class InternalContentRiskSection(BaseModel):
    internal_selling_content: List[str] = Field(..., description="3-5 internal selling assets needed. Will be adjusted to 3-5.")
    risk_notes: List[str] = Field(..., description="2-4 risk notes and early warnings. Will be adjusted to 2-4.")

    @validator('internal_selling_content')
    def ensure_content_needs(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Internal content asset {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('risk_notes')
    def ensure_risk_notes(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Risk note {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === FULL BUYER DECISION MAP ===

class BuyerDecisionMap(BaseModel):
    header_information: HeaderInformationSection
    buying_committee: BuyingCommitteeSection
    champion_strength: ChampionStrengthSection
    decision_process: DecisionProcessSection
    timeline_pressure: TimelinePressureSection
    key_objections: KeyObjectionsSection
    hidden_objections: HiddenObjectionsSection
    actionable_strategy: ActionableStrategySection
    internal_content_risk: InternalContentRiskSection
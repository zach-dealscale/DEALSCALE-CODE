from datetime import date
from typing import List, Optional, Literal
from pydantic import BaseModel, Field,validator

class CustomerInformation(BaseModel):
    """
    Customer information section of the sales engineering demo brief.
    """
    company_name: str = Field(..., description="Full legal name of the customer's company")
    customer_name_title: str = Field(..., description="Contact person's name and job title")
    industry: str = Field(..., description="Primary industry/sector of the customer")
    company_size: str = Field(..., description="Employee count and location details")
    location: str = Field(..., description="Geographic headquarters and subsidiaries")

class CallOverview(BaseModel):
    """
    Call overview section of the sales engineering demo brief.
    """
    purpose_of_the_call: str = Field(..., description="Primary goal of the demonstration")
    key_business_challenges_mentioned: List[str] = Field(..., description="Customer's stated challenges")
    initial_objectives_expectations: List[str] = Field(..., description="Customer's expected outcomes")

class PainPoint(BaseModel):
    """
    Pain point section of the sales engineering demo brief.
    """
    title: str = Field(..., description="Title of the pain point")
    details: str = Field(..., description="Detailed explanation of the challenge")

class AdditionalPainPointsNeeds(BaseModel):
    """
    Additional pain points and needs section of the sales engineering demo brief
    """
    details_context: List[str] = Field(..., description="Additional customer needs")

class PainPointsNeeds(BaseModel):
    """
    `PainPointsNeeds` section of the sales engineering demo brief.
    """
    pain_point_list: dict = Field(..., description="Add pain point title as key and details context as value")
    additional_pain_points_needs: AdditionalPainPointsNeeds


class DesiredOutcomesSuccessCriteria(BaseModel):
    """
    Desired outcomes and success criteria section of the sales engineering demo brief
    """
    desired_outcome_list: List[str] = Field(..., description="Primary business desired outcome")
    key_performance_indicators_kpis: List[str] = Field(..., description="Measurable success metrics")

class StakeholdersDecisionMakers(BaseModel):
    """
    Stakeholders and decision-makers section of the sales engineering demo brief
    """
    primary_contact: str = Field(..., description="Main point of contact")
    influencers_decision_makers: List[str] = Field(..., description="Decision-making stakeholders")
    other_notable_participants: str = Field(..., description="Additional influential participants")

class TechnicalEnvironmentCurrentSolutions(BaseModel):
    """
    Technical environment and current solutions section of the sales engineering demo brief
    """
    existing_technologies_platforms: List[str] = Field(..., description="Current tech stack")
    current_workflow_process: List[str] = Field(..., description="Existing business processes")
    integration_compatibility_notes: str = Field(..., description="Integration requirements")

class FeatureModule(BaseModel):
    """
    Feature/module details for opportunities for personalization in the demo
    """
    name: str = Field(..., description="Feature/module name")
    relevance_to_customer_need: str = Field(..., description="Business value proposition")

class OpportunitiesForPersonalizationInTheDemo(BaseModel):
    """
    Opportunities for personalization in the demo section of the sales engineering demo brief
    """
    feature_modules: List[FeatureModule]
    other_notable_customizations: List[str] = Field(..., description="Customization ideas")

class AdditionalNotesContext(BaseModel):
    """
    Additional notes and context section of the sales engineering demo brief
    """
    comments: List[str] = Field(..., description="Internal team notes")
    concerns: List[str] = Field(..., description="Potential risks/hesitations")
    potential_objections: List[str] = Field(..., description="Anticipated pushbacks")

class NextSteps(BaseModel):
    """
    Next steps section of the sales engineering demo brief
    """
    demo_date_time: str = Field(..., description="Scheduled date/time in ISO format")
    follow_up_actions: List[str] = Field(..., description="Action items post-demo")
    assigned_team_members: str = Field(..., description="Responsible team members")

class SalesEngineeringDemoBrief(BaseModel):
    """
    Sales engineering demo brief model.
    """
    customer_information: CustomerInformation
    call_overview: CallOverview
    pain_points_needs: List[PainPoint] = Field(..., description="List of pain points (min = 3, max = 7)")
    desired_outcomes_success_criteria: DesiredOutcomesSuccessCriteria
    stakeholders_decision_makers: StakeholdersDecisionMakers
    technical_environment_current_solutions: TechnicalEnvironmentCurrentSolutions
    opportunities_for_personalization_in_the_demo: OpportunitiesForPersonalizationInTheDemo
    additional_notes_context: AdditionalNotesContext
    next_steps: NextSteps

class SalesEngineeringDemoBriefWrapper(BaseModel):
    """
    Wrapper model for the sales engineering demo brief.
    """
    sales_engineering_demo_brief: SalesEngineeringDemoBrief
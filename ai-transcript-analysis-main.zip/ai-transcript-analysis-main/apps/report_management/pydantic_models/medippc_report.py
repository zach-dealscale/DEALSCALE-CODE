from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === METRICS SECTION ===

class MetricsSection(BaseModel):
    mentioned_metrics: List[str] = Field(..., description="Specific metrics and numbers mentioned by prospect. Will be adjusted to 3-6.")
    business_case_cost_savings: str = Field(..., description="Dollar amount of cost savings (e.g., '$1M+ in potential productivity unlock')")
    business_case_revenue_upside: str = Field(..., description="Revenue opportunity description")
    business_case_efficiency_gain: str = Field(..., description="Time/resource efficiency percentage or description")
    missing_metrics: List[str] = Field(..., description="Missing metrics that would strengthen the deal. Will be adjusted to 2-4.")
    ai_nudge_suggestions: List[str] = Field(..., description="2 ROI-proof points based on industry benchmarks. Will be adjusted to exactly 2.")

    @validator('mentioned_metrics')
    def ensure_metrics_count(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Additional metric {len(v) + 1}")
        elif len(v) > 6:
            v = v[:6]
        return v

    @validator('missing_metrics')
    def ensure_missing_metrics(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Missing metric {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('ai_nudge_suggestions')
    def ensure_two_ai_nudges(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"AI nudge suggestion {len(v) + 1}")
        elif len(v) > 2:
            v = v[:2]
        return v


# === ECONOMIC BUYER SECTION ===

class EconomicBuyerSection(BaseModel):
    name_role: str = Field(..., description="Economic buyer's name and role (e.g., 'Katherine [CHRO or HR Executive]')")
    confirmed_authority: bool = Field(..., description="True if authority is confirmed, False if not")
    engaged_yet: bool = Field(..., description="True if engaged, False if not engaged yet")
    known_motivations: List[str] = Field(..., description="Known motivations and triggers. Will be adjusted to 2-4.")
    risk_if_not_engaged: str = Field(..., description="Risk description if economic buyer is not engaged")

    @validator('known_motivations')
    def ensure_motivations(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Motivation {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === DECISION CRITERIA SECTION ===

class DecisionCriteriaSection(BaseModel):
    top_must_haves: List[str] = Field(..., description="Top 3 must-have requirements. Will be adjusted to exactly 3.")
    unspoken_criteria: List[str] = Field(..., description="Unspoken criteria to probe. Will be adjusted to 2-4.")

    @validator('top_must_haves')
    def ensure_three_must_haves(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Must-have requirement {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v

    @validator('unspoken_criteria')
    def ensure_unspoken_criteria(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Unspoken criteria {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === DECISION PROCESS SECTION ===

class DecisionProcessSection(BaseModel):
    milestones_identified: List[str] = Field(..., description="Process milestones in order (e.g., ['Discovery', 'Custom Demo', 'Katherine Review', 'Procurement']). Will be adjusted to 3-5.")
    legal_it_security_gates: bool = Field(..., description="True if there are legal/IT/security gates, False if not")
    known_gaps: List[str] = Field(..., description="Known gaps in understanding the process. Will be adjusted to 1-3.")

    @validator('milestones_identified')
    def ensure_milestones(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Milestone {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('known_gaps')
    def ensure_gaps(cls, v):
        if len(v) < 1:
            v.append("Gap in understanding process")
        elif len(v) > 3:
            v = v[:3]
        return v


# === PAPER PROCESS SECTION ===

class PaperProcessSection(BaseModel):
    procurement_owner: str = Field(..., description="Who owns procurement (e.g., 'TBD – likely through HR/Operations')")
    estimated_contract_date: str = Field(..., description="Estimated contract date (e.g., 'Q4 2025 (pending Katherine review)')")
    blocking_requirements: List[str] = Field(..., description="Blocking requirements like SOC2, NDAs, etc. Will be adjusted to 1-4.")
    risk_level: str = Field(..., description="Risk level: 'High', 'Medium', or 'Low'")
    risk_level_reasoning: str = Field(..., description="Reasoning for the risk level assessment")

    @validator('blocking_requirements')
    def ensure_blocking_requirements(cls, v):
        if len(v) < 1:
            v.append("TBD - requirements to be identified")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('risk_level')
    def validate_risk_level(cls, v):
        if v not in ['High', 'Medium', 'Low']:
            return 'Medium'
        return v


# === PAIN SECTION ===

class PainSection(BaseModel):
    stated_pain: List[str] = Field(..., description="List of stated pain points. Will be adjusted to 2-4.")
    root_cause_analysis: List[str] = Field(..., description="5 Whys analysis - list of why questions and answers. Will be adjusted to exactly 5.")
    impact_revenue_at_risk: str = Field(..., description="Revenue at risk amount (e.g., '$2–3M+ revenue at risk')")
    impact_waste_amount: str = Field(..., description="Amount wasted per period (e.g., '30–50 hours/month wasted')")

    @validator('stated_pain')
    def ensure_pain_points(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Pain point {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('root_cause_analysis')
    def ensure_five_whys(cls, v):
        if len(v) < 5:
            while len(v) < 5:
                v.append(f"Why question {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === CHAMPION SECTION ===

class ChampionSection(BaseModel):
    name_role: str = Field(..., description="Champion's name and role")
    influence_level: int = Field(..., description="Influence level from 1-5", ge=1, le=5)
    actions_taken: List[str] = Field(..., description="Actions taken to push deal forward. Will be adjusted to 2-4.")
    red_flags: List[str] = Field(..., description="Red flags about the champion. Will be adjusted to 1-3.")
    game_plan_to_strengthen: List[str] = Field(..., description="Game plan to strengthen champion. Will be adjusted to 2-4.")

    @validator('actions_taken')
    def ensure_actions(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Action taken {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('red_flags')
    def ensure_red_flags(cls, v):
        if len(v) < 1:
            v.append("Red flag to monitor")
        elif len(v) > 3:
            v = v[:3]
        return v

    @validator('game_plan_to_strengthen')
    def ensure_game_plan(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Strengthening strategy {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === COMPETITION SECTION ===

class CompetitorView(BaseModel):
    competitor_name: str = Field(..., description="Competitor name")
    prospect_view: str = Field(..., description="Prospect's view of this competitor")

class CompetitionSection(BaseModel):
    known_vendors: List[str] = Field(..., description="Known vendors in evaluation. Will be adjusted to 1-4.")
    competitor_views: List[CompetitorView] = Field(..., description="Prospect's view of each competitor. Will be adjusted to match known_vendors.")
    our_differentiators: List[str] = Field(..., description="Our differentiators mapped to their criteria. Will be adjusted to 3-5.")
    counter_positioning_plan: List[str] = Field(..., description="Counter-positioning plan. Will be adjusted to 2-4.")

    @validator('known_vendors')
    def ensure_vendors(cls, v):
        if len(v) < 1:
            v.append("No known competitors yet")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('competitor_views')
    def match_competitor_views(cls, v, values):
        vendors = values.get('known_vendors', [])
        if len(v) < len(vendors):
            for i in range(len(v), len(vendors)):
                v.append(CompetitorView(
                    competitor_name=vendors[i] if i < len(vendors) else f"Competitor {i+1}",
                    prospect_view=f"View of {vendors[i] if i < len(vendors) else f'Competitor {i+1}'}"
                ))
        elif len(v) > len(vendors):
            v = v[:len(vendors)]
        return v

    @validator('our_differentiators')
    def ensure_differentiators(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Differentiator {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('counter_positioning_plan')
    def ensure_counter_plan(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Counter-positioning strategy {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === BONUS INSIGHTS SECTION ===

class BonusInsightsSection(BaseModel):
    rep_blind_spot: str = Field(..., description="What the rep is not seeing or avoiding")
    biggest_deal_acceleration_lever: str = Field(..., description="The biggest opportunity to accelerate the deal")


# === FULL MEDDPICC REPORT ===

class MEDDPICCReport(BaseModel):
    company_name: str = Field(..., description="Company name for header")
    
    metrics: MetricsSection
    economic_buyer: EconomicBuyerSection
    decision_criteria: DecisionCriteriaSection
    decision_process: DecisionProcessSection
    paper_process: PaperProcessSection
    pain: PainSection
    champion: ChampionSection
    competition: CompetitionSection
    bonus_insights: BonusInsightsSection
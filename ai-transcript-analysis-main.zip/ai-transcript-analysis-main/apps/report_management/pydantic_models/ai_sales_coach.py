# from datetime import date
# from typing import List, Optional, Literal
# from pydantic import BaseModel, Field, validator


# class PerformanceMetric(BaseModel):
#     """Model for individual performance metrics"""
#     score: int = Field(..., description="Rating score from 1 (low) to 5 (high)")
#     analysis: str = Field(..., description="Detailed performance analysis")

#     @validator('score')
#     def validate_score(cls, v):
#         """Post-processing validation for score range"""
#         if not 1 <= v <= 5:
#             raise ValueError("Score must be between 1 and 5")
#         return v


# class RepPerformanceScorecard(BaseModel):
#     """Model for the rep's performance evaluation"""
#     discovery_quality: PerformanceMetric = Field(
#         ...,
#         description="Evaluation of discovery questioning quality"
#     )
#     objection_handling: PerformanceMetric = Field(
#         ...,
#         description="Assessment of objection handling skills"
#     )
#     structure_and_clarity: PerformanceMetric = Field(
#         ...,
#         description="Evaluation of call structure and clarity"
#     )
#     call_to_action: PerformanceMetric = Field(
#         ...,
#         description="Assessment of call-to-action effectiveness"
#     )
#     responsiveness: PerformanceMetric = Field(
#         ...,
#         description="Evaluation of responsiveness during call"
#     )


# class VPInsights(BaseModel):
#     """Model for executive insights and forecast impact"""
#     buyer_intent_signals: str = Field(
#         ...,
#         description="Assessment of buyer's purchase intent signals"
#     )
#     deal_risk_factors: List[str] = Field(
#         ...,
#         description="List of identified deal risks"
#     )
#     rep_coachability: str = Field(
#         ...,
#         description="Evaluation of rep's coaching potential"
#     )
#     pipeline_forecast_impact: str = Field(
#         ...,
#         description="Forecast impact indicator (Green/Yellow/Red)"
#     )

#     @validator('pipeline_forecast_impact')
#     def validate_impact(cls, v):
#         """Post-processing validation for impact indicators"""
#         allowed = ["Green", "Yellow", "Red", "🟢", "🟡", "🔴"]  # Support both text and emoji

#         # Extract first word before hyphen/space if needed
#         if isinstance(v, str):
#             if ' - ' in v:
#                 base_color = v.split(' - ')[0].strip()
#                 if base_color in allowed:
#                     return base_color
#             elif v in allowed:
#                 return v

#         raise ValueError(f"Must be one of {allowed} or start with one of these followed by explanation")


# class AiSalesPerformanceReportWrapper(BaseModel):
#     """Complete sales performance report model"""
#     rep_performance_scorecard: RepPerformanceScorecard = Field(
#         ...,
#         description="Detailed performance evaluation"
#     )
#     vp_insights_and_forecast_impact: VPInsights = Field(
#         ...,
#         description="Executive insights and forecast analysis"
#     )
#     overall_coaching_feedback_for_rep: Optional[str] = Field(
#         None,
#         description="Comprehensive coaching feedback for the rep"
#     )


from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field, validator


# --------------------------
# Enums
# --------------------------

class ForecastImpact(str, Enum):
    GREEN = "🟢 Green"
    YELLOW = "🟡 Yellow"
    RED = "🔴 Red"


# --------------------------
# Core Components
# --------------------------

# class PerformanceMetric(BaseModel):
    


class SalesSkill(str, Enum):
    DISCOVERY = "Discovery Questioning"
    OBJECTION_HANDLING = "Objection Handling"
    STRUCTURE_AND_CLARITY = "Call Structure & Clarity"
    CALL_TO_ACTION = "Call to Action"
    RESPONSIVENESS = "Responsiveness"


class SkillAssessment(BaseModel):
    skill: SalesSkill = Field(..., description="Sales Skill Name (Discovery, Objection handling, structure and clarity, CTA, Responsiveness)")
    score: int = Field(..., description="Score from 1 (poor) to 5 (excellent)")
    analysis: str = Field(..., description="Detailed reasoning for the score")

    @validator('score')
    def validate_score(cls, v):
        if not 1 <= v <= 5:
            raise ValueError("Score must be between 1 and 5")
        return v


class RepPerformanceEvaluation(BaseModel):
    assessments: List[SkillAssessment] = Field(
        ..., description="List of sales skills and their evaluations"
    )


# --------------------------
# Executive Insight Section
# --------------------------

class VPInsights(BaseModel):
    buyer_intent_signals: str = Field(..., description="Summary of buyer's intent signals")
    deal_risk_factors: List[str] = Field(..., description="Risks or concerns in the deal")
    rep_coachability: str = Field(..., description="How coachable the rep is according to the system")
    pipeline_forecast_impact: ForecastImpact = Field(..., description="Forecast impact colored indicator")


# --------------------------
# Final Report Wrapper
# --------------------------

class AISalesCoachReport(BaseModel):
    rep_performance_evaluation: RepPerformanceEvaluation = Field(
        ..., description="Detailed evaluation of rep's performance"
    )
    vp_insights_and_forecast: VPInsights = Field(
        ..., description="Executive perspective and pipeline impact analysis"
    )
    coaching_feedback: Optional[str] = Field(
        None, description="Optional open-ended feedback for coaching the rep"
    )

    class Config:
        use_enum_values = True


class AiSalesPerformanceReportWrapper(BaseModel):
    ai_sales_coach_report: AISalesCoachReport = Field(
        ..., description="AI Sales coach report for detailed evaluation of reps performance and executive perspective and pipeline"
    )
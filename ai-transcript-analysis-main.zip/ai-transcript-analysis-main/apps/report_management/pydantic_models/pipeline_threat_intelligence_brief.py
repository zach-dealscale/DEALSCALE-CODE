from typing import List, Optional, Literal
from pydantic import BaseModel
from enum import Enum
from datetime import date


# Enums for standardized values
class UrgencyLevel(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class RiskLevel(str, Enum):
    RED = "🔴 High Risk"
    YELLOW = "🟡 Medium Risk"
    GREEN = "🟢 Low Risk"


class SalesStage(str, Enum):
    DISCOVERY = "Discovery"
    DEMO = "Demo"
    EVALUATION = "Evaluation"
    PROPOSAL = "Proposal"
    NEGOTIATION = "Negotiation"
    CLOSING = "Closing"


class PersonaType(str, Enum):
    ECONOMIC_BUYER = "Economic Buyer"
    TECHNICAL_BUYER = "Technical Buyer"
    CHAMPION = "Champion"
    BLOCKER = "Blocker"
    END_USER = "End User"


# Core models
class RiskAlert(BaseModel):
    risk: str
    trigger: str
    urgency: UrgencyLevel
    recommended_action: str


class EnablementPlay(BaseModel):
    strategic_trend: str
    immediate_move: str


class ObjectionPattern(BaseModel):
    sales_stage: SalesStage
    top_objection: str
    percent_of_calls: float  # 0-100
    risk_level: RiskLevel


class PersonaBlocker(BaseModel):
    persona: PersonaType
    common_objection: str
    frequency_percent: float  # 0-100


class EmergingObjection(BaseModel):
    new_objection: str
    stage: SalesStage
    persona: PersonaType
    frequency: Literal["Rare", "Emerging", "Frequent", "Critical"]


class PipelineThreatBrief(BaseModel):
    # Metadata
    period_analyzed: str  # "2023-01-01 to 2023-01-31"
    total_calls_analyzed: int
    deals_covered: int
    teams_covered: List[str]

    # Executive Summary
    top_immediate_threat: str
    fastest_recovery_lever: str
    emerging_risk: str

    # Risk Alerts
    risk_alerts: List[RiskAlert]
    risk_action_signal: str

    # Strategic Enablement Plays
    enablement_plays: List[EnablementPlay]
    enablement_action_signal: str

    # Top Objection Patterns
    objection_patterns: List[ObjectionPattern]
    objection_action_signal: str

    # Persona Blockers
    persona_blockers: List[PersonaBlocker]
    persona_action_signal: str

    # Emerging Objections
    emerging_objections: List[EmergingObjection]
    emerging_action_signal: str

    class Config:
        json_schema_extra = {
            "example": {
                "period_analyzed": "2023-11-01 to 2023-11-30",
                "total_calls_analyzed": 147,
                "deals_covered": 42,
                "teams_covered": ["Enterprise AE", "Commercial AE"],

                "top_immediate_threat": "Increasing budget scrutiny in Q4",
                "fastest_recovery_lever": "ROI calculator with 90-day payback framing",
                "emerging_risk": "New competitor undercutting prices by 20%",

                "risk_alerts": [
                    {
                        "risk": "Deals stalling in legal review",
                        "trigger": ">3 week delay from proposal to signature",
                        "urgency": "High",
                        "recommended_action": "Pre-packaged legal terms for common objections"
                    }
                ],
                "risk_action_signal": "Implement legal playbook by Dec 1 to reduce review time",

                "enablement_plays": [
                    {
                        "strategic_trend": "Buyers requesting executive sponsorship earlier",
                        "immediate_move": "Train AEs on executive engagement frameworks"
                    }
                ],
                "enablement_action_signal": "Schedule exec engagement training for next week",

                "objection_patterns": [
                    {
                        "sales_stage": "Proposal",
                        "top_objection": "Lack of clear ROI justification",
                        "percent_of_calls": 62.3,
                        "risk_level": "🔴 High Risk"
                    }
                ],
                "objection_action_signal": "Update ROI templates with industry benchmarks",

                "persona_blockers": [
                    {
                        "persona": "Economic Buyer",
                        "common_objection": "Budget not allocated until Q1",
                        "frequency_percent": 45.2
                    }
                ],
                "persona_action_signal": "Develop budget justification playbook for AEs",

                "emerging_objections": [
                    {
                        "new_objection": "Concerns about AI implementation complexity",
                        "stage": "Evaluation",
                        "persona": "Technical Buyer",
                        "frequency": "Emerging"
                    }
                ],
                "emerging_action_signal": "Create implementation roadmap assets"
            }
        }
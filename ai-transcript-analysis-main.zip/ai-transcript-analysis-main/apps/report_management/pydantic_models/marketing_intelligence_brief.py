from pydantic import BaseModel, Field, validator
from typing import List, Optional
from enum import Enum


class UrgencyLevel(str, Enum):
    high = "🔴 High"
    medium = "🟡 Medium"
    low = "⚪ Low"


class SignalStrength(str, Enum):
    weak = "Weak"
    medium = "Medium"
    strong = "Strong"


# === EXECUTIVE SUMMARY ===

class ExecutiveSummarySection(BaseModel):
    bold_insight: str = Field(..., description="Most important insight from call set that impacts messaging, positioning, or GTM strategy. Sharp, controversial, or clear pivot signal.")
    top_persona_shift: str = Field(..., description="Persona whose influence/mention increased significantly. Include % change and stage where they appear.")
    message_friction: str = Field(..., description="Common phrases or claims that triggered resistance, doubt, or eye-roll from buyers.")
    campaign_opportunity: str = Field(..., description="Clusters of buyer interest around topic that matches product capability - something team could turn into campaign now.")
    competitor_vulnerability: str = Field(..., description="Most repeated buyer complaint or frustration with known competitor. Flag if new or trending.")


# === PRIORITY PERSONA RADAR ===

class PersonaRadar(BaseModel):
    persona: str = Field(..., description="Persona name/title")
    emotional_triggers: str = Field(..., description="Fear, pressure, or goal surfaced in objections or questions")
    messaging_pitfalls: str = Field(..., description="Language that failed to land with them")
    campaign_hooks: str = Field(..., description="Short phrase that connects emotionally and strategically - usable in subject lines, ads, or deck headlines")
    urgency: UrgencyLevel = Field(..., description="Urgency level based on how often persona appeared or blocked progress")


class PersonaRadarSection(BaseModel):
    persona_radar: List[PersonaRadar] = Field(..., description="2-3 personas most frequently mentioned or influenced in calls. Will be adjusted to 2-3.")
    critical_move_persona: str = Field(..., description="Strategic recommendation for prioritizing specific persona in messaging")

    @validator('persona_radar')
    def ensure_two_to_three_personas(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(PersonaRadar(
                    persona=f"Persona {len(v) + 1}",
                    emotional_triggers="Emotional trigger",
                    messaging_pitfalls="Messaging pitfall",
                    campaign_hooks="Campaign hook",
                    urgency=UrgencyLevel.medium
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === INDUSTRY & SEGMENT INTELLIGENCE ===

class IndustryIntelligence(BaseModel):
    industry: str = Field(..., description="Industry/vertical name")
    trend_observed: str = Field(..., description="The shift observed (e.g., 'Move to async sales training', 'Security concerns rising')")
    messaging_opportunity: str = Field(..., description="How to reframe or reword message to fit this trend")
    strategic_play: str = Field(..., description="Content, nurture, or co-marketing moves for this quarter")


class IndustryIntelligenceSection(BaseModel):
    industry_intelligence: List[IndustryIntelligence] = Field(..., description="2-3 verticals where clear buyer trends or objections emerged. Will be adjusted to 2-3.")
    critical_move_industry: str = Field(..., description="Strategic recommendation for industry/vertical alignment")

    @validator('industry_intelligence')
    def ensure_two_to_three_industries(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(IndustryIntelligence(
                    industry=f"Industry {len(v) + 1}",
                    trend_observed="Trend observed",
                    messaging_opportunity="Messaging opportunity",
                    strategic_play="Strategic play"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === CAMPAIGN ACTIVATION MAP ===

class CampaignActivation(BaseModel):
    insight: str = Field(..., description="Short version of the friction or pattern from calls")
    recommended_campaign: str = Field(..., description="Logical program name (e.g., 'Adoption Playbook Drip', 'Competitive Winback')")
    segment: str = Field(..., description="Who it targets")
    launch_timing: str = Field(..., description="Timeline - Now, Q3 Week 1, etc.")
    format: str = Field(..., description="Webinar, PDF Toolkit, Email Nurture, Landing Page, Paid Ads, etc.")


class CampaignActivationSection(BaseModel):
    campaign_activations: List[CampaignActivation] = Field(..., description="Top buyer insights matched to specific campaign opportunities. Will be adjusted to 3-4.")
    trigger_now_campaign: str = Field(..., description="Immediate campaign recommendation backed by field mentions and urgent buyer signals")

    @validator('campaign_activations')
    def ensure_three_to_four_campaigns(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(CampaignActivation(
                    insight=f"Insight {len(v) + 1}",
                    recommended_campaign=f"Campaign {len(v) + 1}",
                    segment="Target segment",
                    launch_timing="Timing",
                    format="Format"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === MESSAGING RESONANCE HEATMAP ===

class MessageResonance(BaseModel):
    message_theme: str = Field(..., description="Message theme currently used by marketing or sales")
    buyer_reaction: str = Field(..., description="Quote or tone (skeptical, confused, curious, excited)")
    signal_strength: SignalStrength = Field(..., description="Based on frequency and response intensity")
    action: str = Field(..., description="'Reframe as...', 'Double down', or 'Deprioritize'")


class MessageResonanceSection(BaseModel):
    message_resonance: List[MessageResonance] = Field(..., description="3-4 message themes with buyer reactions. Will be adjusted to 3-4.")
    reframe_guidance: str = Field(..., description="Guidance for actual messaging updates in decks, ads, and website copy")

    @validator('message_resonance')
    def ensure_three_to_four_messages(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(MessageResonance(
                    message_theme=f"Message theme {len(v) + 1}",
                    buyer_reaction="Buyer reaction",
                    signal_strength=SignalStrength.medium,
                    action="Action to take"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === HERO STORYLINE BRIEFS ===

class HeroStoryline(BaseModel):
    narrative: str = Field(..., description="The before/after story (e.g., 'From chaos to clarity', 'Legacy vendor lock-in')")
    tension_resolved: str = Field(..., description="What pain or fear does this resolve")
    campaign_ready: bool = Field(..., description="Whether storyline is ready for campaign use")
    next_move: str = Field(..., description="Build asset, collect case study, test headline, etc.")


class HeroStorylineSection(BaseModel):
    hero_storylines: List[HeroStoryline] = Field(..., description="2-3 storylines from buyer conversations with emotional resonance + product alignment. Will be adjusted to 2-3.")
    hero_pick: str = Field(..., description="Priority storyline recommendation for Q3 thought leadership")

    @validator('hero_storylines')
    def ensure_two_to_three_storylines(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(HeroStoryline(
                    narrative=f"Storyline narrative {len(v) + 1}",
                    tension_resolved="Tension resolved",
                    campaign_ready=False,
                    next_move="Next move"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === BUYER FRICTION & RISK SIGNALS ===

class BuyerFriction(BaseModel):
    funnel_stage: str = Field(..., description="Stage where friction occurred (Discovery, Demo, Proposal)")
    friction_point: str = Field(..., description="Quote or paraphrased hesitation")
    persona: str = Field(..., description="Persona affected")
    strategic_risk: str = Field(..., description="Risk category (e.g., 'Differentiation failed', 'Lack of proof', 'Unclear pricing')")
    impact_score: UrgencyLevel = Field(..., description="Impact level of this friction")


class BuyerFrictionSection(BaseModel):
    buyer_frictions: List[BuyerFriction] = Field(..., description="Points where deals slowed, stalled, or risked churn due to messaging/perception issues. Will be adjusted to 3-5.")
    strategic_fixes: List[str] = Field(..., description="Action items to drive bottom-funnel content and sales/marketing alignment work. Will be adjusted to 2-4.")

    @validator('buyer_frictions')
    def ensure_three_to_five_frictions(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(BuyerFriction(
                    funnel_stage="Discovery",
                    friction_point=f"Friction point {len(v) + 1}",
                    persona="Persona",
                    strategic_risk="Strategic risk",
                    impact_score=UrgencyLevel.medium
                ))
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('strategic_fixes')
    def ensure_two_to_four_fixes(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Strategic fix {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === FULL MARKETING INTELLIGENCE BRIEF ===

class MarketingIntelligenceBrief(BaseModel):
    # Metadata
    version: str = Field(..., description="Date range or version identifier (e.g., 'July 1-31, 2025')")
    calls_analyzed: int = Field(..., description="Number of calls analyzed")
    deals_covered: int = Field(..., description="Number of deals covered")
    target_segments: List[str] = Field(..., description="List of target segments")
    primary_owner: str = Field(default="Marketing Strategy & Demand Generation", description="Primary owner of the brief")
    refresh_cadence: str = Field(default="Monthly", description="How often the brief is refreshed")
    
    # Report sections
    executive_summary: ExecutiveSummarySection
    persona_radar: PersonaRadarSection
    industry_intelligence: IndustryIntelligenceSection
    campaign_activation: CampaignActivationSection
    message_resonance: MessageResonanceSection
    hero_storyline: HeroStorylineSection
    buyer_friction: BuyerFrictionSection
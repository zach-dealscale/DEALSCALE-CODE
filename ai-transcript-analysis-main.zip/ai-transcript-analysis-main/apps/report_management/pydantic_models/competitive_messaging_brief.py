from pydantic import BaseModel, Field, validator
from typing import List, Optional, Literal


# === REPORT HEADER ===

class ReportHeader(BaseModel):
    date_range_analyzed: str = Field(..., description="Date range of analyzed calls (e.g., 'July–August 2025')")
    calls_processed: int = Field(..., description="Total number of calls processed")
    deals_involving_competitors: int = Field(..., description="Number of deals mentioning competitors")
    primary_competitors_mentioned: str = Field(..., description="Top 3-5 competitors mentioned (comma-separated)")


# === EXECUTIVE SNAPSHOT ===

class ExecutiveSnapshot(BaseModel):
    most_vulnerable_competitor: str = Field(..., description="Competitor with most buyer pushback and specific weakness")
    most_common_complaint: str = Field(..., description="Most repeated objection or negative theme with frequency data")
    positioning_opportunity: str = Field(..., description="Area where buyers are confused about competitor messaging")
    loss_risk_signal: str = Field(..., description="Positive competitor mentions in late-stage deals")
    suggested_offensive_play: str = Field(..., description="Recommended campaign or content move to exploit weaknesses")


# === COMPETITOR BREAKDOWN ===

class CompetitorBreakdown(BaseModel):
    competitor: str = Field(..., description="Competitor name")
    buyer_complaint_quote: str = Field(..., description="Representative buyer quote with negative sentiment")
    objection_theme: str = Field(..., description="Category of objection (e.g., 'pricing', 'onboarding', 'lack of fit')")
    opportunity_for_us: str = Field(..., description="Specific messaging or campaign angle to exploit this weakness")

class CompetitorBreakdownTable(BaseModel):
    competitor_breakdowns: List[CompetitorBreakdown] = Field(..., description="3-5 competitor analyses. Will be adjusted to 3-5.")

    @validator('competitor_breakdowns')
    def ensure_competitor_breakdowns(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(CompetitorBreakdown(
                    competitor=f"Competitor {len(v) + 1}",
                    buyer_complaint_quote=f"Buyer complaint quote {len(v) + 1}",
                    objection_theme=f"Objection theme {len(v) + 1}",
                    opportunity_for_us=f"Opportunity {len(v) + 1}"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === HIGH-LEVERAGE CAMPAIGN HOOKS ===

class CampaignHook(BaseModel):
    friction_point: str = Field(..., description="Common buyer friction point from transcripts")
    campaign_hook: str = Field(..., description="Marketing-ready campaign hook (short and punchy)")
    suggested_format: str = Field(..., description="Recommended format (e.g., 'retargeting ad', 'comparison page')")
    target_persona: str = Field(..., description="Persona most likely to care about this friction point")

class HighLeverageCampaignHooks(BaseModel):
    campaign_hooks: List[CampaignHook] = Field(..., description="4-6 campaign hooks. Will be adjusted to 4-6.")
    priority_campaign: str = Field(..., description="Top priority campaign with alignment percentage and reasoning")

    @validator('campaign_hooks')
    def ensure_campaign_hooks(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(CampaignHook(
                    friction_point=f"Friction point {len(v) + 1}",
                    campaign_hook=f"Campaign hook {len(v) + 1}",
                    suggested_format=f"Format {len(v) + 1}",
                    target_persona=f"Persona {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === WHERE COMPETITOR MESSAGING BREAKS ===

class CompetitorMessagingBreak(BaseModel):
    claim_competitors_use: str = Field(..., description="Marketing claim competitors make")
    buyer_reaction: str = Field(..., description="What buyers actually said in response")
    trust_level: Literal["Low", "Mixed", "Skeptical"] = Field(..., description="Buyer trust level in the claim")
    suggested_counter_move: str = Field(..., description="Recommended messaging or campaign counter-strategy")

class CompetitorMessagingBreaks(BaseModel):
    messaging_breaks: List[CompetitorMessagingBreak] = Field(..., description="3-5 messaging breaks. Will be adjusted to 3-5.")
    callout_warning: str = Field(..., description="Warning callout about specific claims flagged as fluff")

    @validator('messaging_breaks')
    def ensure_messaging_breaks(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(CompetitorMessagingBreak(
                    claim_competitors_use=f"Claim {len(v) + 1}",
                    buyer_reaction=f"Buyer reaction {len(v) + 1}",
                    trust_level="Mixed",
                    suggested_counter_move=f"Counter move {len(v) + 1}"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === AT-RISK DEALS ===

class AtRiskDeal(BaseModel):
    deal_name: str = Field(..., description="Deal or company name")
    stage: str = Field(..., description="Deal stage (e.g., 'Evaluation', 'Proposal')")
    competitor_mentioned: str = Field(..., description="Competitor gaining momentum")
    persona_influenced: str = Field(..., description="Buyer persona influenced by competitor")
    risk_level: Literal["🔴 High", "🟡 Medium", "🟢 Low"] = Field(..., description="Risk level with emoji")
    counter_play: str = Field(..., description="Recommended content-driven counter action")

class AtRiskDeals(BaseModel):
    at_risk_deals: List[AtRiskDeal] = Field(..., description="2-3 at-risk deals. Will be adjusted to 2-3.")
    strategic_move: str = Field(..., description="Overall strategic recommendation for at-risk deals")

    @validator('at_risk_deals')
    def ensure_at_risk_deals(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(AtRiskDeal(
                    deal_name=f"Deal {len(v) + 1}",
                    stage="Evaluation",
                    competitor_mentioned=f"Competitor {len(v) + 1}",
                    persona_influenced=f"Persona {len(v) + 1}",
                    risk_level="🟡 Medium",
                    counter_play=f"Counter play {len(v) + 1}"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v


# === PLAYBOOK RECOMMENDATIONS ===

class PlaybookRecommendations(BaseModel):
    offensive_moves: List[str] = Field(..., description="2-3 offensive campaign/content recommendations. Will be adjusted to 2-3.")
    defensive_pivots: List[str] = Field(..., description="1-2 defensive messaging pivots. Will be adjusted to 1-2.")

    @validator('offensive_moves')
    def ensure_offensive_moves(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Offensive move {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v

    @validator('defensive_pivots')
    def ensure_defensive_pivots(cls, v):
        if len(v) < 1:
            v.append("Defensive pivot 1")
        elif len(v) > 2:
            v = v[:2]
        return v


# === FULL COMPETITIVE MESSAGING BRIEF ===

class CompetitiveMessagingBrief(BaseModel):
    header: ReportHeader
    executive_snapshot: ExecutiveSnapshot
    competitor_breakdown: CompetitorBreakdownTable
    campaign_hooks: HighLeverageCampaignHooks
    messaging_breaks: CompetitorMessagingBreaks
    at_risk_deals: AtRiskDeals
    playbook_recommendations: PlaybookRecommendations
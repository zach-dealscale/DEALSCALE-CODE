from datetime import date
from typing import List, Optional, Literal
from pydantic import BaseModel, Field,validator


class DealStage(BaseModel):
    stage: str = Field(..., description="Current stage of the deal")
    justification: str = Field(..., description="Reason for this stage classification")

class UrgencyType(BaseModel):
    type: str = Field(..., description="Type of urgency identified")
    evidence: str = Field(..., description="Supporting evidence for the urgency type")

class CloseWindowStep(BaseModel):
    step: str = Field(..., description="Description of the step in the closing process")
    time_estimate_weeks: int = Field(..., description="Estimated duration in weeks")

class PredictedCloseWindow(BaseModel):
    steps: List[CloseWindowStep] = Field(..., description="Breakdown of steps to close")
    total_estimated_weeks: int = Field(..., description="Total estimated weeks to close")
    estimated_close_date: str = Field(..., description="Projected close date in YYYY-MM-DD format")
    assumptions: str = Field(..., description="Assumptions made in the estimate")

class ConfidenceLevel(BaseModel):
    level: str = Field(..., description="Confidence level in deal closing")
    justification: str = Field(..., description="Reason for the confidence level")

class DealAnalysis(BaseModel):
    deal_stage: DealStage = Field(..., description="Current stage of the sales deal")
    urgency_type: UrgencyType = Field(..., description="Type and evidence of urgency")
    top_signals: List[str] = Field(..., description="Key positive signals from buyer")
    predicted_close_window_weeks: PredictedCloseWindow = Field(
        ...,
        description="Detailed close timeline prediction"
    )
    blocking_factors: List[str] = Field(..., description="Current obstacles to closing")
    confidence_level: ConfidenceLevel = Field(..., description="Deal confidence assessment")

class DealAnalysisWrapper(BaseModel):
    """Wrapper model for the deal analysis"""
    deal_analysis: DealAnalysis
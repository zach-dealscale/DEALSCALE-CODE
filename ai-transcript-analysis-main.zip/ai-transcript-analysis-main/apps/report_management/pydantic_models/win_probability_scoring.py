from typing import Optional
from enum import Enum
from pydantic import BaseModel, Field
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field

class RiskGrade(str, Enum):
    LIKELY_TO_WIN = "🔵 80–100: Likely to Win"
    MEDIUM_RISK = "🟡 60–79: Medium Risk"
class DealType(str, Enum):
    PLATFORM = "Platform"
    USE_CASE = "Use Case"
    EMPLOYEE_ENGAGEMENT = "Employee Engagement Platform"
    OTHER = "Other"


class Stage(str, Enum):
    CLOSED_WON = "Closed-Won"

class ScoreCategory(str, Enum):
    PAIN_IDENTIFIED = "Pain Identified"
    BUDGET_DISCUSSED = "Budget Discussed"
    DECISION_MAKER_PRESENT = "Decision Maker Present"
    TIMELINE_MENTIONED = "Timeline Mentioned"
    STAKEHOLDER_ALIGNMENT = "Stakeholder Alignment"
    SOLUTION_FIT_CLARITY = "Solution Fit Clarity"
    OBJECTIONS_IMPACT = "Objections Impact"
    OBJECTION_HANDLING = "Objection Handling"


class Score(BaseModel):
    category: ScoreCategory = Field(..., description="The category being scored")
    points: int = Field(..., description="Points assigned to this category")
    reasoning: str = Field(..., description="Explanation for the assigned score")


# Risk Assessment
class RiskAssessment(BaseModel):
    strengths_list: List[str] = Field(..., description="Key strengths of the deal")
    gaps_list: List[str] = Field(..., description="Areas that need improvement or attention")
    risk_factors_list: List[str] = Field(..., description="Specific risk factors identified")


class CriteriaCategory(str, Enum):
    PAIN_IDENTIFIED = "Pain Identified"
    BUDGET_DISCUSSED = "Budget Discussed"
    DECISION_MAKER_PRESENT = "Decision Maker Present"
    TIMELINE_MENTIONED = "Timeline Mentioned"
    STAKEHOLDER_ALIGNMENT = "Stakeholder Alignment"
    SOLUTION_FIT_CLARITY = "Solution Fit Clarity"

class CriteriaAssessment(BaseModel):
    category: CriteriaCategory
    status: bool
    details: str


class ObjectionAssessment(BaseModel):
    objection_list: List[str]
    objection_count: int
    objection_handling_score: int
    objection_handling_details: str

# Enums
class RiskGrade(str, Enum):
    LIKELY_TO_WIN = "🔵 80–100: Likely to Win"
    MEDIUM_RISK = "🟡 60–79: Medium Risk"

class DetailedCriteriaAssessment(BaseModel):
    criteria_assessment: List[CriteriaAssessment] = Field(
        ..., description="List of criteria evaluations"
    )
    objection_assessment: ObjectionAssessment = Field(
        ..., description="Objection details including count, list, handling score and detail"
    )




# Buyer Sentiment
class BuyerSentimentAnalysis(BaseModel):
    overall_tone: str
    engagement_level: str
    hesitations_list: List[str]
    key_quotes_list: List[str]
    caution_flags_list: List[str]



class ClientInformation(BaseModel):
    client_name: str = Field(..., description="Name of the client/prospect")
    representative_name: str = Field(..., description="Name of the sales representative")
    call_date: Optional[str] = Field(None, description="Date of the sales call in YYYY-MM-DD format")
    employee_count: str = Field(..., description="Employee count information (e.g., '500+')")

class DealInformation(BaseModel):
    deal_type: DealType = Field(..., description="Specific type of deal")
    stage: Stage = Field(..., description="Stage of the deal")
    deal_health_score: int = Field(..., description="Overall deal score (0–100)")
    risk_grade: RiskGrade = Field(..., description="Risk grade of the deal")



class WinProbabilityScoringReport(BaseModel):
    client_information: ClientInformation = Field(..., description="Client personal and company Details including representative of the call")
    deal_information: DealInformation = Field(..., description="Summary of the deal information")

    score_breakdown: List[Score] = Field(..., description="Detailed scoring breakdown")
    risk_assessment: RiskAssessment = Field(..., description="Strengths and risk factors of the deal")

    criteria_assessment: DetailedCriteriaAssessment = Field(..., description="Detailed evaluation of criteria")
    buyer_sentiment: BuyerSentimentAnalysis = Field(..., description="Buyer tone and sentiment analysis")
    next_steps_list: List[str] = Field(..., description="Clear next steps")

class DealScorecardWrapper(BaseModel):
    win_probability_scoring_report: WinProbabilityScoringReport = Field(
        ..., description = "A report to describe detailed scoring about win probability from sales transcript"
    )
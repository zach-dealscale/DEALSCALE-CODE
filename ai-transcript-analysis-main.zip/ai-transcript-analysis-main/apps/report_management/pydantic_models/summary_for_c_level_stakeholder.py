from datetime import date
from typing import List, Optional, Literal
from pydantic import BaseModel, Field,validator

class SummaryCLevelStakeholdersWrapper(BaseModel):
    """Model for C-level executive summary document"""
    client_business_challenge: str = Field(
        ...,
        description="Concise summary of the client's core business challenges and pain points",
        example="High employee turnover (25% annually) and low engagement scores impacting productivity"
    )

    proposed_solution: str = Field(
        ...,
        description="Overview of the proposed solution and strategic fit",
        example="Terrybury engagement platform with recognition programs and analytics"
    )

    expected_business_impact: str = Field(
        ...,
        description="Quantified business outcomes and ROI projections",
        example="Projected 40% reduction in turnover, saving $1.2M annually in hiring costs"
    )

    cost_of_inaction: str = Field(
        ...,
        description="Risk analysis of maintaining status quo",
        example="Continuing current trajectory could result in $3M+ in annual turnover costs"
    )

    recommended_next_step: str = Field(
        ...,
        description="Clear, time-bound action for decision makers",
        example="Executive demo scheduled for May 15th with CPO and CFO"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "client_business_challenge": "Declining employee engagement (current score: 58/100) and lack of recognition programs",
                "proposed_solution": "Integrated engagement platform with peer recognition, service awards, and real-time analytics",
                "expected_business_impact": "30% improvement in engagement scores within 6 months, 15% productivity gain",
                "cost_of_inaction": "Top performers likely to leave without recognition, risking $2M+ in replacement costs",
                "recommended_next_step": "Approval of pilot program by May 30 for July 1 implementation"
            }
        }

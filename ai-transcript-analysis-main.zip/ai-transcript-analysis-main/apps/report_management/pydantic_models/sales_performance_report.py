from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === SCORECARD SECTIONS ===

class ScorecardSection(BaseModel):
    section_name: str = Field(..., description="Section name (e.g., 'Opening & Discovery Effectiveness')")
    score: int = Field(..., description="Score from 1-10", ge=1, le=10)
    observations: List[str] = Field(..., description="Exactly 4 bullet points: 3 strengths + 1 improvement. Will be adjusted to exactly 4.  (Add real sentence example from transcript in parenthesis in 1-2 bullet points)")

    @validator('observations')
    def ensure_four_observations(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(f"Observation point {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

class RepPerformanceScorecardSection(BaseModel):
    sections: List[ScorecardSection] = Field(..., description="Exactly 5 scorecard sections. Will be adjusted to exactly 5.")

    @validator('sections')
    def ensure_five_sections(cls, v):
        default_sections = [
            "Opening & Discovery Effectiveness",
            "Objection Handling & Responsiveness", 
            "Call Structure & Clarity",
            "Trust Building & Solution Alignment",
            "Call-to-Action Strength"
        ]
        
        if len(v) < 5:
            while len(v) < 5:
                section_index = len(v)
                section_name = default_sections[section_index] if section_index < len(default_sections) else f"Section {section_index + 1}"
                v.append(ScorecardSection(
                    section_name=section_name,
                    score=6,
                    observations=[
                        f"Positive observation 1 for {section_name}",
                        f"Positive observation 2 for {section_name}", 
                        f"Positive observation 3 for {section_name}",
                        f"Could have improved {section_name.lower()}"
                    ]
                ))
        elif len(v) > 5:
            v = v[:5]
        return v

class OverallCallScoreSection(BaseModel):
    overall_score: float = Field(..., description="Average score of all 5 sections (calculated)")
    performance_tag: str = Field(..., description="Performance tag based on score (e.g., 'Good — Strong Foundation')")

class CoachingFeedbackSection(BaseModel):
    rep_name: str = Field(..., description="Rep's name to address them directly")
    feedback_paragraph: str = Field(..., description="2-3 sentences addressed directly to rep by name with praise, biggest improvement opportunity, and next step")

class VPInsightsSection(BaseModel):
    buyer_intent_signals: List[str] = Field(..., description="2-4 bullets about buyer behavior, buying stage, urgency. Will be adjusted to 2-4.")
    deal_risk_factors: List[str] = Field(..., description="2-4 bullets about pipeline-blocking gaps. Will be adjusted to 2-4.")
    rep_coachability: List[str] = Field(..., description="2-3 bullets about rep strengths and coaching opportunities. Will be adjusted to 2-3.")
    pipeline_forecast_impact: str = Field(..., description="Forecast decision with justification (Remove/Best Case/Medium Confidence/Commit)")
    pipeline_forecast_impact_reasoning: str = Field(..., description="Reasoning for the forecast decision")

    @validator('buyer_intent_signals')
    def ensure_buyer_signals(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Buyer intent signal {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('deal_risk_factors')
    def ensure_risk_factors(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Risk factor {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('rep_coachability')
    def ensure_coachability(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Coachability point {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v


# === FULL SALES PERFORMANCE COACH REPORT ===

class SalesPerformanceCoachReport(BaseModel):
    rep_performance_scorecard: RepPerformanceScorecardSection
    overall_call_score: OverallCallScoreSection
    coaching_feedback: CoachingFeedbackSection
    vp_insights: VPInsightsSection
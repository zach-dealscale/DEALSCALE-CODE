from datetime import date
from typing import List, Optional, Literal
from pydantic import BaseModel, Field,validator


class Objection(BaseModel):
    """Model for tracking individual sales objections"""
    quote: str = Field(
        ...,
        description="The exact objection phrasing from the prospect",
        example="It sounds expensive, and we're already over budget this quarter."
    )

    category: Literal["Pricing", "Competition", "Timing", "Features", "Trust", "Other"] = Field(
        ...,
        description="Classification of the objection type"
    )

    resolved: bool = Field(
        ...,
        description="Whether the objection was successfully addressed"
    )

    rep_response_quality: int = Field(
        ...,
        description="Rating (1-5) of how well the rep handled the objection, where 1=Poor and 5=Excellent",
        example=3
    )

    @validator('rep_response_quality')
    def validate_quality(cls, v):
        """Post-processing validation for response quality"""
        if not 1 <= v <= 5:
            raise ValueError("Response quality must be between 1-5")
        return v


class ObjectionTrackerWrapper(BaseModel):
    """Top-level model for tracking all sales objections"""
    objections: List[Objection] = Field(
        ...,
        description="List of all objections raised during the sales process"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "objections": [
                    {
                        "quote": "It sounds expensive...",
                        "category": "Pricing",
                        "resolved": False,
                        "rep_response_quality": 1
                    },
                    {
                        "quote": "We're also looking at Competitor X...",
                        "category": "Competition",
                        "resolved": True,
                        "rep_response_quality": 2
                    }
                ]
            }
        }
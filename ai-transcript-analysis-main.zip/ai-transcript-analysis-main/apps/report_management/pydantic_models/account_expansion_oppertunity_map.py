from pydantic import BaseModel, Field, validator
from typing import List, Optional
from enum import Enum


# === ENUMS FOR STRUCTURED VALUES ===

class ExpansionType(str, Enum):
    UPSELL = "Upsell"
    CROSS_SELL = "Cross-sell"
    ROLLOUT = "Rollout"
    SEAT_GROWTH = "Seat Growth"
    ADD_ON_FEATURE = "Add-on Feature"
    NEW_ROLLOUT = "New Rollout"

class PriorityLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

class UrgencyLevel(str, Enum):
    IMMEDIATE = "🔴 Immediate"
    NEAR_TERM = "🟡 Near-Term"
    PASSIVE = "⚪ Passive"

class InfluenceLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    MEDIUM_HIGH = "Medium–High"

class ChampionStatus(str, Enum):
    YES = "Yes"
    NO = "No"
    UNKNOWN = "Unknown"


# === HEADER AND CALL SUMMARY SECTION ===

class HeaderCallSummarySection(BaseModel):
    company_name: str = Field(..., description="Company name")
    customer_contacts: List[str] = Field(..., description="List of customer contacts mentioned on call. Will be adjusted to 1-3.")
    call_date: str = Field(..., description="Date of the call")
    call_summary: str = Field(..., description="2-3 sentence context about call purpose, what surfaced, momentum/risks detected")

    @validator('customer_contacts')
    def ensure_contacts(cls, v):
        if len(v) < 1:
            v.append("Customer contact name")
        elif len(v) > 3:
            v = v[:3]
        return v


# === DETECTED EXPANSION SIGNALS SECTION ===

class ExpansionSignal(BaseModel):
    signal_description: str = Field(..., description="Description of the expansion signal detected")
    expansion_type: ExpansionType = Field(..., description="Type of expansion opportunity")
    priority: PriorityLevel = Field(..., description="Priority level: High, Medium, or Low")
    supporting_quote: str = Field(..., description="Supporting quote from customer conversation")
    urgency: UrgencyLevel = Field(..., description="Urgency level with emoji indicator")

class DetectedExpansionSignalsSection(BaseModel):
    expansion_signals: List[ExpansionSignal] = Field(..., description="3-6 expansion signals detected. Will be adjusted to 3-6.")
    critical_move: str = Field(..., description="Strategic recommendation based on top 1-2 expansion signals")

    @validator('expansion_signals')
    def ensure_signals(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(ExpansionSignal(
                    signal_description=f"Expansion signal {len(v) + 1}",
                    expansion_type=ExpansionType.UPSELL,
                    priority=PriorityLevel.MEDIUM,
                    supporting_quote=f"Supporting quote {len(v) + 1}",
                    urgency=UrgencyLevel.NEAR_TERM
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === NEW POTENTIAL STAKEHOLDERS SECTION ===

class PotentialStakeholder(BaseModel):
    stakeholder_name: str = Field(..., description="Stakeholder name or title")
    role_title: str = Field(..., description="Role/title of stakeholder")
    influence_level: InfluenceLevel = Field(..., description="Influence level assessment")
    expansion_champion: ChampionStatus = Field(..., description="Expansion champion potential: Yes/No/Unknown")
    next_step: str = Field(..., description="Next step for stakeholder engagement")

class NewPotentialStakeholdersSection(BaseModel):
    potential_stakeholders: List[PotentialStakeholder] = Field(..., description="1-4 potential stakeholders. Will be adjusted to 1-4.")
    critical_move: str = Field(..., description="Plan for activating top champions into expansion motions")

    @validator('potential_stakeholders')
    def ensure_stakeholders(cls, v):
        if len(v) < 1:
            v.append(PotentialStakeholder(
                stakeholder_name="Stakeholder name",
                role_title="Role/title",
                influence_level=InfluenceLevel.MEDIUM,
                expansion_champion=ChampionStatus.UNKNOWN,
                next_step="Next step for engagement"
            ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === EXPANSION NEXT STEPS SECTION ===

class ExpansionNextStep(BaseModel):
    action_item: str = Field(..., description="Specific action item to be taken")
    owner: str = Field(..., description="Owner of the action (AM/CSM name)")
    due_date: str = Field(..., description="Due date for completion")
    linked_expansion_signal: str = Field(..., description="Which expansion signal this action is linked to")

class ExpansionNextStepsSection(BaseModel):
    next_steps: List[ExpansionNextStep] = Field(..., description="3-6 expansion next steps. Will be adjusted to 3-6.")

    @validator('next_steps')
    def ensure_next_steps(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(ExpansionNextStep(
                    action_item=f"Action item {len(v) + 1}",
                    owner="AM/CSM",
                    due_date="[Insert Date]",
                    linked_expansion_signal=f"Signal {len(v) + 1}"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === EXPANSION TIMELINE LEVERS SECTION ===

class TimelineLever(BaseModel):
    event_deadline: str = Field(..., description="Event or deadline description")
    impact_on_expansion: str = Field(..., description="Impact on expansion opportunity")
    urgency_level: PriorityLevel = Field(..., description="Urgency level: High/Medium/Low")

class ExpansionTimelineLeversSection(BaseModel):
    timeline_levers: List[TimelineLever] = Field(..., description="2-4 timeline levers. Will be adjusted to 2-4.")
    critical_move: str = Field(..., description="Plan to align expansion push with timeline pressure points")

    @validator('timeline_levers')
    def ensure_timeline_levers(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(TimelineLever(
                    event_deadline=f"Event/deadline {len(v) + 1}",
                    impact_on_expansion=f"Impact on expansion {len(v) + 1}",
                    urgency_level=PriorityLevel.MEDIUM
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === STRATEGIC NOTES / WATCHOUTS SECTION ===

class StrategicWatchout(BaseModel):
    observation: str = Field(..., description="Strategic observation or watchout")
    risk_type: str = Field(..., description="Type of risk (Political, Commercial, Technical, etc.)")
    impact: str = Field(..., description="Impact level or description")
    recommendation: str = Field(..., description="Recommended action or mitigation")

class StrategicNotesWatchoutsSection(BaseModel):
    strategic_watchouts: List[StrategicWatchout] = Field(..., description="2-4 strategic watchouts. Will be adjusted to 2-4.")
    critical_move: str = Field(..., description="Recommended mitigation steps for major risks detected")

    @validator('strategic_watchouts')
    def ensure_watchouts(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(StrategicWatchout(
                    observation=f"Strategic observation {len(v) + 1}",
                    risk_type="Risk type",
                    impact="Impact level",
                    recommendation=f"Recommendation {len(v) + 1}"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === FULL ACCOUNT EXPANSION OPPORTUNITY MAP ===

class AccountExpansionOpportunityMap(BaseModel):
    header_call_summary: HeaderCallSummarySection
    detected_expansion_signals: DetectedExpansionSignalsSection
    new_potential_stakeholders: NewPotentialStakeholdersSection
    expansion_next_steps: ExpansionNextStepsSection
    expansion_timeline_levers: ExpansionTimelineLeversSection
    strategic_notes_watchouts: StrategicNotesWatchoutsSection
from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === ACCOUNT SUMMARY SECTION ===

class AccountSummarySection(BaseModel):
    customer_name: str = Field(..., description="Customer company name")
    primary_contact: str = Field(..., description="Champion/main buyer name and role (e.g., 'Christina, Culture & Engagement Lead')")
    industry: str = Field(..., description="Industry sector (e.g., 'Retail (Fashion/Apparel)', 'Foodservice Distribution')")
    company_size: str = Field(..., description="Employee count or revenue description (e.g., '~16,000 global employees', '~74,000 global employees')")
    location: str = Field(..., description="Headquarters or region (e.g., 'Headquartered in Montreal, Canada')")
    one_line_description: str = Field(..., description="One-line strategic description of customer and mandate")


# === DEAL OVERVIEW SECTION ===

class DealOverviewSection(BaseModel):
    current_deal_stage: str = Field(..., description="Current pipeline stage (e.g., 'Initial Discovery Complete', 'Early Discovery')")
    key_use_cases: List[str] = Field(..., description="3 key use cases identified. Will be adjusted to exactly 3.")
    strategic_outcomes: List[str] = Field(..., description="2-4 strategic outcomes they want. Will be adjusted to 2-4.")
    priority_statement: str = Field(..., description="Priority quote statement in format: 'Customer is prioritizing [goal] by [timeline] to [driver].'")

    @validator('key_use_cases')
    def ensure_three_use_cases(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Use case {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v

    @validator('strategic_outcomes')
    def ensure_outcomes(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Strategic outcome {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === RISK FACTORS SECTION ===

class RiskFactor(BaseModel):
    risk_description: str = Field(..., description="Risk description (e.g., 'Single Point of Contact Risk: Cassandra is the only person managing recognition')")
    mitigation_strategy: str = Field(..., description="Mitigation strategy starting with 'Mitigation:' (e.g., 'Provide tailored recaps, offer co-selling material')")

class RiskFactorsSection(BaseModel):
    risk_factors: List[RiskFactor] = Field(..., description="2-4 risk factors with mitigation strategies. Will be adjusted to 2-4.")

    @validator('risk_factors')
    def ensure_risk_factors(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(RiskFactor(
                    risk_description=f"Risk factor {len(v) + 1}",
                    mitigation_strategy=f"Mitigation strategy {len(v) + 1}"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === INTERNAL WIN STRATEGY SECTION ===

class InternalWinStrategySection(BaseModel):
    win_thesis: str = Field(..., description="Core win requirement statement: 'In order to win, we must [core requirement].'")
    key_strengths: List[str] = Field(..., description="2-4 key strengths to leverage. Will be adjusted to 2-4.")
    areas_to_fortify: List[str] = Field(..., description="2-4 areas that need strengthening. Will be adjusted to 2-4.")
    competitive_differentiators: List[str] = Field(..., description="2-4 competitive differentiators. Will be adjusted to 2-4.")

    @validator('key_strengths')
    def ensure_strengths(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Key strength {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('areas_to_fortify')
    def ensure_fortify_areas(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Area to fortify {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('competitive_differentiators')
    def ensure_differentiators(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Competitive differentiator {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === BRIEF METADATA SECTION ===

class BriefMetadataSection(BaseModel):
    prepared_by: str = Field(..., description="Name of person who prepared the brief")
    preparation_date: str = Field(..., description="Date brief was prepared (e.g., 'August 2, 2025')")
    confidentiality_notice: str = Field(
        "This document is internal-only. Keep strategic notes, concerns, and next steps candid to ensure full-team alignment toward winning this deal.",
        description="Confidentiality statement"
    )


# === FULL INTERNAL DEAL TEAM BRIEF ===

class InternalDealTeamBrief(BaseModel):
    account_summary: AccountSummarySection
    deal_overview: DealOverviewSection
    risk_factors: RiskFactorsSection
    internal_win_strategy: InternalWinStrategySection
    brief_metadata: BriefMetadataSection
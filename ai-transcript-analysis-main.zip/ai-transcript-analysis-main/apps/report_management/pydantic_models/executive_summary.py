from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === EXECUTIVE SUMMARY SECTIONS ===

class CurrentStateChallengeSection(BaseModel):
    threat_description: str = Field(..., description="Two sentences framing absence of action as critical threat using urgent executive language")

class ProposedSolutionSection(BaseModel):
    strategic_opportunity: str = Field(..., description="Two sentences highlighting high-value strategic opportunity created by solving the problem")

class BusinessOutcomeMetric(BaseModel):
    objective: str = Field(..., description="Metric name (e.g., 'Revenue Retention', 'Churn Reduction', 'Operational Agility')")
    current_state: str = Field(..., description="Current baseline figure or percentage")
    target_outcome: str = Field(..., description="Target figure or percentage by timeline")

class KeyBusinessOutcomesSection(BaseModel):
    timeline: str = Field(..., description="Target timeline (e.g., 'Q4 2025', 'Q2 2025')")
    metrics: List[BusinessOutcomeMetric] = Field(..., description="3 business outcome metrics. Will be adjusted to exactly 3.")

    @validator('metrics')
    def ensure_three_metrics(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(BusinessOutcomeMetric(
                    objective=f"Strategic KPI {len(v) + 1}",
                    current_state=f"Current baseline {len(v) + 1}",
                    target_outcome=f"Target outcome {len(v) + 1}"
                ))
        elif len(v) > 3:
            v = v[:3]
        return v

class CostOfStatusQuoSection(BaseModel):
    # Pattern: "Every [time period], [reach] are impacted by [problem], costing [cost]. Without intervention by [timeline], [worsening outcome]."
    time_period: str = Field(..., description="Time frequency (e.g., 'Every quarter', 'Every month')")
    affected_reach: str = Field(..., description="Who/what is impacted (e.g., 'hundreds of employees', 'the security team')")
    problem_description: str = Field(..., description="Core problem description")
    cost_impact: str = Field(..., description="Cost or impact description")
    intervention_timeline: str = Field(..., description="Deadline for intervention (e.g., 'Q4 2025')")
    worsening_outcome: str = Field(..., description="What will worsen if no action is taken")

class InvestmentSection(BaseModel):
    budget_range: str = Field(..., description="Budget range description (e.g., 'CAD $34,560 annually', '$40,000 - $50,000 annually')")
    implementation_timeline: str = Field(..., description="Implementation timeline (e.g., 'January 2025 → March 2025')")
    key_stakeholders: List[str] = Field(..., description="List of key stakeholders and their roles. Will be adjusted to 3-5.")

    @validator('key_stakeholders')
    def ensure_stakeholders(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Stakeholder {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === FULL EXECUTIVE SUMMARY ===

class ExecutiveSummaryReport(BaseModel):
    company_name: str = Field(..., description="Client company name for header")
    
    current_state_challenge: CurrentStateChallengeSection
    proposed_solution: ProposedSolutionSection
    key_business_outcomes: KeyBusinessOutcomesSection
    cost_of_status_quo: CostOfStatusQuoSection
    investment: InvestmentSection
from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === CUSTOMER INFORMATION SECTION ===

class CustomerInformationSection(BaseModel):
    company_name: str = Field(..., description="Customer company name")
    primary_contact: str = Field(..., description="Primary contact name and role")
    influencers_decision_makers: List[str] = Field(..., description="List of influencers and decision makers. Will be adjusted to 2-5.")
    economic_buyer: str = Field(..., description="Economic buyer if known, or 'Unknown' with likely role")
    industry: str = Field(..., description="Industry sector with context")
    company_size: str = Field(..., description="Employee count or company size description")
    location: str = Field(..., description="Headquarters or operational location")

    @validator('influencers_decision_makers')
    def ensure_influencers(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Decision maker {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === COMPANY BACKGROUND SECTION ===

class CompanyBackgroundSection(BaseModel):
    company_background_paragraph: str = Field(..., description="Single comprehensive narrative paragraph (150-200+ words) covering company size, industry, strategic context, values, and transformation goals")


# === CUSTOMER'S CURRENT CHALLENGES SECTION ===

class CurrentChallengesSection(BaseModel):
    opening_paragraph: str = Field(..., description="Opening contextual paragraph that sets up the current situation")
    challenge_bullet_points: List[str] = Field(..., description="4-8 specific pain points as bullet points. Will be adjusted to 4-8.")
    closing_paragraph: str = Field(..., description="Closing paragraph describing broader impact or context")

    @validator('challenge_bullet_points')
    def ensure_challenge_bullets(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(f"Challenge point {len(v) + 1}")
        elif len(v) > 8:
            v = v[:8]
        return v


# === DESIRED OUTCOME SECTION ===

class DesiredOutcomeSection(BaseModel):
    opening_paragraph: str = Field(..., description="Opening paragraph describing strategic objectives overview")
    desired_outcome_bullet_points: List[str] = Field(..., description="4-8 specific goals as bullet points. Will be adjusted to 4-8.")
    closing_paragraph: str = Field(..., description="Closing paragraph defining success criteria")

    @validator('desired_outcome_bullet_points')
    def ensure_outcome_bullets(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(f"Desired outcome {len(v) + 1}")
        elif len(v) > 8:
            v = v[:8]
        return v


# === DEMO GOALS SECTION ===

class DemoGoalsSection(BaseModel):
    opening_context: str = Field(..., description="Opening contextual sentence about what the demo must accomplish")
    must_prove_outcomes: List[str] = Field(..., description="3-5 specific outcomes that must be proven in demo. Will be adjusted to 3-5.")
    top_technical_questions: List[str] = Field(..., description="1-5 top technical questions or blockers. Will be adjusted to 1-5.")
    key_differentiators: List[str] = Field(..., description="3-5 key differentiators to highlight. Will be adjusted to 3-5.")
    stakeholder_requirements: List[str] = Field(..., description="2-5 stakeholder-specific requirements in 'Name (Role): Needs...' format. Will be adjusted to 2-5.")
    strategic_aha_moments: List[str] = Field(..., description="3-5 strategic 'aha' moments to create. Will be adjusted to 3-5.")

    @validator('must_prove_outcomes')
    def ensure_must_prove(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Must prove outcome {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('top_technical_questions')
    def ensure_technical_questions(cls, v):
        if len(v) < 1:
            v.append("Technical question to address")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('key_differentiators')
    def ensure_differentiators(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Key differentiator {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('stakeholder_requirements')
    def ensure_stakeholder_requirements(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Stakeholder (Role): Needs requirement {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('strategic_aha_moments')
    def ensure_aha_moments(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Strategic aha moment {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === TECH ENVIRONMENT SECTION ===

class TechEnvironmentSection(BaseModel):
    tech_environment_description: str = Field(..., description="Comprehensive description of current tech environment, can include mixed paragraph and bullet point format")


# === RISKS SECTION ===

class RisksSection(BaseModel):
    deal_blockers: List[str] = Field(..., description="2-5 deal blockers or red flags. Will be adjusted to 2-5.")
    power_dynamics: List[str] = Field(..., description="2-4 power dynamics observations. Will be adjusted to 2-4.")
    technical_concerns: List[str] = Field(..., description="2-4 technical concerns or other risks. Will be adjusted to 2-4.")
    watch_outs: List[str] = Field(..., description="2-4 watch-outs and tactical guidance. Will be adjusted to 2-4.")

    @validator('deal_blockers')
    def ensure_deal_blockers(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Deal blocker {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v

    @validator('power_dynamics')
    def ensure_power_dynamics(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Power dynamic {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('technical_concerns')
    def ensure_technical_concerns(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Technical concern {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('watch_outs')
    def ensure_watch_outs(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Watch out {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === COMMENTS SECTION ===

class CommentsSection(BaseModel):
    comments_list: List[str] = Field(..., description="3-5 additional tactical insights and context bullet points. Will be adjusted to 3-5.")

    @validator('comments_list')
    def ensure_comments(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Additional insight {len(v) + 1}")
        elif len(v) > 5:
            v = v[:5]
        return v


# === FULL DEMO STRATEGY BRIEF ===

class DemoStrategyBrief(BaseModel):
    customer_information: CustomerInformationSection
    company_background: CompanyBackgroundSection
    current_challenges: CurrentChallengesSection
    desired_outcome: DesiredOutcomeSection
    demo_goals: DemoGoalsSection
    tech_environment: TechEnvironmentSection
    risks: RisksSection
    comments: CommentsSection
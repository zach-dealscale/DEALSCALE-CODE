from typing import List, Optional, Literal
from pydantic import BaseModel
from enum import Enum


class RiskLevel(str, Enum):
    CRITICAL = "🔴 High"
    HIGH = "🟠 Elevated"
    MEDIUM = "🟡 Medium"
    LOW = "🟢 Low"


class PersonaType(str, Enum):
    ECONOMIC_BUYER = "Economic Buyer"
    TECHNICAL_BUYER = "Technical Buyer"
    END_USER = "End User"
    CHAMPION = "Champion"
    BLOCKER = "Blocker"
    ENABLEMENT = "Enablement/IT"


class CampaignFormat(str, Enum):
    WEBINAR = "Webinar"
    CASE_STUDY = "Case Study"
    COMPARISON = "Comparison Guide"
    TESTIMONIAL = "Testimonial Video"
    ROI_TOOL = "ROI Calculator"


class DealStage(str, Enum):
    DISCOVERY = "Discovery"
    EVALUATION = "Evaluation"
    PROPOSAL = "Proposal"
    NEGOTIATION = "Negotiation"
    CLOSING = "Closing"


# Core Models
class CompetitorComplaint(BaseModel):
    competitor: str
    buyer_quote: str
    objection_theme: str
    opportunity: str


class CampaignHook(BaseModel):
    friction_point: str
    hook_phrase: str
    suggested_format: CampaignFormat
    target_persona: PersonaType


class MessagingHeatmap(BaseModel):
    claim_type: str
    competitor: str
    trust_signal: Literal["High", "Medium", "Low", "None"]
    recommended_action: str


class AtRiskDeal(BaseModel):
    deal_name: str
    stage: DealStage
    competitor: str
    influenced_persona: PersonaType
    risk_level: RiskLevel
    counter_play: str


class PlaybookRecommendation(BaseModel):
    offensive_moves: List[str]
    defensive_pivots: List[str]
    content_updates: List[str]


class CompetitiveAttackBrief(BaseModel):
    # Metadata
    date_range_analyzed: str
    calls_processed: int
    deals_with_competitors: int
    primary_competitors: List[str]

    # Executive Snapshot
    most_vulnerable_competitor: str
    most_common_complaint: str
    positioning_opportunity: str
    loss_risk_signal: str
    suggested_offensive_play: str

    # Competitor Breakdown
    competitor_complaints: List[CompetitorComplaint]

    # Campaign Hooks
    campaign_hooks: List[CampaignHook]
    priority_campaign: str

    # Messaging Heatmap
    messaging_heatmap: List[MessagingHeatmap]

    # At-Risk Deals
    at_risk_deals: List[AtRiskDeal]
    strategic_move: str

    # Playbook Recommendations
    playbook_recommendations: PlaybookRecommendation

    class Config:
        json_schema_extra = {
            "example": {
                "date_range_analyzed": "2023-11-01 to 2023-11-30",
                "calls_processed": 89,
                "deals_with_competitors": 23,
                "primary_competitors": ["CompetitorX", "CompetitorY", "CompetitorZ"],

                "most_vulnerable_competitor": "CompetitorX — flagged in 42% of calls for poor support",
                "most_common_complaint": "\"Implementation takes twice as long as promised\"",
                "positioning_opportunity": "Buyers confused by CompetitorY's tiered pricing",
                "loss_risk_signal": "CompetitorZ praised by technical buyers in 5 late-stage deals",
                "suggested_offensive_play": "Launch 'Implementation Guarantee' campaign",

                "competitor_complaints": [
                    {
                        "competitor": "CompetitorA",
                        "buyer_quote": "\"They disappeared after onboarding\"",
                        "objection_theme": "Poor customer support",
                        "opportunity": "Highlight our 24/7 support guarantee"
                    }
                ],

                "campaign_hooks": [
                    {
                        "friction_point": "\"No implementation help\"",
                        "hook_phrase": "\"Don't launch alone\"",
                        "suggested_format": "Webinar",
                        "target_persona": "Enablement/IT"
                    }
                ],
                "priority_campaign": "\"Why We Switched\" testimonial series — aligns with 68% of loss calls",

                "messaging_heatmap": [
                    {
                        "claim_type": "\"#1 in the industry\"",
                        "competitor": "CompetitorX",
                        "trust_signal": "Low",
                        "recommended_action": "Publish third-party analyst reports"
                    }
                ],

                "at_risk_deals": [
                    {
                        "deal_name": "Acme Corp",
                        "stage": "Evaluation",
                        "competitor": "CompetitorY",
                        "influenced_persona": "Technical Buyer",
                        "risk_level": "🔴 High",
                        "counter_play": "Schedule technical deep dive"
                    }
                ],
                "strategic_move": "Activate competitive enablement team for 3 high-risk deals",

                "playbook_recommendations": {
                    "offensive_moves": [
                        "Create 'Why We Switched' assets for CompetitorA defectors"
                    ],
                    "defensive_pivots": [
                        "De-emphasize legacy system integrations"
                    ],
                    "content_updates": [
                        "Refresh battlecards with pricing comparison data"
                    ]
                }
            }
        }
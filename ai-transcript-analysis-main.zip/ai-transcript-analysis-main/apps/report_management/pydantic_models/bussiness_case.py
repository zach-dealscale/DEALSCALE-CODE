from pydantic import BaseModel, Field, validator
from typing import List, Optional


# === CONTEXT ===

class ContextSection(BaseModel):
    opening_paragraph: str = Field(..., description="2-3 sentence opening paragraph describing the current situation, operational bottlenecks, and strategic risks using urgent executive language. Should naturally flow like client samples.")
    buying_team: str = Field(..., description="Team that must act (e.g., 'The People & Culture team')")
    deadline: str = Field(..., description="Action deadline (e.g., 'Q4 2025')")
    # action_items: List[str] = Field(..., description="3 specific action items. Will be adjusted to exactly 3.")
    cost_of_delay_paragraph: str = Field(..., description="Complete paragraph describing worsening problem and business consequences")
    metric_impact: str = Field(..., description="Metric impact description starting with 'risk of...'")



# === CHALLENGES ===
class ChallengeSection(BaseModel):
    # Client's required structure: "Every [period], [team] is impacted by [issue], causing:"
    frequency: str = Field(..., description="Time period (e.g., 'Every year', 'Every quarter')")
    affected_team: str = Field(..., description="Team/group affected")
    main_issue: str = Field(..., description="Main issue description")
    
    # These go after "causing:"
    impact_bullets: List[str] = Field(..., description="2-3 bullet points. First should be financial impact, second should start with 'Direct impact to:'")
    
    # Client's required structure: "Despite [attempts], we remain unable to [outcome] due to [constraint]"
    attempted_solutions: str = Field(..., description="What was attempted")
    unable_to_achieve: str = Field(..., description="What they remain unable to achieve")
    constraint: str = Field(..., description="Due to what constraint")
    
    # Client's required structure: "If unaddressed by [deadline], [risk] will escalate"
    escalation_deadline: str = Field(..., description="Deadline (Future Date) when problem escalates")
    escalation_risk: str = Field(..., description="What will escalate")
    
    root_causes: List[str] = Field(..., description="Root causes. Will be adjusted to 3-4.")

# === SOLUTION ===

class SolutionCapability(BaseModel):
    title: str = Field(..., description="Capability title")
    description: str = Field(..., description="Detailed description of the capability")

class SolutionSection(BaseModel):
    client_name: str = Field(..., description="Client company name for header and references")
    opening_paragraph: str = Field(..., description="Opening paragraph describing what the client will implement, including platform name if applicable")
    capabilities: List[SolutionCapability] = Field(..., description="4-5 solution capabilities. Will be adjusted to 4-5.")
    why_this_solution: str = Field(..., description="Complete paragraph explaining why this solution works with specific business impacts")

    @validator('capabilities')
    def ensure_four_to_five_capabilities(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(SolutionCapability(
                    title=f"Capability {len(v) + 1}",
                    description=f"Description for capability {len(v) + 1}"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === OUTCOMES ===

class OutcomeMetric(BaseModel):
    metric_name: str = Field(..., description="Metric name")
    current_state: str = Field(..., description="Current state description")
    target_outcome: str = Field(..., description="Target outcome description")

class OutcomeSection(BaseModel):
    metrics: List[OutcomeMetric] = Field(..., description="4-5 specific outcome metrics. Will be adjusted to 4-5. Show this in table with header (Metric, Current State, Target outcome by [target period])")
    resilience_current: str = Field(..., description="Current business resilience state with context")
    resilience_target: str = Field(..., description="Target business resilience state with context")

    @validator('metrics')
    def ensure_four_to_five_metrics(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(OutcomeMetric(
                    metric_name=f"Metric {len(v) + 1}",
                    current_state=f"Current state {len(v) + 1}",
                    target_outcome=f"Target outcome {len(v) + 1}"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === INVESTMENT ===

class InvestmentCategory(BaseModel):
    category_title: str = Field(..., description="Investment category title (e.g., 'Technology Investment', 'Platform Licensing', 'Organizational Investment')")
    items: List[str] = Field(..., description="List of specific items under this category")

class InvestmentSection(BaseModel):
    opening_line: Optional[str] = Field(None, description="Optional opening line like 'To achieve the above, [Client] will invest:' or 'Resources Required:'")
    investment_categories: List[InvestmentCategory] = Field(..., description="Detailed investment categories. Will be adjusted to 2-4 categories.")
    alignment_paragraph: str = Field(..., description="Complete paragraph describing strategic alignment and why this investment is critical")
    strategic_impacts: List[str] = Field(..., description="Strategic impacts as bullet points. Will be adjusted to 3-4.")
    conclusion_paragraph: str = Field(..., description="Concluding paragraph about future positioning and consequences of delay")

    @validator('investment_categories')
    def ensure_investment_categories(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(InvestmentCategory(
                    category_title=f"Investment Category {len(v) + 1}",
                    items=[f"Investment item {len(v) + 1}"]
                ))
        elif len(v) > 4:
            v = v[:4]
        return v

    @validator('strategic_impacts')
    def ensure_strategic_impacts(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(f"Strategic impact {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v


# === FULL REPORT ===

class BusinessCaseReport(BaseModel):
    title: str = Field(..., description="Title with quantifiable metric, transformation, and scope")
    # subtitle: Optional[str] = Field(None, description="Subtitle for additional context")
    prepared_by: str = Field(..., description="Prepared by line")
    
    context: ContextSection
    challenges: ChallengeSection
    solution: SolutionSection
    outcomes: OutcomeSection
    investment: InvestmentSection
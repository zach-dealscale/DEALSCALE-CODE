from pydantic import BaseModel, Field, validator
from typing import List, Optional
from enum import Enum


class SignalStrength(str, Enum):
    strong = "🟢 Strong"
    medium = "🟡 Medium" 
    high_friction = "🔴 High"


# === EXECUTIVE SUMMARY ===

class ExecutiveSummarySection(BaseModel):
    most_vocal_persona: str = Field(..., description="Persona that appeared in most calls or had most speaking time. Include % or count.")
    most_emotionally_charged_trigger: str = Field(..., description="Phrase, moment, or friction point that sparked visible emotion, pushback, or tension from persona. Include quote if possible.")
    priority_campaign_hook: str = Field(..., description="Punchy line (5-8 words max) that hits on this week's most repeated tension or need.")
    messaging_landmine: str = Field(..., description="Phrase or concept that repeatedly triggered eye-rolls, laughs, or skepticism. Include persona who reacted.")
    net_new_insight: str = Field(..., description="Pattern, behavior, or objection from persona that hasn't shown up before or now appears in new stage.")


# === PERSONA EMOTION GRID ===

class PersonaEmotionGrid(BaseModel):
    persona: str = Field(..., description="Persona name/title")
    trigger_words_phrases: str = Field(..., description="Direct or paraphrased quotes that triggered emotional signals")
    emotional_signals: str = Field(..., description="Emotional tone (e.g., anxiety, frustration, ROI stress, control-seeking)")
    objection_pattern: str = Field(..., description="Most common objection theme from this persona")
    campaign_angle: str = Field(..., description="Campaign-ready angle - something that can appear in copy or content, mapping to objection AND emotion")


class PersonaEmotionGridSection(BaseModel):
    persona_emotion_grid: List[PersonaEmotionGrid] = Field(..., description="3-5 key personas with their emotional triggers and patterns. Will be adjusted to 3-5.")

    @validator('persona_emotion_grid')
    def ensure_three_to_five_personas(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(PersonaEmotionGrid(
                    persona=f"Persona {len(v) + 1}",
                    trigger_words_phrases="Trigger words and phrases",
                    emotional_signals="Emotional signals",
                    objection_pattern="Objection pattern",
                    campaign_angle="Campaign angle"
                ))
        elif len(v) > 5:
            v = v[:5]
        return v


# === MESSAGING HEAT ZONES ===

class MessagingHeatZone(BaseModel):
    message_angle: str = Field(..., description="Phrase or theme currently used in messaging (e.g., 'seamless onboarding', 'AI-powered', 'single pane of glass')")
    persona_response: str = Field(..., description="Persona reactions (tone, quote, or sentiment)")
    signal_strength: SignalStrength = Field(..., description="Strong (buyer leaned in), Medium (mild interest or mixed), High friction (rejection, eye-roll, or pushback)")
    action: str = Field(..., description="Action to take: 'Retire', 'Reframe as...', 'Proof it with numbers', etc.")


class MessagingHeatZonesSection(BaseModel):
    messaging_heat_zones: List[MessagingHeatZone] = Field(..., description="4-6 phrases or themes with persona reactions. Will be adjusted to 4-6.")

    @validator('messaging_heat_zones')
    def ensure_four_to_six_messages(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(MessagingHeatZone(
                    message_angle=f"Message angle {len(v) + 1}",
                    persona_response="Persona response",
                    signal_strength=SignalStrength.medium,
                    action="Action to take"
                ))
        elif len(v) > 6:
            v = v[:6]
        return v


# === EMERGING PERSONA SHIFTS ===

class EmergingPersonaShift(BaseModel):
    change_detected: str = Field(..., description="Shift in where or how personas are showing up in deals (new persona influencing, appearing earlier/later, asking different questions)")
    supporting_evidence: str = Field(..., description="Transcript-based evidence (quote or call stage)")
    strategic_implication: str = Field(..., description="One messaging or enablement move tied to that shift")


class EmergingPersonaShiftsSection(BaseModel):
    emerging_persona_shifts: List[EmergingPersonaShift] = Field(..., description="2-4 shifts in persona behavior or influence. Will be adjusted to 2-4.")

    @validator('emerging_persona_shifts')
    def ensure_two_to_four_shifts(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(EmergingPersonaShift(
                    change_detected=f"Change detected {len(v) + 1}",
                    supporting_evidence="Supporting evidence",
                    strategic_implication="Strategic implication"
                ))
        elif len(v) > 4:
            v = v[:4]
        return v


# === CREATIVE BRIEF INPUT CARDS ===

class CreativeBriefInputCard(BaseModel):
    persona_name: str = Field(..., description="Persona name/title")
    tone: str = Field(..., description="Tone for this persona (e.g., Strategic, Empathetic, Outcome-driven)")
    do_say: str = Field(..., description="Language that works - must reflect real call language and reactions")
    dont_say: str = Field(..., description="Language to avoid - must reflect real call language and reactions")
    cta_words_that_work: str = Field(..., description="Call-to-action words that resonate with this persona")
    ad_angle: str = Field(..., description="Ad angle that connects emotionally to their objection or pressure")
    content_format_preference: str = Field(..., description="Content format that matches persona's consumption style (dashboards, testimonials, ROI visuals, etc.)")


class CreativeBriefInputCardsSection(BaseModel):
    creative_brief_input_cards: List[CreativeBriefInputCard] = Field(..., description="One card per persona with copy-ready guidance. Will match persona count from emotion grid.")

    @validator('creative_brief_input_cards')
    def ensure_minimum_personas(cls, v):
        if len(v) < 3:
            while len(v) < 3:
                v.append(CreativeBriefInputCard(
                    persona_name=f"Persona {len(v) + 1}",
                    tone="Tone",
                    do_say="Do say",
                    dont_say="Don't say", 
                    cta_words_that_work="CTA words",
                    ad_angle="Ad angle",
                    content_format_preference="Content format preference"
                ))
        return v


# === FULL PERSONA MESSAGING BRIEF ===

class PersonaMessagingBrief(BaseModel):
    # Metadata
    period_analyzed: str = Field(..., description="Date range analyzed (e.g., 'July 1-31, 2025')")
    calls_processed: int = Field(..., description="Number of calls processed")
    deals_covered: int = Field(..., description="Number of deals covered")
    target_segments: List[str] = Field(..., description="List of target segments")
    
    # Report sections
    executive_summary: ExecutiveSummarySection
    persona_emotion_grid: PersonaEmotionGridSection
    messaging_heat_zones: MessagingHeatZonesSection
    emerging_persona_shifts: EmergingPersonaShiftsSection
    creative_brief_input_cards: CreativeBriefInputCardsSection
from pydantic import BaseModel, Field, validator
from typing import List, Optional

# === GOALS & TIMELINE ===

class GoalsTimelineSection(BaseModel):
    goals: List[str] = Field(..., description="2-3 outcome-based goals tied to business value")
    target: str = Field(..., description="Target statement with compelling date and business context")

    @validator('goals')
    def ensure_two_to_three_goals(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Goal {len(v) + 1}")
        elif len(v) > 3:
            v = v[:3]
        return v

# === MILESTONE ===

class Milestone(BaseModel):
    label: str = Field(..., description="Milestone or decision point label")
    start_date: str = Field(..., description="Start date (e.g., 'Aug 5, 2025')")
    end_date: str = Field(..., description="End date (e.g., 'Aug 7, 2025')")
    owner: str = Field(..., description="Owner (Customer / Us / Shared)")
    status: str = Field(..., description="Status (To Do, In Progress, Complete, Planned, etc.)")

class KeyMilestonesSection(BaseModel):
    milestones: List[Milestone] = Field(..., description="5–10 key milestones, each with all fields filled")

    @validator('milestones')
    def ensure_milestone_count(cls, v):
        if len(v) < 5:
            while len(v) < 5:
                v.append(Milestone(
                    label=f"Milestone {len(v) + 1}",
                    start_date="TBD",
                    end_date="TBD",
                    owner="Shared",
                    status="To Do"
                ))
        elif len(v) > 12:
            v = v[:12]
        return v

# === DECISION CRITERIA ALIGNMENT ===

class DecisionCriteriaSection(BaseModel):
    criteria: List[str] = Field(..., description="4–6 bullets with buyer's decision requirements")

    @validator('criteria')
    def ensure_four_to_six_criteria(cls, v):
        if len(v) < 4:
            while len(v) < 4:
                v.append(f"Decision criterion {len(v) + 1}")
        elif len(v) > 6:
            v = v[:6]
        return v

# === INTERNAL SPONSORSHIP VIEW ===

class SponsorshipViewSection(BaseModel):
    view_paragraph: str = Field(..., description="Narrative describing champion's focus, KPIs, success definition, supporting sponsors/names")

# === FINAL SIGN-OFF PLAN ===

class SignOffPlanSection(BaseModel):
    final_business_case_review: str = Field(..., description="Final business case review date")
    contract_signature_target: str = Field(..., description="Contract signature target date")
    launch_go_live: str = Field(..., description="Launch or Go-Live date")
    plan_co_owners: List[str] = Field(..., description="List of co-owners (Champion + Rep/AE)")

    @validator('plan_co_owners')
    def ensure_two_owners(cls, v):
        if len(v) < 2:
            while len(v) < 2:
                v.append(f"Co-owner {len(v) + 1}")
        elif len(v) > 4:
            v = v[:4]
        return v

# === FULL MUTUAL ACTION PLAN REPORT ===

class MutualActionPlanReport(BaseModel):
    opening_sentence: str = Field(..., description="Opening sentence with structure 'Built in collaboration with [Champion Name(s)] to align stakeholders, accelerate progress, and achieve defined success milestones.")
    client_name: str = Field(..., description="Client company name for header")

    goals_timeline: GoalsTimelineSection
    key_milestones: KeyMilestonesSection
    decision_criteria: DecisionCriteriaSection
    sponsorship_view: SponsorshipViewSection
    signoff_plan: SignOffPlanSection

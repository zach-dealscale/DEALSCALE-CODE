from django.test import TestCase
from django.contrib.auth import get_user_model
from apps.authentication.models import Client
from apps.report_management.models import Transcript, ReportTemplate, ReportFormation, ReportDocument

User = get_user_model()


class TranscriptDeletionTest(TestCase):
    def setUp(self):
        # Create a user and a client
        self.user = User.objects.create_user(password="pass123", email="test@gmail.com")
        self.client = Client.objects.create(user=self.user, name="Test Client", company_size="3456")

        # Create a transcript
        self.transcript = Transcript.objects.create(
            user=self.user,
            client=self.client,
            title="Sample Transcript",
            text="Transcript content here"
        )

        # Create a report template
        self.template = ReportTemplate.objects.create(
            key="test_key",
            title="Deal Forecast Brief",
            description="Test description"
        )

        # Create a report formation linked to the transcript
        self.report = ReportFormation.objects.create(
            template=self.template,
            transcript=self.transcript,
            client=self.client,
            user=self.user
        )

        # Create a report document linked to the report
        self.document = ReportDocument.objects.create(
            report=self.report,
            title=f"{self.template.title} - {self.client.name}",
            user=self.user,
            client=self.client
        )

    def test_documents_not_deleted_when_transcript_deleted(self):
        """
        Deleting a Transcript should NOT delete related ReportDocuments.
        The ReportFormation.transcript field uses SET_NULL, so documents remain intact.
        """

        # Verify setup
        self.assertEqual(ReportDocument.objects.count(), 1)
        self.assertEqual(ReportFormation.objects.count(), 1)
        self.assertEqual(Transcript.objects.count(), 1)

        self.transcript.delete()

        self.assertEqual(Transcript.objects.count(), 0)

        self.report.refresh_from_db()
        self.assertIsNone(self.report.transcript)

        self.assertEqual(ReportDocument.objects.count(), 1)

        doc = ReportDocument.objects.first()
        self.assertEqual(doc.title, f"{self.template.title} - {self.client.name}")

        print("Test passed: Documents remain after transcript deletion.")

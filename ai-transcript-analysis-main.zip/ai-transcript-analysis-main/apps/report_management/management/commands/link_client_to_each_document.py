from django.core.management.base import BaseCommand
from apps.report_management.models import ReportDocument

class Command(BaseCommand):
    help = "Update all ReportDocument entries with their related client from the linked transcript."

    def handle(self, *args, **options):
        documents = ReportDocument.objects.select_related(
            "report__transcript__client"
        ).all()
        updated_count = 0

        for document in documents:
            try:
                transcript = getattr(document.report, "transcript", None)
                if transcript and transcript.client:
                    document.client = transcript.client
                    document.save(update_fields=["client"])
                    updated_count += 1
                    self.stdout.write(
                        self.style.SUCCESS(f"Updated document ID {document.id} → Client: {transcript.client}")
                    )
                else:
                    self.stdout.write(
                        self.style.WARNING(f"Skipped document ID {document.id} (no client or transcript found)")
                    )
            except Exception as e:
                self.stdout.write(
                    self.style.ERROR(f"Error updating document ID {document.id}: {e}")
                )

        self.stdout.write(
            self.style.SUCCESS(f"✅ Successfully updated {updated_count} documents.")
        )

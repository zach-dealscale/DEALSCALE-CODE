from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Client, Company, Role, Team, TeamMembership
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from .tasks import send_password_reset_email  # 👈 import your celery task here
from django.conf import settings

from django.utils.translation import gettext_lazy as _


from ..sale_rooms.salesforce_integration_utils import RoleChoices

User = get_user_model()  # Dynamically get the user model

# CSS Classes for consistent styling
FORM_CONTROL_CLASS = 'w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500'
TEXTAREA_CLASS = 'w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 resize-none'
CHECKBOX_CLASS = 'h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded'
SELECT_CLASS = 'w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white'


class SignupForm(UserCreationForm):
    first_name = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "John"
        }),
        label="First Name (Optional)",
    )

    last_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "Doe"
        }),
        label="Last Name",
    )

    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "john@example.com"
        }),
    )

    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "••••••••"
        }),
    )

    password2 = forms.CharField(
        label="Confirm Password",
        widget=forms.PasswordInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "••••••••"
        }),
    )

    company_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={
            "class": "mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500",
            "placeholder": "Acme Corporation"
        }),
        label="Company Name",
        help_text="The name of your company or organization"
    )

    class Meta:
        model = CustomUser
        fields = ["email", "first_name", "last_name", "company_name", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add help texts for password requirements
        self.fields['password1'].help_text = "Your password must contain at least 8 characters."



class EmailLoginForm(AuthenticationForm):
    username = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "Email"}),
        label="Email",
    )
    password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={"class": "form-control", "placeholder": "Password"}),
        label="Password",
    )




class CustomPasswordResetForm(PasswordResetForm):
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if not User.objects.filter(email=email).exists():
            raise forms.ValidationError("There is no user registered with this email address.")
        return email

    def save(
            self,
            domain_override=None,
            subject_template_name="registration/password_reset_subject.txt",
            email_template_name="registration/password_reset_email.html",
            use_https=False,
            token_generator=default_token_generator,
            from_email=None,
            request=None,
            html_email_template_name=None,
            extra_email_context=None,
    ):
        email = self.cleaned_data["email"]
        if not domain_override:
            current_site = get_current_site(request)
            site_name = current_site.name
            domain = current_site.domain
        else:
            site_name = domain = domain_override

        for user in self.get_users(email):
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = token_generator.make_token(user)

            context = {
                "email": user.email,
                "domain": domain,
                "site_name": site_name,
                "uid": uid,
                "user_id": user.pk,
                "token": token,
                "protocol": "https" if use_https else "http",
                **(extra_email_context or {}),
            }

            send_password_reset_email.delay(
                subject_template_name,
                email_template_name,
                context,
                from_email or settings.DEFAULT_FROM_EMAIL,
                user.email,
                html_email_template_name
            )


class ClientUpdateForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'industry', 'company_size', 'website', 'company_logo', 'notes', 'company_email']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
            }),
            'website': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
            }),
            'company_email': forms.EmailInput(attrs={  # Changed to EmailInput for better validation
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
            }),
            'company_size': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
            }),
            'industry': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
            }),
            'notes': forms.Textarea(attrs={  # Changed to Textarea for better notes handling
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
                'rows': 3
            })
        }


# ==================== COMPANY MANAGEMENT FORMS ====================

class CompanyForm(forms.ModelForm):
    """Form for editing company details"""
    class Meta:
        model = Company
        fields = ['name', 'website', 'logo']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'Company Name',
                'required': True,
            }),
            'website': forms.URLInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'https://example.com',
                'required': False,
            }),
            'logo': forms.FileInput(attrs={
                'class': 'block w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100',
                'accept': 'image/*',
            }),
        }


class RoleForm(forms.ModelForm):
    """Form for creating and editing roles with permissions"""

    # Permission checkboxes
    can_view_all_data = forms.BooleanField(
        label='View all company data',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_manage_team = forms.BooleanField(
        label='Manage teams',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_manage_roles = forms.BooleanField(
        label='Manage roles',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_manage_clients = forms.BooleanField(
        label='Manage clients',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_upload_transcripts = forms.BooleanField(
        label='Upload transcripts',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_generate_reports = forms.BooleanField(
        label='Generate reports',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_view_hierarchy_data = forms.BooleanField(
        label='View hierarchy data',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_view_forecast = forms.BooleanField(
        label='View Forecast',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )
    can_view_analytics = forms.BooleanField(
        label='View Analytics',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_CLASS})
    )

    class Meta:
        model = Role
        fields = ['name', 'level', 'description']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'Role Name (e.g., Sales Manager)',
            }),
            'level': forms.NumberInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'Hierarchy Level (0 = highest)',
                'type': 'number',
                'min': '0',
            }),
            'description': forms.Textarea(attrs={
                'class': TEXTAREA_CLASS,
                'placeholder': 'Role description...',
                'rows': 3,
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            # Populate permission checkboxes from existing role
            self.fields['can_view_all_data'].initial = self.instance.can_view_all_data
            self.fields['can_manage_team'].initial = self.instance.can_manage_team
            self.fields['can_manage_roles'].initial = self.instance.can_manage_roles
            self.fields['can_manage_clients'].initial = self.instance.can_manage_clients
            self.fields['can_upload_transcripts'].initial = self.instance.can_upload_transcripts
            self.fields['can_generate_reports'].initial = self.instance.can_generate_reports
            self.fields['can_view_hierarchy_data'].initial = self.instance.can_view_hierarchy_data
            self.fields['can_view_forecast'].initial = self.instance.can_view_forecast
            self.fields['can_view_analytics'].initial = self.instance.can_view_analytics

    def save(self, commit=True):
        instance = super().save(commit=False)

        # If admin access is enabled, automatically set all permissions to True
        is_admin = self.cleaned_data.get('can_view_all_data', False)

        if is_admin:
            # Set all permissions to True for admin roles
            instance.can_view_all_data = True
            instance.can_manage_team = True
            instance.can_manage_roles = True
            instance.can_manage_clients = True
            instance.can_upload_transcripts = True
            instance.can_generate_reports = True
            instance.can_view_hierarchy_data = True
            instance.can_view_forecast = True
            instance.can_view_analytics = True
        else:
            # For non-admin roles, use the form values
            instance.can_view_all_data = False
            instance.can_manage_team = self.cleaned_data.get('can_manage_team', False)
            instance.can_manage_roles = self.cleaned_data.get('can_manage_roles', False)
            instance.can_manage_clients = self.cleaned_data.get('can_manage_clients', False)
            instance.can_upload_transcripts = self.cleaned_data.get('can_upload_transcripts', False)
            instance.can_generate_reports = self.cleaned_data.get('can_generate_reports', False)
            instance.can_view_hierarchy_data = self.cleaned_data.get('can_view_hierarchy_data', False)
            instance.can_view_forecast = self.cleaned_data.get('can_view_forecast', False)
            instance.can_view_analytics = self.cleaned_data.get('can_view_analytics', False)

        if commit:
            instance.save()
        return instance


class UserInviteForm(forms.Form):
    """Form for inviting new users to the company"""
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': FORM_CONTROL_CLASS,
            'placeholder': 'user@example.com',
        }),
        label='Email Address'
    )
    first_name = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': FORM_CONTROL_CLASS,
            'placeholder': 'First Name',
        })
    )
    last_name = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': FORM_CONTROL_CLASS,
            'placeholder': 'Last Name',
        })
    )
    role = forms.ModelChoiceField(
        queryset=Role.objects.none(),
        widget=forms.Select(attrs={
            'class': SELECT_CLASS,
        }),
        label='Role'
    )
    manager = forms.ModelChoiceField(
        queryset=CustomUser.objects.none(),
        widget=forms.Select(attrs={
            'class': SELECT_CLASS,
        }),
        label='Manager (Optional)',
        required=False
    )

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company:
            self.fields['role'].queryset = company.roles.all()
            # Only show active users as potential managers
            self.fields['manager'].queryset = company.users.filter(
                is_active_in_company=True
            )


class UserEditForm(forms.ModelForm):
    """Form for editing user details"""
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'role', 'manager']
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'First Name',
            }),
            'last_name': forms.TextInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'Last Name',
            }),
            'role': forms.Select(attrs={
                'class': SELECT_CLASS,
            }),
            'manager': forms.Select(attrs={
                'class': SELECT_CLASS,
            }),
        }

    def __init__(self, *args, company=None, user_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company:
            self.fields['role'].queryset = company.roles.all()
            # Only show active users, excluding self
            self.fields['manager'].queryset = company.users.filter(
                is_active_in_company=True
            ).exclude(id=user_id)
        # Make manager field optional
        self.fields['manager'].required = False


class TeamForm(forms.ModelForm):
    """Form for creating and editing teams"""
    class Meta:
        model = Team
        fields = ['name', 'description', 'lead']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': FORM_CONTROL_CLASS,
                'placeholder': 'Team Name (e.g., Sales Team)',
            }),
            'description': forms.Textarea(attrs={
                'class': TEXTAREA_CLASS,
                'placeholder': 'Team description and purpose...',
                'rows': 3,
            }),
            'lead': forms.Select(attrs={
                'class': SELECT_CLASS,
            }),
        }

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company:
            self.fields['lead'].queryset = company.users.filter(is_active_in_company=True)
        # Make lead optional
        self.fields['lead'].required = False


class TeamMemberForm(forms.Form):
    """Form for adding members to a team"""
    user = forms.ModelChoiceField(
        queryset=CustomUser.objects.none(),
        widget=forms.Select(attrs={
            'class': SELECT_CLASS,
        }),
        label='Select User'
    )
    role_in_team = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': FORM_CONTROL_CLASS,
            'placeholder': 'Role in team (optional)',
        }),
        label='Role in Team'
    )

    def __init__(self, *args, company=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company and team:
            # Show only users not already in this team
            self.fields['user'].queryset = company.users.filter(
                is_active_in_company=True
            ).exclude(
                team_memberships__team=team,
                team_memberships__is_active=True
            )
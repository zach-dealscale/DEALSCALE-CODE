import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import Q
from apps.report_management.helpers.report_choices import Stage

from django.utils.text import slugify
from django.core.cache import cache

from .manager import CustomUserManager
from django_resized import ResizedImageField
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta
import secrets
import string
from apps.core.models import BaseModel


# ==================== COMPANY MODELS ====================

class Company(BaseModel):
    """
    Top-level organizational unit (tenant).
    Every piece of data belongs to exactly one Company.
    Uses BaseModel's prefixed UUID (company-xyz) as primary key.
    """
    PREFIX = "company"

    name = models.CharField(max_length=255)
    website = models.URLField(blank=True, null=True)
    logo = models.ImageField(upload_to="company_logos/", blank=True, null=True)

    # Metadata
    created_by = models.ForeignKey(
        'CustomUser',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='companies_created'
    )

    # Future expansion: is_active for soft-delete, subscription_tier for SaaS
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['name']
        indexes = [
            models.Index(fields=['is_active'], name='company_active_idx'),
        ]

    def __str__(self):
        return self.name


class Role(BaseModel):
    """
    Permission level within a Company.
    Each Company can define custom roles.
    """
    PREFIX = "role"

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='roles'
    )
    name = models.CharField(max_length=100)
    level = models.PositiveIntegerField(default=0)  # 0=highest, 999=lowest
    description = models.TextField(blank=True)

    # Permission flags (simple, fast checks)
    can_manage_team = models.BooleanField(default=False)
    can_view_all_data = models.BooleanField(default=False)
    can_view_hierarchy_data = models.BooleanField(default=False)
    can_manage_roles = models.BooleanField(default=False)
    can_manage_clients = models.BooleanField(default=False)
    can_upload_transcripts = models.BooleanField(default=True)
    can_generate_reports = models.BooleanField(default=True)
    can_view_forecast = models.BooleanField(default=False)
    can_view_analytics = models.BooleanField(default=False)

    def set_full_permissions(self):
        self.can_manage_team = True
        self.can_view_all_data = True
        self.can_view_hierarchy_data = True
        self.can_manage_roles = True
        self.can_manage_clients = True
        self.can_upload_transcripts = True
        self.can_generate_reports = True
        self.can_view_forecast = True
        self.can_view_analytics = True

    class Meta:
        unique_together = ('company', 'name')
        ordering = ['level', 'name']
        indexes = [
            models.Index(fields=['company', 'level'], name='role_company_level_idx'),
        ]

    def __str__(self):
        return f"{self.company.name} - {self.name}"

    @classmethod
    def create_default_roles(cls, company):
        """Factory: Create default roles for a new company."""
        defaults = [
            {
                'name': 'Owner',
                'level': 0,
                'can_manage_team': True,
                'can_view_all_data': True,
                'can_manage_roles': True,
                'can_manage_clients': True,
                'can_view_forecast': True,
                'can_view_analytics': True,
            },
            {
                'name': 'VP/Admin',
                'level': 1,
                'can_manage_team': True,
                'can_view_hierarchy_data': True,
                'can_manage_clients': True,
                'can_view_forecast': True,
                'can_view_analytics': True,
            },
            {
                'name': 'Sales Rep',
                'level': 2,
                'can_upload_transcripts': True,
                'can_generate_reports': True,
                'can_view_forecast': False,
                'can_view_analytics': False,
            },
        ]
        for role_data in defaults:
            cls.objects.get_or_create(company=company, name=role_data['name'], defaults=role_data)


class Team(BaseModel):
    """
    Group of Users within a Company.
    Example: "Enterprise Sales", "Onboarding", "Support"
    """
    PREFIX = "team"

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='teams'
    )
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)

    created_by = models.ForeignKey(
        'CustomUser',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='teams_created'
    )

    # Optional team lead
    lead = models.ForeignKey(
        'CustomUser',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='teams_led'
    )

    class Meta:
        unique_together = ('company', 'name')
        ordering = ['name']
        indexes = [
            models.Index(fields=['company', 'created_at'], name='team_company_created_idx'),
        ]

    def __str__(self):
        return f"{self.company.name} - {self.name}"

    def get_member_count(self):
        """Return count of active users in this team."""
        return self.memberships.filter(is_active=True).count()

    def get_active_members(self):
        """Return all active members of this team."""
        return self.memberships.filter(is_active=True).select_related('user')


class TeamMembership(BaseModel):
    """
    Through table to link Users to Teams (many-to-many with metadata).
    Allows a user to belong to multiple teams.
    """
    PREFIX = "tmembership"

    user = models.ForeignKey(
        'CustomUser',
        on_delete=models.CASCADE,
        related_name='team_memberships'
    )

    team = models.ForeignKey(
        Team,
        on_delete=models.CASCADE,
        related_name='memberships'
    )

    # Optional: Role within this specific team (for future use)
    # e.g., "Team Lead", "Member", "Observer"
    role_in_team = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        help_text="Role of user within this team (e.g., 'Team Lead')"
    )

    # Soft delete: mark as inactive instead of deleting
    is_active = models.BooleanField(default=True)

    # Track when user joined this team
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'team')
        ordering = ['joined_at']
        indexes = [
            models.Index(fields=['user', 'is_active'], name='tmembership_user_active_idx'),
            models.Index(fields=['team', 'is_active'], name='tmembership_team_active_idx'),
        ]

    def __str__(self):
        return f"{self.user.email} → {self.team.name}"


# ==================== EXTENDED CUSTOMUSER ====================

class CustomUser(AbstractUser):
    id = models.CharField(max_length=50, primary_key=True, editable=False, unique=True)
    username = None
    email = models.EmailField(unique=True)
    profile_picture = ResizedImageField(
        null=True,
        blank=True,
        upload_to="Profile/profile_image",
        max_length=1000,
        force_format="WEBP",
        quality=75,
    )

    # ✅ NEW: Company-level fields (nullable during Phase 1)
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='users',
        null=True,
        blank=True
    )

    role = models.ForeignKey(
        Role,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='users'
    )

    # Self-referential: who is this user's manager?
    manager = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='subordinates'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Company status
    is_active_in_company = models.BooleanField(default=True)
    joined_company_at = models.DateTimeField(null=True, blank=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    class Meta:
        indexes = [
            models.Index(fields=['company', 'created_at'], name='user_company_created_idx'),
            models.Index(fields=['company', 'role'], name='user_company_role_idx'),
            models.Index(fields=['manager', 'is_active_in_company'], name='user_manager_active_idx'),
            models.Index(fields=['company', 'is_active_in_company'], name='user_company_active_idx'),
        ]

    def save(self, *args, **kwargs):
        if not self.id:
            self.id = f"user-{uuid.uuid4()}"  # ✅ Prefixed UUID

        # Auto-set joined_company_at on first company assignment
        if self.company and not self.joined_company_at:
            self.joined_company_at = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        company_name = self.company.name if self.company else "No Company"
        return f"{self.email} ({self.first_name} {self.last_name}) ({company_name})"

    # ✅ NEW METHODS: Hierarchy & Permissions

    def get_subordinates(self, include_self=False):
        """
        Get all users under this user in hierarchy (iterative, no stack overflow).
        Uses iterative BFS instead of recursion for deep org charts.
        """
        subordinates = []
        queue = [self]
        visited = {self.id}

        while queue:
            current = queue.pop(0)
            if current != self or include_self:
                subordinates.append(current)

            # Get direct reports
            for sub in current.subordinates.filter(is_active_in_company=True).exclude(id__in=visited):
                if sub.id not in visited:
                    queue.append(sub)
                    visited.add(sub.id)

        return subordinates

    def get_subordinate_ids(self, use_cache=True):
        """
        Get cached subordinate IDs for fast permission checks.
        Cache invalidated when manager changes.
        """
        cache_key = f"user_subordinates_{self.id}"

        if use_cache:
            cached = cache.get(cache_key)
            if cached is not None:
                return cached

        sub_ids = [u.id for u in self.get_subordinates(include_self=True)]
        cache.set(cache_key, sub_ids, timeout=3600)  # 1 hour

        return sub_ids

    def get_hierarchy_level(self):
        """
        Calculate depth in reporting hierarchy.
        Owner = 0, direct reports of owner = 1, etc.
        """
        if not self.manager:
            return 0
        return 1 + self.manager.get_hierarchy_level()

    def is_manager_of(self, other_user):
        """Check if this user manages another user."""
        return other_user in self.get_subordinates()

    def can_view_user_data(self, target_user):
        """
        Permission check: Can this user view target_user's data?

        Rules:
        1. Owner can view all company data
        2. Users can view their own data
        3. Managers can view their subordinates' data
        """
        if self.company != target_user.company:
            return False

        if self.role and self.role.can_view_all_data:  # Owner
            return True

        if self == target_user:
            return True

        if self.role and self.role.can_view_hierarchy_data and self.is_manager_of(target_user):
            return True

        return False

    # ✅ NEW METHODS: Team Management (multiple team support)

    def get_teams(self):
        """Get all active teams this user belongs to."""
        return Team.objects.filter(
            memberships__user=self,
            memberships__is_active=True
        ).distinct()

    def get_team_count(self):
        """Count active teams this user belongs to."""
        return self.team_memberships.filter(is_active=True).count()

    def is_in_team(self, team):
        """Check if user is active member of a team."""
        return self.team_memberships.filter(
            team=team,
            is_active=True
        ).exists()

    def add_to_team(self, team, role_in_team=None):
        """Add user to a team (creates TeamMembership)."""
        membership, created = TeamMembership.objects.get_or_create(
            user=self,
            team=team,
            defaults={'role_in_team': role_in_team, 'is_active': True}
        )
        if not created and not membership.is_active:
            # Re-activate if was previously removed
            membership.is_active = True
            membership.role_in_team = role_in_team
            membership.save()
        return membership

    def remove_from_team(self, team):
        """Soft-delete: Remove user from team (mark as inactive)."""
        try:
            membership = self.team_memberships.get(team=team)
            membership.is_active = False
            membership.save()
            return True
        except TeamMembership.DoesNotExist:
            return False


User = get_user_model()


# ==================== EXTENDED CLIENT ====================

class Client(models.Model):
    """
    Customer/Client model.
    Now company-scoped (multiple users in a company can see the same client).
    """
    name = models.CharField(max_length=255)
    company_logo = models.ImageField(upload_to="client_logos/", blank=True, null=True)
    website = models.URLField(blank=True, null=True)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='clients',
        null=True,
        blank=True
    )

    # LEGACY: Keep for backward compatibility (mark as deprecated)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="clients_legacy"
    )

    # ✅ NEW: Primary owner within the company
    primary_owner = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='owned_clients'
    )

    # ✅ NEW: Track who created this client
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='clients_created'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    company_email = models.EmailField(blank=True, null=True)
    industry = models.CharField(max_length=100, blank=True)
    company_size = models.IntegerField(blank=True, null=True)
    notes = models.TextField(blank=True)
    stage = models.CharField(
        max_length=50,
        choices=Stage.choices,
        default=Stage.DISCOVERY,
        db_index=True)

    class Meta:
        ordering = ['-created_at']
        unique_together = ('company', 'name')
        indexes = [
            models.Index(fields=['company', 'created_at'], name='client_company_created_idx'),
            models.Index(fields=['primary_owner'], name='client_owner_idx'),
        ]
        verbose_name = "Client"
        verbose_name_plural = "Clients"

    def get_total_documents_count(self):
        from apps.report_management.models import ReportDocument
        documents = ReportDocument.objects.filter(
            Q(report__transcript__client=self) |
            Q(report__additional_transcripts__client=self) |
            Q(client=self)
        ).distinct()
        return documents.count()

    def __str__(self):
        company_name = self.company.name if self.company else "No Company"
        return f"{self.name} ({company_name})"

class GuestUser(models.Model):
    """
    Model for guest users.
    """
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=100, blank=True)
    is_verified = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_login=models.DateTimeField(null=True, blank=True, auto_now_add=True)
    visit_count=models.IntegerField(default=0)
    sales_room = models.ForeignKey("sale_rooms.SalesRoom", on_delete=models.CASCADE, related_name="visitors", null=True, blank=True)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='guest_users',
        null=True,
        blank=True
    )

    class Meta:
        indexes = [
            models.Index(fields=['company', 'created_at'], name='guestuser_company_created_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from sales_room if not already set."""
        if not self.company and self.sales_room and self.sales_room.company:
            self.company = self.sales_room.company
        super().save(*args, **kwargs)


class GuestUserSessionKey(models.Model):
    SESSION_KEY_LENGTH = 128
    guest_user = models.ForeignKey(GuestUser, on_delete=models.CASCADE, related_name='sessions')
    session_key = models.CharField(max_length=255, unique=True)
    expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Guest User Session"
        verbose_name_plural = "Guest User Sessions"

    def generate_session_key(self, length=SESSION_KEY_LENGTH):
        """Generate a secure random session key"""
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    def save(self, *args, **kwargs):
        if not self.session_key:
            self.session_key = self.generate_session_key()
            self.expires_at = timezone.now() + timedelta(days=30)
        super().save(*args, **kwargs)


# ==================== INVITATION SYSTEM ====================

class Invitation(BaseModel):
    """
    Tracks user invitations to join a company.
    When a user is invited, an Invitation record is created with a unique token.
    The invitee clicks the link in the email and sets their password to activate.
    """
    PREFIX = "invite"

    # The user being invited
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='invitations_received'
    )

    # Company they're being invited to
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='user_invitations'
    )

    # Who sent the invitation
    invited_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='invitations_sent'
    )

    # Unique token for accepting invitation (replaces password reset style flow)
    token = models.CharField(max_length=128, unique=True, db_index=True)

    # Status of invitation
    PENDING = 'pending'
    ACCEPTED = 'accepted'
    EXPIRED = 'expired'
    REJECTED = 'rejected'

    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (ACCEPTED, 'Accepted'),
        (EXPIRED, 'Expired'),
        (REJECTED, 'Rejected'),
    ]

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=PENDING
    )

    # Timestamps
    sent_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField()

    class Meta:
        unique_together = ('user', 'company')
        ordering = ['-sent_at']
        indexes = [
            models.Index(fields=['token'], name='invitation_token_idx'),
            models.Index(fields=['company', 'status'], name='invitation_company_status_idx'),
            models.Index(fields=['user', 'status'], name='invitation_user_status_idx'),
        ]

    def __str__(self):
        return f"{self.user.email} → {self.company.name} (Invitation)"

    def is_expired(self):
        """Check if invitation has expired"""
        return timezone.now() > self.expires_at

    @staticmethod
    def generate_token(length=64):
        """Generate a secure random token"""
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    def save(self, *args, **kwargs):
        # Generate token on creation if not provided
        if not self.token:
            self.token = self.generate_token()

        # Set expiry to 7 days from now if not set
        if not self.expires_at:
            self.expires_at = timezone.now() + timedelta(days=7)

        super().save(*args, **kwargs)
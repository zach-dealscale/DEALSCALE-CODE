from django.urls import path
from django.contrib.auth import views as auth_views
from .forms import EmailLoginForm  # Custom login form
from . import views
from .forms import CustomPasswordResetForm
from . import views_company
from .views import CustomPasswordResetConfirmView

urlpatterns = [
    path(
        "login/",
        views.custom_login,
        name="login",
    ),
    path("signup/", views.signup, name="signup"),
    path('logout/', views.custom_logout, name='logout'),
    # path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path(
        'password_reset/',
        auth_views.PasswordResetView.as_view(
            template_name='authentication/password_reset.html',
            form_class=CustomPasswordResetForm
        ),
        name='password_reset',
    ),
    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(template_name='authentication/password_reset_done.html'), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/', CustomPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='authentication/password_reset_complete.html'), name='password_reset_complete'),

    # Invitation System
    path('accept-invitation/<str:token>/', views_company.AcceptInvitationView.as_view(), name='accept_invitation'),

    # ==================== COMPANY MANAGEMENT ====================
    # Company Settings
    path('company/', views_company.CompanySettingsView.as_view(), name='company_settings'),
    path('company/edit/', views_company.CompanyEditView.as_view(), name='company_edit'),

    # Roles Management
    path('company/roles/', views_company.RoleListView.as_view(), name='company_roles_list'),
    path('company/roles/create/', views_company.RoleCreateView.as_view(), name='company_role_create'),
    path('company/roles/<str:role_id>/edit/', views_company.RoleEditView.as_view(), name='company_role_edit'),
    path('company/roles/<str:role_id>/delete/', views_company.RoleDeleteView.as_view(), name='company_role_delete'),

    # Users Management
    path('company/users/', views_company.UserListView.as_view(), name='company_users_list'),
    path('company/users/invite/', views_company.UserInviteView.as_view(), name='company_users_invite'),
    path('company/users/<str:user_id>/edit/', views_company.UserEditView.as_view(), name='company_user_edit'),
    path('company/users/<str:user_id>/deactivate/', views_company.UserDeactivateView.as_view(), name='company_user_deactivate'),
    path('company/users/<str:user_id>/reactivate/', views_company.UserReactivateView.as_view(), name='company_user_reactivate'),
    path('company/users/<str:user_id>/delete/', views_company.UserDeleteView.as_view(), name='company_user_delete'),
    path('company/users/<str:user_id>/resend-invitation/', views_company.ResendInvitationView.as_view(), name='company_user_resend_invitation'),

    # Teams Management
    path('company/teams/', views_company.TeamListView.as_view(), name='company_teams_list'),
    path('company/teams/create/', views_company.TeamCreateView.as_view(), name='company_team_create'),
    path('company/teams/<str:team_id>/edit/', views_company.TeamEditView.as_view(), name='company_team_edit'),
    path('company/teams/<str:team_id>/delete/', views_company.TeamDeleteView.as_view(), name='company_team_delete'),
    path('company/teams/<str:team_id>/members/', views_company.TeamMembersView.as_view(), name='company_team_members'),
    path('company/teams/<str:team_id>/members/add/', views_company.AddTeamMemberView.as_view(), name='company_team_member_add'),
    path('company/teams/<str:team_id>/members/<str:user_id>/remove/', views_company.RemoveTeamMemberView.as_view(), name='company_team_member_remove'),

    # Company Hierarchy
    path('company/hierarchy/', views_company.CompanyHierarchyView.as_view(), name='company_hierarchy'),
]

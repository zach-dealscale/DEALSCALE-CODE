from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import SignupForm
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.views.decorators.http import require_GET
from .models import Company, Role
from django.contrib.auth.views import PasswordResetConfirmView
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_decode
from django.contrib.auth import get_user_model
import logging


logger = logging.getLogger(__name__)
User = get_user_model()


def signup(request):
    # Redirect logged-in users away from signup page
    if request.user.is_authenticated:
        from django.contrib import messages
        messages.warning(request, "You are already logged in.")
        return redirect("home")

    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)  # Do not save to database yet
            user.first_name = form.cleaned_data["first_name"]
            user.last_name = form.cleaned_data["last_name"]
            user.save()  # Now save to the database

            # Create company with the user as creator
            # The signal create_default_owner_role will automatically:
            # 1. Create Owner role for the company
            # 2. Assign Owner role to the user
            company_name = form.cleaned_data.get("company_name")
            company = Company.objects.create(
                name=company_name,
                created_by=user
            )

            # Set user's company
            user.company = company
            user.save()

            login(request, user)
            return redirect("home")
    else:
        form = SignupForm()
    return render(request, "authentication/signup.html", {"form": form})

@require_GET
def custom_logout(request):
    logout(request)
    return redirect('login')  # Redirect to your login page or home page


def custom_login(request):
    """
    Custom login view that redirects authenticated users away from login page.
    """
    # Redirect logged-in users away from login page
    if request.user.is_authenticated:
        from django.contrib import messages
        messages.warning(request, "You are already logged in.")
        return redirect("home")

    # Import here to avoid circular imports
    from django.contrib.auth.views import LoginView as DjangoLoginView
    from .forms import EmailLoginForm

    # Use Django's built-in LoginView with our custom authentication
    view = DjangoLoginView.as_view(
        template_name="authentication/login.html",
        authentication_form=EmailLoginForm,
        next_page='home'
    )
    return view(request)


class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    """
    Custom password reset confirm view that properly displays form errors.
    """
    template_name = 'authentication/password_reset_confirm.html'
    success_url = '/auth/password_reset_complete/'

    def post(self, request, *args, **kwargs):
        """
        Override post to ensure form errors are properly passed to the template.
        """
        # Get the user and validate the token
        uidb64 = kwargs.get('uidb64')
        token = kwargs.get('token')

        try:
            uid = urlsafe_base64_decode(uidb64).decode()
            user = User.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            user = None

        # Validate token
        if user is not None and default_token_generator.check_token(user, token):
            # Token is valid, process the form
            if request.method == 'POST':
                form = self.get_form()
                if form.is_valid():
                    # Set the user on the form
                    form.save()
                    return redirect(self.success_url)
                else:
                    # Form has errors, re-render with errors
                    return self.form_invalid(form)
        else:
            # Invalid token
            return self.render_to_response(self.get_context_data(validlink=False))

    def get_context_data(self, **kwargs):
        """Add form to context with proper error handling."""
        context = super().get_context_data(**kwargs)

        # Ensure form is in context
        if 'form' not in context:
            context['form'] = self.get_form()

        return context
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.html import format_html
from .models import CustomUser, Client, GuestUser, Company, Role, Team, TeamMembership, Invitation


# ==================== COMPANY ADMIN ====================

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    """Admin interface for Company (Tenant) management."""

    list_display = ('name', 'is_active', 'created_by', 'created_at', 'user_count')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'website')
    readonly_fields = ('id', 'created_at', 'updated_at')

    fieldsets = (
        ('Company Info', {
            'fields': ('id', 'name', 'website', 'logo')
        }),
        ('Organization', {
            'fields': ('created_by', 'is_active')
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def user_count(self, obj):
        """Display number of users in company."""
        return obj.users.filter(is_active_in_company=True).count()
    user_count.short_description = 'Active Users'

    def has_delete_permission(self, request, obj=None):
        """Prevent accidental company deletion."""
        return False


# ==================== ROLE ADMIN ====================

@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    """Admin interface for Role (Permission Level) management."""

    list_display = ('name', 'company', 'level', 'can_view_all_data', 'can_view_forecast', 'can_view_analytics', 'user_count')
    list_filter = ('company', 'level', 'can_manage_team', 'can_view_hierarchy_data', 'can_view_forecast', 'can_view_analytics')
    search_fields = ('name', 'company__name')
    readonly_fields = ('id', 'created_at', 'updated_at')

    fieldsets = (
        ('Role Info', {
            'fields': ('id', 'company', 'name', 'level', 'description')
        }),
        ('Admin & Data Access', {
            'fields': (
                'can_view_all_data',
                'can_view_hierarchy_data',
                'can_manage_roles',
                'can_manage_team',
                'can_manage_clients',
            ),
            'description': 'Configure admin and data access permissions'
        }),
        ('Feature Access', {
            'fields': (
                'can_view_forecast',
                'can_view_analytics',
            ),
            'description': 'Configure access to specific features'
        }),
        ('Core Capabilities', {
            'fields': (
                'can_upload_transcripts',
                'can_generate_reports',
            ),
            'description': 'Configure core feature capabilities'
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def user_count(self, obj):
        """Display number of users with this role."""
        return obj.users.filter(is_active_in_company=True).count()
    user_count.short_description = 'Users'


# ==================== TEAM ADMIN ====================

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    """Admin interface for Team management."""

    list_display = ('name', 'company', 'lead', 'member_count', 'created_at')
    list_filter = ('company', 'created_at')
    search_fields = ('name', 'company__name')
    readonly_fields = ('id', 'created_at', 'updated_at', 'member_count')

    fieldsets = (
        ('Team Info', {
            'fields': ('id', 'company', 'name', 'description')
        }),
        ('Leadership', {
            'fields': ('lead', 'created_by')
        }),
        ('Members', {
            'fields': ('member_count',),
            'description': 'See TeamMembership for detailed member management'
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def member_count(self, obj):
        """Display number of active members in team."""
        return obj.get_member_count()
    member_count.short_description = 'Active Members'


# ==================== TEAM MEMBERSHIP ADMIN ====================

@admin.register(TeamMembership)
class TeamMembershipAdmin(admin.ModelAdmin):
    """Admin interface for Team Membership (user ↔ team assignments)."""

    list_display = ('user_email', 'team_name', 'role_in_team', 'is_active', 'joined_at')
    list_filter = ('team__company', 'team', 'role_in_team', 'is_active', 'joined_at')
    search_fields = ('user__email', 'team__name', 'role_in_team')
    readonly_fields = ('id', 'joined_at', 'created_at', 'updated_at')

    fieldsets = (
        ('Membership Info', {
            'fields': ('id', 'user', 'team')
        }),
        ('Role & Status', {
            'fields': ('role_in_team', 'is_active')
        }),
        ('Metadata', {
            'fields': ('joined_at', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def user_email(self, obj):
        """Display user email."""
        return obj.user.email
    user_email.short_description = 'User'
    user_email.admin_order_field = 'user__email'

    def team_name(self, obj):
        """Display team name."""
        return obj.team.name
    team_name.short_description = 'Team'
    team_name.admin_order_field = 'team__name'


# ==================== CUSTOMUSER ADMIN (EXTENDED) ====================

class CustomUserAdmin(UserAdmin):
    """Enhanced admin interface for CustomUser with company & hierarchy."""

    list_display = ('email', 'company_display', 'role_display', 'team_count_display', 'is_active_in_company', 'is_staff')
    list_filter = ('company', 'role', 'is_active_in_company', 'is_staff', 'is_superuser', 'created_at')
    search_fields = ('email', 'first_name', 'last_name', 'company__name')
    readonly_fields = ('id', 'created_at', 'updated_at', 'joined_company_at', 'hierarchy_level', 'team_count_display')
    ordering = ('email',)  # Order by email instead of username (which we removed)

    fieldsets = (
        ('Authentication', {
            'fields': ('email', 'password', 'id')
        }),
        ('Personal Info', {
            'fields': ('first_name', 'last_name', 'profile_picture')
        }),
        ('Company & Organization', {
            'fields': ('company', 'role', 'is_active_in_company', 'joined_company_at')
        }),
        ('Teams', {
            'fields': ('team_count_display',),
            'description': 'Manage team memberships via TeamMembership section'
        }),
        ('Hierarchy', {
            'fields': ('manager', 'hierarchy_level'),
            'classes': ('collapse',),
            'description': 'Reporting structure'
        }),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')
        }),
        ('Important Dates', {
            'fields': ('last_login', 'date_joined', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2')
        }),
        ('Organization', {
            'fields': ('company', 'role', 'manager')
        }),
        ('Permissions', {
            'fields': ('is_staff', 'is_superuser', 'is_active')
        }),
    )

    def company_display(self, obj):
        """Display company name (or 'No Company' if not assigned)."""
        return obj.company.name if obj.company else '—'
    company_display.short_description = 'Company'

    def role_display(self, obj):
        """Display role name (or '—' if not assigned)."""
        return obj.role.name if obj.role else '—'
    role_display.short_description = 'Role'

    def team_count_display(self, obj):
        """Display count of teams user belongs to."""
        count = obj.get_team_count()
        return f"{count} team(s)" if count > 0 else "No teams"
    team_count_display.short_description = 'Teams'

    def hierarchy_level(self, obj):
        """Display hierarchy level (read-only)."""
        if not obj.company:
            return '—'
        try:
            return f"Level {obj.get_hierarchy_level()}"
        except:
            return 'Error'
    hierarchy_level.short_description = 'Hierarchy Level'


# ==================== CLIENT ADMIN (EXTENDED) ====================

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    """Enhanced admin interface for Client with company & ownership."""

    list_display = ('name', 'company', 'primary_owner', 'industry', 'created_at')
    list_filter = ('company', 'industry', 'created_at', 'created_by')
    search_fields = ('name', 'company__name', 'company_email', 'website')
    readonly_fields = ('id', 'created_at', 'document_count')

    fieldsets = (
        ('Client Info', {
            'fields': ('name', 'company_email', 'website', 'industry', 'company_size')
        }),
        ('Company & Organization', {
            'fields': ('company', 'primary_owner', 'created_by')
        }),
        ('Visual Assets', {
            'fields': ('company_logo',)
        }),
        ('Notes', {
            'fields': ('notes',)
        }),
        ('Metadata', {
            'fields': ('created_at', 'document_count'),
            'classes': ('collapse',)
        }),
    )

    def document_count(self, obj):
        """Display total documents count."""
        return obj.get_total_documents_count()
    document_count.short_description = 'Total Documents'


# ==================== GUESTUSER ADMIN ====================

@admin.register(GuestUser)
class GuestUserAdmin(admin.ModelAdmin):
    """Admin interface for GuestUser (non-authenticated access)."""

    list_display = ('email', 'name', 'is_verified', 'visit_count', 'created_at')
    list_filter = ('is_verified', 'created_at')
    search_fields = ('email', 'name')
    readonly_fields = ('created_at', 'last_login')


# ==================== INVITATION ADMIN ====================

@admin.register(Invitation)
class InvitationAdmin(admin.ModelAdmin):
    """Admin interface for User Invitations."""

    list_display = ('user_email', 'company_name', 'status_badge', 'invited_by_name', 'sent_at', 'expires_at', 'is_expired_display')
    list_filter = ('company', 'status', 'sent_at', 'expires_at')
    search_fields = ('user__email', 'company__name', 'invited_by__email')
    readonly_fields = ('id', 'token', 'sent_at', 'accepted_at', 'created_at', 'updated_at')

    fieldsets = (
        ('Invitation Info', {
            'fields': ('id', 'user', 'company', 'status')
        }),
        ('Invitation Details', {
            'fields': ('invited_by', 'sent_at', 'accepted_at')
        }),
        ('Token & Expiration', {
            'fields': ('token', 'expires_at', 'is_expired_display'),
            'description': 'Secure token for accepting invitation. Read-only.'
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def user_email(self, obj):
        """Display user email address."""
        return obj.user.email
    user_email.short_description = 'User Email'
    user_email.admin_order_field = 'user__email'

    def company_name(self, obj):
        """Display company name."""
        return obj.company.name
    company_name.short_description = 'Company'
    company_name.admin_order_field = 'company__name'

    def invited_by_name(self, obj):
        """Display name of user who sent the invitation."""
        if obj.invited_by:
            return obj.invited_by.get_full_name() or obj.invited_by.email
        return '—'
    invited_by_name.short_description = 'Invited By'
    invited_by_name.admin_order_field = 'invited_by__email'

    def status_badge(self, obj):
        """Display status with color-coded badge."""
        colors = {
            'pending': '#3b82f6',      # Blue
            'accepted': '#10b981',     # Green
            'expired': '#ef4444',      # Red
            'rejected': '#6b7280',     # Gray
        }
        color = colors.get(obj.status, '#9ca3af')
        return format_html(
            '<span style="padding: 3px 10px; border-radius: 4px; background-color: {}; color: white; font-weight: 500;">{}</span>',
            color,
            obj.get_status_display()
        )
    status_badge.short_description = 'Status'
    status_badge.admin_order_field = 'status'

    def is_expired_display(self, obj):
        """Display whether invitation has expired."""
        if obj.is_expired():
            return format_html('<span style="color: #ef4444; font-weight: 500;">✓ Expired</span>')
        return format_html('<span style="color: #10b981; font-weight: 500;">✓ Active</span>')
    is_expired_display.short_description = 'Expiration Status'


# Register CustomUser with enhanced admin
admin.site.register(CustomUser, CustomUserAdmin)

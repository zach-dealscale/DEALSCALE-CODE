"""
Company Management Views
- Company Settings
- Users Management
- Roles Management
- Teams Management
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.db.models import Count, Q
from django.utils import timezone
from django.http import JsonResponse
import json

from .models import Company, Role, Team, TeamMembership, CustomUser, Invitation
from .forms import (
    CompanyForm, RoleForm, UserEditForm, UserInviteForm,
    TeamForm, TeamMemberForm
)
from apps.core.services.email_service import EmailService
from apps.core.mixins import CompanyManagementAccessMixin


# ==================== COMPANY SETTINGS ====================

class CompanySettingsView(CompanyManagementAccessMixin, View):
    """Company overview and navigation - Admin only"""

    def get(self, request):
        company = request.user.company

        context = {
            'company': company,
            'total_users': company.users.filter(is_active_in_company=True).count(),
            'total_roles': company.roles.count(),
            'total_teams': company.teams.count(),
        }
        return render(request, 'authentication/company/settings/overview.html', context)


class CompanyEditView(CompanyManagementAccessMixin, View):
    """Edit company details - Admin only"""

    def get(self, request):
        company = request.user.company
        form = CompanyForm(instance=company)
        return render(request, 'authentication/company/settings/edit.html', {
            'form': form,
            'company': company
        })

    def post(self, request):
        company = request.user.company
        form = CompanyForm(request.POST, request.FILES, instance=company)

        if form.is_valid():
            form.save()
            messages.success(request, 'Company details updated successfully')
            return redirect('company_settings')

        return render(request, 'authentication/company/settings/edit.html', {
            'form': form,
            'company': company
        })


# ==================== ROLES MANAGEMENT ====================

class RoleListView(CompanyManagementAccessMixin, View):
    """List all roles for company - Admin only"""

    def get(self, request):
        company = request.user.company
        roles = company.roles.all().annotate(
            user_count=Count('users', filter=Q(users__is_active_in_company=True))
        ).order_by('level')

        context = {
            'roles': roles,
            'company': company,
        }
        return render(request, 'authentication/company/roles/list.html', context)


class RoleCreateView(CompanyManagementAccessMixin, View):
    """Create new role - Admin only"""

    def get(self, request):
        form = RoleForm()
        return render(request, 'authentication/company/roles/create.html', {
            'form': form
        })

    def post(self, request):
        form = RoleForm(request.POST)

        if form.is_valid():
            role = form.save(commit=False)
            role.company = request.user.company
            role.save()
            messages.success(request, f'Role "{role.name}" created successfully')
            return redirect('company_roles_list')

        return render(request, 'authentication/company/roles/create.html', {
            'form': form
        })


class RoleEditView(CompanyManagementAccessMixin, View):
    """Edit role - Owner role is completely read-only (system role)"""

    def get(self, request, role_id):
        role = get_object_or_404(Role, id=role_id, company=request.user.company)
        form = RoleForm(instance=role)

        # Disable ALL fields for Owner role (system role - read-only)
        if role.name == 'Owner':
            for field in form.fields:
                form.fields[field].disabled = True

        context = {
            'form': form,
            'role': role,
            'user_count': role.users.filter(is_active_in_company=True).count(),
            'is_owner_role': role.name == 'Owner',
        }
        return render(request, 'authentication/company/roles/edit.html', context)

    def post(self, request, role_id):
        role = get_object_or_404(Role, id=role_id, company=request.user.company)

        # Completely prevent Owner role from being edited
        if role.name == 'Owner':
            messages.warning(request, 'Cannot edit Owner role - this is a system role.')
            return redirect('company_roles_list')

        form = RoleForm(request.POST, instance=role)

        if form.is_valid():
            form.save()
            messages.success(request, f'Role "{role.name}" updated successfully')
            return redirect('company_roles_list')

        context = {
            'form': form,
            'role': role,
            'user_count': role.users.filter(is_active_in_company=True).count(),
            'is_owner_role': role.name == 'Owner',
        }
        return render(request, 'authentication/company/roles/edit.html', context)


class RoleDeleteView(CompanyManagementAccessMixin, View):
    """Delete role"""

    def post(self, request, role_id):
        role = get_object_or_404(Role, id=role_id, company=request.user.company)

        # Prevent deletion if users are assigned
        if role.users.filter(is_active_in_company=True).exists():
            messages.error(request, 'Cannot delete role with assigned users. Reassign users first.')
            return redirect('company_roles_list')

        role_name = role.name
        role.delete()
        messages.success(request, f'Role "{role_name}" deleted successfully')
        return redirect('company_roles_list')


# ==================== USERS MANAGEMENT ====================

class UserListView(CompanyManagementAccessMixin, View):
    """List all users in company"""

    def get(self, request):
        company = request.user.company
        status = request.GET.get('status', 'active')

        if status == 'pending':
            # Show users with pending invitations
            users = company.users.filter(
                invitations_received__status=Invitation.PENDING,
                is_active_in_company=False
            ).select_related('role', 'manager').distinct().order_by('-invitations_received__sent_at')
        else:
            users = company.users.all().select_related('role', 'manager').order_by('-is_active_in_company', 'email')

            if status == 'active':
                users = users.filter(is_active_in_company=True)
            elif status == 'inactive':
                users = users.filter(is_active_in_company=False)

        context = {
            'users': users,
            'status': status,
            'company': company,
        }
        return render(request, 'authentication/company/users/list.html', context)


class UserInviteView(CompanyManagementAccessMixin, View):
    """Invite new user to company"""

    def get(self, request):
        form = UserInviteForm(company=request.user.company)

        return render(request, 'authentication/company/users/invite.html', {
            'form': form
        })

    def post(self, request):
        from apps.core.tasks import send_user_invitation_email_task

        form = UserInviteForm(request.POST, company=request.user.company)

        if form.is_valid():
            email = form.cleaned_data['email']
            role = form.cleaned_data['role']
            first_name = form.cleaned_data.get('first_name', '')
            last_name = form.cleaned_data.get('last_name', '')
            manager = form.cleaned_data.get('manager')

            try:
                # Check if user already exists in this company
                user = CustomUser.objects.get(email=email, company=request.user.company)
                messages.warning(request, f'User {email} is already in your company')
                return redirect('company_users_list')
            except CustomUser.DoesNotExist:
                # Create new user with empty password (invited status)
                user = CustomUser.objects.create_user(
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                    password=None,  # No password set yet
                )

                # Assign to company
                user.company = request.user.company
                user.role = role
                user.manager = manager  # Assign the selected manager
                user.is_active_in_company = False  # Invited users are initially inactive
                user.save()

                # Create invitation record
                invitation, _ = Invitation.objects.get_or_create(
                    user=user,
                    company=request.user.company,
                    defaults={
                        'invited_by': request.user,
                    }
                )

                # Send invitation email asynchronously via Celery
                send_user_invitation_email_task.delay(invitation.id)

                messages.success(
                    request,
                    f'Invitation sent to {email}! They will need to accept the invitation and set a password to join.'
                )
                return redirect('company_users_list')

        return render(request, 'authentication/company/users/invite.html', {
            'form': form
        })


class UserEditView(CompanyManagementAccessMixin, View):
    """Edit user details"""

    def get(self, request, user_id):
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)
        form = UserEditForm(instance=user, company=request.user.company, user_id=user_id)

        context = {
            'form': form,
            'user_obj': user,
            'teams': user.get_teams(),
        }
        return render(request, 'authentication/company/users/edit.html', context)

    def post(self, request, user_id):
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)
        form = UserEditForm(request.POST, instance=user, company=request.user.company, user_id=user_id)

        if form.is_valid():
            form.save()
            messages.success(request, f'User {user.email} updated successfully')
            return redirect('company_users_list')

        context = {
            'form': form,
            'user_obj': user,
            'teams': user.get_teams(),
        }
        return render(request, 'authentication/company/users/edit.html', context)


class UserDeactivateView(CompanyManagementAccessMixin, View):
    """Deactivate user"""

    def post(self, request, user_id):
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)

        user.is_active_in_company = False
        user.save()

        messages.success(request, f'User {user.email} deactivated')
        return redirect('company_users_list')


class UserReactivateView(CompanyManagementAccessMixin, View):
    """Reactivate user"""

    def post(self, request, user_id):
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)

        user.is_active_in_company = True
        user.joined_company_at = timezone.now()
        user.save()

        messages.success(request, f'User {user.email} reactivated')
        return redirect('company_users_list')


class UserDeleteView(CompanyManagementAccessMixin, View):
    """Permanently delete user"""

    def post(self, request, user_id):
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)

        # Prevent deleting the current user
        if user == request.user:
            messages.error(request, 'You cannot delete your own account')
            return redirect('company_users_list')

        email = user.email
        user.delete()

        messages.success(request, f'User {email} has been permanently deleted')
        return redirect('company_users_list')


# ==================== INVITATION SYSTEM ====================

class ResendInvitationView(CompanyManagementAccessMixin, View):
    """Resend invitation email to a user"""

    def post(self, request, user_id):
        from apps.core.tasks import send_user_invitation_email_task

        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)

        try:
            # Get the pending invitation
            invitation = Invitation.objects.get(user=user, company=request.user.company, status=Invitation.PENDING)

            # Resend the invitation email
            send_user_invitation_email_task.delay(invitation.id)

            messages.success(request, f'Invitation resent to {user.email}')
        except Invitation.DoesNotExist:
            messages.error(request, f'No pending invitation found for {user.email}')

        return redirect('company_users_list')


class AcceptInvitationView(View):
    """Accept user invitation and set password"""

    def get(self, request, token):
        try:
            invitation = Invitation.objects.get(token=token)

            # Check if invitation is still valid
            if invitation.status != Invitation.PENDING:
                messages.error(request, 'This invitation is no longer valid')
                return redirect('login')

            if invitation.is_expired():
                # Mark as expired
                invitation.status = Invitation.EXPIRED
                invitation.save()
                messages.error(request, 'This invitation has expired. Please ask your administrator to send a new one.')
                return redirect('login')

            # Show password setup form
            context = {
                'invitation': invitation,
                'email': invitation.user.email,
                'company_name': invitation.company.name,
            }
            return render(request, 'authentication/accept_invitation.html', context)

        except Invitation.DoesNotExist:
            messages.error(request, 'Invalid invitation link')
            return redirect('login')

    def post(self, request, token):
        try:
            invitation = Invitation.objects.get(token=token)

            # Validate invitation
            if invitation.status != Invitation.PENDING:
                messages.error(request, 'This invitation is no longer valid')
                return redirect('login')

            if invitation.is_expired():
                invitation.status = Invitation.EXPIRED
                invitation.save()
                messages.error(request, 'This invitation has expired')
                return redirect('login')

            # Get password from form
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            # Validate passwords
            if not password:
                messages.error(request, 'Password is required')
                context = {
                    'invitation': invitation,
                    'email': invitation.user.email,
                    'company_name': invitation.company.name,
                }
                return render(request, 'authentication/accept_invitation.html', context)

            if password != confirm_password:
                messages.error(request, 'Passwords do not match')
                context = {
                    'invitation': invitation,
                    'email': invitation.user.email,
                    'company_name': invitation.company.name,
                }
                return render(request, 'authentication/accept_invitation.html', context)

            if len(password) < 8:
                messages.error(request, 'Password must be at least 8 characters long')
                context = {
                    'invitation': invitation,
                    'email': invitation.user.email,
                    'company_name': invitation.company.name,
                }
                return render(request, 'authentication/accept_invitation.html', context)

            # Set password and activate user
            user = invitation.user
            user.set_password(password)
            user.is_active = True
            user.is_active_in_company = True
            user.joined_company_at = timezone.now()
            user.save()

            # Mark invitation as accepted
            invitation.status = Invitation.ACCEPTED
            invitation.accepted_at = timezone.now()
            invitation.save()

            messages.success(request, 'Your invitation has been accepted! You can now log in with your email and password.')
            return redirect('login')

        except Invitation.DoesNotExist:
            messages.error(request, 'Invalid invitation link')
            return redirect('login')


# ==================== TEAMS MANAGEMENT ====================

class TeamListView(CompanyManagementAccessMixin, View):
    """List all teams"""

    def get(self, request):
        company = request.user.company
        teams = company.teams.all().annotate(
            member_count=Count('memberships', filter=Q(memberships__is_active=True))
        ).order_by('name')

        context = {
            'teams': teams,
            'company': company,
        }
        return render(request, 'authentication/company/teams/list.html', context)


class TeamCreateView(CompanyManagementAccessMixin, View):
    """Create new team"""

    def get(self, request):
        form = TeamForm(company=request.user.company)

        return render(request, 'authentication/company/teams/create.html', {
            'form': form
        })

    def post(self, request):
        form = TeamForm(request.POST, company=request.user.company)

        if form.is_valid():
            team = form.save(commit=False)
            team.company = request.user.company
            team.created_by = request.user
            team.save()

            messages.success(request, f'Team "{team.name}" created successfully')
            return redirect('company_teams_list')

        return render(request, 'authentication/company/teams/create.html', {
            'form': form
        })


class TeamEditView(CompanyManagementAccessMixin, View):
    """Edit team"""

    def get(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        form = TeamForm(instance=team, company=request.user.company)

        context = {
            'form': form,
            'team': team,
        }
        return render(request, 'authentication/company/teams/edit.html', context)

    def post(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        form = TeamForm(request.POST, instance=team, company=request.user.company)

        if form.is_valid():
            form.save()
            messages.success(request, f'Team "{team.name}" updated successfully')
            return redirect('company_teams_list')

        context = {
            'form': form,
            'team': team,
        }
        return render(request, 'authentication/company/teams/edit.html', context)


class TeamDeleteView(CompanyManagementAccessMixin, View):
    """Delete team"""

    def post(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        team_name = team.name
        team.delete()

        messages.success(request, f'Team "{team_name}" deleted')
        return redirect('company_teams_list')


class TeamMembersView(CompanyManagementAccessMixin, View):
    """View and manage team members"""

    def get(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        memberships = team.memberships.filter(is_active=True).select_related('user')

        context = {
            'team': team,
            'memberships': memberships,
        }
        return render(request, 'authentication/company/teams/members.html', context)


class AddTeamMemberView(CompanyManagementAccessMixin, View):
    """Add member to team"""

    def get(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        form = TeamMemberForm(company=request.user.company, team=team)

        context = {
            'form': form,
            'team': team,
        }
        return render(request, 'authentication/company/teams/add_member.html', context)

    def post(self, request, team_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        form = TeamMemberForm(request.POST, company=request.user.company, team=team)

        if form.is_valid():
            user = form.cleaned_data['user']
            user.add_to_team(team, form.cleaned_data.get('role_in_team'))

            messages.success(request, f'{user.email} added to team')
            return redirect('company_team_members', team_id=team_id)

        context = {
            'form': form,
            'team': team,
        }
        return render(request, 'authentication/company/teams/add_member.html', context)


class RemoveTeamMemberView(CompanyManagementAccessMixin, View):
    """Remove member from team"""

    def post(self, request, team_id, user_id):
        team = get_object_or_404(Team, id=team_id, company=request.user.company)
        user = get_object_or_404(CustomUser, id=user_id, company=request.user.company)

        user.remove_from_team(team)
        messages.success(request, f'{user.email} removed from team')

        return redirect('company_team_members', team_id=team_id)


# ==================== HIERARCHY ====================

class CompanyHierarchyView(LoginRequiredMixin, View):
    """Display company organizational hierarchy/org chart"""

    def get(self, request):
        company = request.user.company
        if not company:
            messages.error(request, 'Company not found')
            return redirect('home')

        # Get all active users in the company
        users = CustomUser.objects.filter(
            company=company,
            is_active_in_company=True
        ).select_related('manager')

        # Build hierarchy data for GoJS TreeModel
        node_data_array = []

        for user in users:
            # Create node for each user
            node = {
                "key": user.id,
                "name": user.get_full_name() or user.email,
                "title": user.role.name if user.role else "No Role",
                "email": user.email,
                "profile_picture": user.profile_picture.url if user.profile_picture else None,
            }

            # Add parent key if user has a manager (unless user is the company owner)
            if user.manager and user.id != company.created_by_id:
                node["parent"] = user.manager.id
            elif company.created_by and user.id != company.created_by_id:
                # If no manager and not the owner, make the owner their parent (orphaned users under owner)
                # Only if they're not the owner themselves
                pass  # Don't set parent, let them be at root level

            node_data_array.append(node)

        context = {
            'company': company,
            'node_data': node_data_array,
            'total_users': users.count(),
            'has_hierarchy': any(user.manager for user in users),
            'owner': company.created_by,
        }

        return render(request, 'authentication/company/hierarchy.html', context)

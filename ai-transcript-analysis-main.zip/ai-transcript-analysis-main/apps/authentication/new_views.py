# views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView
from django.http import JsonResponse
from django.contrib import messages
from django.urls import reverse
from django.db.models import Q
from collections import defaultdict
import json
from django.utils import timezone

from apps.authentication.models import Client
from apps.report_management.models import (
    Transcript, ReportFormation, ReportDocument, 
    ReportTemplate, Category, PinnedReportTemplate
)


class DealDetailView(LoginRequiredMixin, ListView):
    template_name = "client/company_detail_new.html"
    context_object_name = 'transcripts'
    paginate_by = 10

    def get_queryset(self):
        self.client = get_object_or_404(Client, pk=self.kwargs['pk'])
        return Transcript.objects.filter(client=self.client).order_by('-created_at')

    def post(self, request, *args, **kwargs):
        """Handle framework generation form submission"""
        self.client = get_object_or_404(Client, pk=self.kwargs['pk'])
        
        transcript_id = request.POST.get('transcript_id')
        template_ids = request.POST.getlist('templates')
        
        if not transcript_id:
            messages.error(request, 'Please select a transcript.')
            return redirect(request.path)
            
        if not template_ids:
            messages.error(request, 'Please select at least one framework template.')
            return redirect(request.path)
        
        try:
            transcript = get_object_or_404(Transcript, id=transcript_id, client=self.client)
            templates = ReportTemplate.objects.filter(id__in=template_ids)
            
            created_reports = []
            for template in templates:
                # Create report formation
                report = ReportFormation.objects.create(
                    template=template,
                    transcript=transcript,
                    user=request.user,
                    status='pending',
                    company=request.user.company,
                    created_by=request.user,
                )
                created_reports.append(report)
                
                # Update template usage stats
                template.usage_count += 1
                template.last_used = timezone.now()
                template.save()
            
            # Here you would typically trigger the AI processing
            # For now, we'll just set status to completed for demo
            for report in created_reports:
                # In real implementation, this would be async/celery task
                # process_report_with_ai.delay(report.id)
                pass
            
            messages.success(
                request, 
                f'Successfully created {len(created_reports)} framework report(s). '
                f'Processing will begin shortly.'
            )
            
            # Redirect to reports tab
            return redirect(f"{request.path}#reports")
            
        except Exception as e:
            messages.error(request, f'Error creating reports: {str(e)}')
            return redirect(request.path)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        transcripts = self.get_queryset()

        # Selected transcript (if any from GET param)
        transcript_id = self.request.GET.get("transcript")
        selected_transcript = None
        selected_transcript_json = None
        
        if transcript_id:
            selected_transcript = Transcript.objects.filter(
                id=transcript_id, 
                client=self.client
            ).first()
            
            if selected_transcript:
                selected_transcript_json = {
                    'id': selected_transcript.id,
                    'title': selected_transcript.title,
                    'platform': selected_transcript.get_platform_display() if selected_transcript.platform else 'Unknown',
                    'created_at': selected_transcript.created_at.strftime('%B %d, %Y'),
                    'client_name': selected_transcript.client.name if selected_transcript.client else '',
                    'client_logo': selected_transcript.client.company_logo.url if (
                        selected_transcript.client and 
                        selected_transcript.client.company_logo
                    ) else None
                }

        # Categories with Subcategories & Templates - optimized query
        categories = Category.objects.prefetch_related(
            'subcategory_set__reporttemplate_set'
        ).all()

        first_category = categories[0].name if categories else ''
        
        # Get pinned and recent templates for current user
        pinned_reports = ReportTemplate.objects.filter(
            pinned_by_users__user=self.request.user
        ).distinct()
        
        recent_reports = ReportTemplate.objects.filter(
            templates__user=self.request.user
        ).order_by('-last_used').distinct()[:4]  # Increased to 4 for better UX

        # Get reports and documents for this client
        reports = ReportFormation.objects.filter(
            transcript__client=self.client
        ).select_related('template', 'transcript').order_by('-created_at')
        
        documents = ReportDocument.objects.filter(
            report__transcript__client=self.client
        ).select_related('report', 'report__template', 'sales_room').order_by('-created_at')

        # Statistics
        statistics = {
            'total_transcripts': transcripts.count(),
            'total_reports': reports.count(),
            'total_documents': documents.count(),
            'recent_activity': (
                transcripts.first().created_at 
                if transcripts.exists() else None
            ),
        }

        context.update({
            'client': self.client,
            'reports': reports,
            'documents': documents,
            'statistics': statistics,
            'selected_transcript': json.dumps(selected_transcript_json),
            'first_category': first_category,
            'categories': categories,
            'pinned_reports': pinned_reports,
            'recent_reports': recent_reports,
        })
        return context


def toggle_template_pin(request, template_id):
    """AJAX endpoint to toggle template pin status"""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required'}, status=401)
    
    if request.method != 'POST':
        return JsonResponse({'error': 'POST method required'}, status=405)
    
    try:
        template = get_object_or_404(ReportTemplate, id=template_id)
        
        pinned_template, created = PinnedReportTemplate.objects.get_or_create(
            user=request.user,
            template=template
        )
        
        if not created:
            # Already pinned, so unpin it
            pinned_template.delete()
            is_pinned = False
        else:
            # Newly pinned
            is_pinned = True
        
        return JsonResponse({
            'success': True,
            'is_pinned': is_pinned,
            'template_id': template_id
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


def create_transcript(request):
    """Handle transcript creation from modal"""
    if not request.user.is_authenticated:
        return redirect('login')
    
    if request.method != 'POST':
        return JsonResponse({'error': 'POST method required'}, status=405)
    
    try:
        client_id = request.POST.get('client')
        client = get_object_or_404(Client, id=client_id)
        
        # Check if user has access to this client
        # Add your permission checks here
        
        text_content = request.POST.get('text', '').strip()
        uploaded_file = request.FILES.get('file')
        
        if not text_content and not uploaded_file:
            messages.error(request, 'Please provide either text content or upload a file.')
            return redirect('deal_detail', pk=client_id)
        
        # Create transcript
        transcript = Transcript.objects.create(
            client=client,
            user=request.user,
            text=text_content if text_content else None,
            file=uploaded_file if uploaded_file else None,
            company=request.user.company,
            uploaded_by=request.user,
        )
        
        messages.success(
            request, 
            f'Transcript "{transcript.title}" created successfully!'
        )
        
        # Redirect back to client detail with transcript selected
        return redirect(f"{reverse('deal_detail', args=[client_id])}?transcript={transcript.id}#transcripts")
        
    except Exception as e:
        messages.error(request, f'Error creating transcript: {str(e)}')
        return redirect('deal_detail', pk=request.POST.get('client', ''))


def search_transcripts(request, client_id):
    """AJAX endpoint for transcript search"""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required'}, status=401)
    
    client = get_object_or_404(Client, pk=client_id)
    query = request.GET.get('q', '').strip()
    
    transcripts = Transcript.objects.filter(client=client)
    
    if query:
        transcripts = transcripts.filter(
            Q(title__icontains=query) | 
            Q(text__icontains=query)
        )
    
    transcripts = transcripts.order_by('-created_at')[:20]  # Limit results
    
    results = []
    for transcript in transcripts:
        results.append({
            'id': transcript.id,
            'title': transcript.title,
            'platform': transcript.get_platform_display() if transcript.platform else 'Unknown',
            'created_at': transcript.created_at.strftime('%B %d, %Y'),
            'client_name': transcript.client.name if transcript.client else '',
            'client_logo': (
                transcript.client.company_logo.url 
                if transcript.client and transcript.client.company_logo 
                else None
            ),
            'text_preview': transcript.text[:100] + '...' if transcript.text else ''
        })
    
    return JsonResponse({
        'success': True,
        'results': results,
        'count': len(results)
    })



# Generated migration to update stage choices and values

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('authentication', '0009_role_can_view_analytics_role_can_view_forecast'),
    ]

    operations = [
        # First, update all existing stage values
        migrations.RunPython(
            code=lambda apps, schema_editor: update_stage_values(apps, schema_editor),
            reverse_code=lambda apps, schema_editor: None,  # No reverse needed
        ),
        # Then update the field choices and default
        migrations.AlterField(
            model_name='client',
            name='stage',
            field=models.CharField(
                choices=[
                    ('discovery', 'Discovery'),
                    ('evaluation', 'Evaluation'),
                    ('validation', 'Validation'),
                    ('procurement', 'Procurement'),
                    ('closed_won', 'Closed Won'),
                    ('closed_lost', 'Closed Lost')
                ],
                db_index=True,
                default='discovery',
                max_length=50
            ),
        ),
    ]


def update_stage_values(apps, schema_editor):
    """Update existing client stage values from old names to new names"""
    Client = apps.get_model('authentication', 'Client')

    # Mapping from old stage names to new ones
    stage_mapping = {
        'prospecting': 'discovery',
        'qualification': 'evaluation',
        'needs_analysis': 'validation',
        'proposal': 'procurement',
        'negotiation': 'procurement',
    }

    for old_stage, new_stage in stage_mapping.items():
        Client.objects.filter(stage=old_stage).update(stage=new_stage)

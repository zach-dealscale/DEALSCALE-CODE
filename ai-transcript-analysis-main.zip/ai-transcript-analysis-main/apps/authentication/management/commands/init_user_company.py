"""
Management Command: init_user_company

Purpose:
- Create a company for a user (or all users without companies)
- Auto-create "Owner" role for the company
- Assign user as Owner of the company
- Link all user's data (Transcripts, Reports, Clients) to the company
- Generate audit log of all changes

Usage:
    python manage.py init_user_company                    # All users without companies
    python manage.py init_user_company --email test@ex.com # Specific user
    python manage.py init_user_company --dry-run           # Test without changes
"""

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils.text import slugify
from django.utils import timezone
from django.contrib.auth import get_user_model
import json

from apps.authentication.models import Company, Role, Team
from apps.report_management.models import Transcript, ReportDocument, ReportFormation

User = get_user_model()


class Command(BaseCommand):
    help = "Initialize company for users - create company, Owner role, link data"

    def add_arguments(self, parser):
        parser.add_argument(
            '--email',
            type=str,
            help='Email of specific user to initialize',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Test without making changes',
        )
        parser.add_argument(
            '--verbose',
            action='store_true',
            help='Show detailed output',
        )

    def handle(self, *args, **options):
        """Main command handler"""
        dry_run = options.get('dry_run', False)
        email = options.get('email')
        verbose = options.get('verbose', False)

        if email:
            # Specific user mode
            try:
                users = [User.objects.get(email=email)]
                self.stdout.write(
                    self.style.SUCCESS(f'Processing user: {email}')
                )
            except User.DoesNotExist:
                raise CommandError(f'User with email {email} not found')
        else:
            # All users without companies
            users = User.objects.filter(company__isnull=True)
            count = users.count()
            if count == 0:
                self.stdout.write(
                    self.style.WARNING('No users without companies found!')
                )
                return
            self.stdout.write(
                self.style.SUCCESS(f'Found {count} users without companies')
            )

        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('PHASE 1: CREATE COMPANIES FOR USERS')
        self.stdout.write('=' * 60)

        # PHASE 1: Create companies for all users
        audit_log = []
        success_count = 0
        error_count = 0

        for user in users:
            try:
                result = self._create_user_company(user, dry_run, verbose)
                if result:
                    audit_log.append(result)
                    success_count += 1
                    self.stdout.write(
                        self.style.SUCCESS(f'✓ {user.email}')
                    )
            except Exception as e:
                error_count += 1
                self.stdout.write(
                    self.style.ERROR(f'✗ {user.email}: {str(e)}')
                )
                if verbose:
                    import traceback
                    traceback.print_exc()

        if dry_run:
            self.stdout.write(
                self.style.WARNING('\n[DRY RUN] Skipping phases 2-4')
            )
            self._print_summary(success_count, error_count, dry_run, audit_log)
            return

        # PHASE 2: Link all clients to their user's company
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('PHASE 2: LINK CLIENTS TO COMPANIES')
        self.stdout.write('=' * 60)
        client_count = self._link_all_clients(verbose)

        # PHASE 3: Link all other entities (transcripts, reports, documents, etc)
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('PHASE 3: LINK REPORT & TRANSCRIPT ENTITIES')
        self.stdout.write('=' * 60)
        transcript_count = self._link_all_transcripts(verbose)
        report_count = self._link_all_reports(verbose)
        report_formation_count = self._link_all_report_formations(verbose)

        # PHASE 4: Link Deal Room entities
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('PHASE 4: LINK Deal Room ENTITIES')
        self.stdout.write('=' * 60)
        sales_room_count = self._link_all_sales_rooms(verbose)

        # Print summary
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('SUMMARY')
        self.stdout.write('=' * 60)
        self.stdout.write(
            self.style.SUCCESS(f'✓ Users initialized: {success_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✓ Clients linked: {client_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✓ Transcripts linked: {transcript_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✓ Reports linked: {report_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✓ Report Formations linked: {report_formation_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✓ Deal Rooms linked: {sales_room_count}')
        )
        if error_count > 0:
            self.stdout.write(
                self.style.ERROR(f'✗ Errors: {error_count}')
            )
        self.stdout.write('=' * 60)

    def _create_user_company(self, user, dry_run=False, verbose=False):
        """
        PHASE 1: Create company for a single user (if not exists) and make them owner.
        """
        if verbose:
            self.stdout.write(f'\n  Processing {user.email}...')

        # Check if user already has a company
        if user.company:
            if verbose:
                self.stdout.write(f'    → Already has company: {user.company.name}')
            return None

        # Step 1: Create Company
        company_name = f"{user.email.split('@')[0]}'s Company"
        if verbose:
            self.stdout.write(f'    Creating company: {company_name}')

        if dry_run:
            return {
                'email': user.email,
                'company_name': company_name,
                'role': 'Owner',
                'dry_run': True,
                'timestamp': timezone.now().isoformat(),
            }

        # Save company (signal will auto-create Owner role)
        with transaction.atomic():
            company = Company(
                name=company_name,
                created_by=user,
            )
            company.save()

            # Assign user to company and the auto-created Owner role
            user.company = company
            user.role = Role.objects.get(company=company, name='Owner')
            user.is_active_in_company = True
            user.joined_company_at = timezone.now()
            user.save()

            if verbose:
                self.stdout.write(f'    ✓ Created company & assigned owner')

        return {
            'email': user.email,
            'company_id': company.id,
            'company_name': company_name,
            'role': 'Owner',
            'dry_run': False,
            'timestamp': timezone.now().isoformat(),
        }

    def _link_all_clients(self, verbose=False):
        """
        PHASE 2: Link all clients to their associated user's company.
        Since users now all have companies, link each client to its user's company.
        """
        from apps.authentication.models import Client

        # Find all clients where user exists but company is not linked
        clients = Client.objects.filter(user__isnull=False, company__isnull=True)
        count = 0

        if verbose:
            self.stdout.write(f'  Found {clients.count()} clients to link')

        for client in clients:
            if client.user and client.user.company:
                client.company = client.user.company
                client.created_by = client.user  # Set created_by to the user field
                if not client.primary_owner:
                    client.primary_owner = client.user
                client.save()
                count += 1
                if verbose:
                    self.stdout.write(f'    ✓ Linked {client.name} to {client.user.email}\'s company')

        self.stdout.write(self.style.SUCCESS(f'  ✓ Linked {count} clients'))
        return count

    def _link_all_transcripts(self, verbose=False):
        """
        PHASE 3: Link all transcripts to their associated user's company.
        """
        # Find all transcripts where user exists but company is not linked
        transcripts = Transcript.objects.filter(user__isnull=False, company__isnull=True)
        count = 0

        if verbose:
            self.stdout.write(f'  Found {transcripts.count()} transcripts to link')

        for transcript in transcripts:
            if transcript.user and transcript.user.company:
                transcript.company = transcript.user.company
                transcript.uploaded_by = transcript.user
                # Ensure client is also linked to company if needed
                if transcript.client and not transcript.client.company:
                    transcript.client.company = transcript.user.company
                    transcript.client.save()
                transcript.save()
                count += 1
                if verbose:
                    self.stdout.write(f'    ✓ Linked transcript {transcript.title}')

        self.stdout.write(self.style.SUCCESS(f'  ✓ Linked {count} transcripts'))
        return count

    def _link_all_reports(self, verbose=False):
        """
        PHASE 3: Link all report documents to their associated user's company.
        """
        # Find all reports where user exists but company is not linked
        reports = ReportDocument.objects.filter(user__isnull=False, company__isnull=True)
        count = 0

        if verbose:
            self.stdout.write(f'  Found {reports.count()} reports to link')

        for report in reports:
            if report.user and report.user.company:
                report.company = report.user.company
                report.created_by = report.user
                # Ensure client is also linked to company if needed
                if report.client and not report.client.company:
                    report.client.company = report.user.company
                    report.client.save()
                report.save()
                count += 1
                if verbose:
                    self.stdout.write(f'    ✓ Linked report {report.title}')

        self.stdout.write(self.style.SUCCESS(f'  ✓ Linked {count} reports'))
        return count

    def _link_all_report_formations(self, verbose=False):
        """
        PHASE 3: Link all report formations to their associated user's company.
        """
        from apps.report_management.models import ReportFormation

        # Find all report formations where user exists but company is not linked
        formations = ReportFormation.objects.filter(user__isnull=False, company__isnull=True)
        count = 0

        if verbose:
            self.stdout.write(f'  Found {formations.count()} report formations to link')

        for formation in formations:
            if formation.user and formation.user.company:
                formation.company = formation.user.company
                formation.created_by = formation.user
                # Ensure related client is also linked if needed
                if formation.client and not formation.client.company:
                    formation.client.company = formation.user.company
                    formation.client.save()
                formation.save()
                count += 1
                if verbose:
                    self.stdout.write(f'    ✓ Linked report formation {formation.template.title}')

        self.stdout.write(self.style.SUCCESS(f'  ✓ Linked {count} report formations'))
        return count

    def _link_all_sales_rooms(self, verbose=False):
        """
        PHASE 4: Link all Deal Rooms to their associated user's company.
        """
        from apps.sale_rooms.models import SalesRoom

        # Find all Deal Rooms where user exists but company is not linked
        rooms = SalesRoom.objects.filter(user__isnull=False, company__isnull=True)
        count = 0

        if verbose:
            self.stdout.write(f'  Found {rooms.count()} Deal Rooms to link')

        for room in rooms:
            if room.user and room.user.company:
                room.company = room.user.company
                room.created_by = room.user
                # Ensure related client is also linked if needed
                if room.client and not room.client.company:
                    room.client.company = room.user.company
                    room.client.save()
                room.save()
                count += 1
                if verbose:
                    self.stdout.write(f'    ✓ Linked Deal Room {room.name}')

        self.stdout.write(self.style.SUCCESS(f'  ✓ Linked {count} Deal Rooms'))
        return count

    def _print_summary(self, success_count, error_count, dry_run, audit_log):
        """Print final summary and audit log"""
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('SUMMARY')
        self.stdout.write('=' * 60)

        if dry_run:
            self.stdout.write(
                self.style.WARNING('DRY RUN MODE - No changes were committed')
            )

        self.stdout.write(
            self.style.SUCCESS(f'✓ Successfully processed: {success_count}')
        )

        if error_count > 0:
            self.stdout.write(
                self.style.ERROR(f'✗ Errors: {error_count}')
            )

        self.stdout.write('\n' + '=' * 60)
        self.stdout.write('AUDIT LOG')
        self.stdout.write('=' * 60)

        for entry in audit_log:
            self.stdout.write(f'\nUser: {entry["email"]}')
            self.stdout.write(f'  Company: {entry["company_name"]}')
            self.stdout.write(f'  Role: {entry["role"]}')
            self.stdout.write(f'  Transcripts linked: {entry["transcripts_linked"]}')
            self.stdout.write(f'  Reports linked: {entry["reports_linked"]}')
            self.stdout.write(f'  Clients linked: {entry["clients_linked"]}')
            if entry.get('company_id'):
                self.stdout.write(f'  Company ID: {entry["company_id"]}')

        self.stdout.write('\n' + '=' * 60)

        # Save audit log to file
        if audit_log:
            timestamp = timezone.now().strftime('%Y%m%d_%H%M%S')
            filename = f'audit_init_user_company_{timestamp}.json'
            with open(filename, 'w') as f:
                json.dump(audit_log, f, indent=2)
            self.stdout.write(
                self.style.SUCCESS(f'Audit log saved to: {filename}')
            )

# model
from apps.authentication.user_profile_picture_generator import generate_default_profile_picture
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.utils import timezone

User = get_user_model()  # Dynamically get the user model


# assets
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.files.base import ContentFile


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        full_name = f"{instance.first_name} {instance.last_name}"
        email = instance.email
        main_text = ""
        if instance.first_name or instance.last_name:
            main_text = f"{instance.first_name} {instance.last_name}"
        else:
            main_text = email.split("@")[0]


        profile_picture_buffer = generate_default_profile_picture(
            full_name=main_text
        )
        instance.profile_picture.save(
            f"{profile_picture_buffer[0]}_profile.jpg",
            ContentFile(profile_picture_buffer[1].getvalue()),
        )


# ==================== CACHE INVALIDATION SIGNALS ====================

@receiver(post_save, sender=User)
def invalidate_subordinate_cache(sender, instance, created=False, **kwargs):
    """
    Clear cache when user's manager changes or on creation.

    Invalidates:
    - This user's subordinate IDs cache
    - Manager's subordinate IDs cache (since their team changed)
    """
    # Clear this user's cache (they got new subordinates or lost manager)
    cache_key = f"user_subordinates_{instance.id}"
    cache.delete(cache_key)

    # Clear manager's cache (since their subordinates list changed)
    if instance.manager:
        manager_cache_key = f"user_subordinates_{instance.manager.id}"
        cache.delete(manager_cache_key)


# ==================== COMPANY ROLE CREATION SIGNAL ====================

@receiver(post_save, sender='authentication.Company')
def create_default_owner_role(sender, instance, created=False, **kwargs):
    """
    Automatically create 'Owner' role for new companies and assign it to company creator.

    When a Company is created:
    1. Create 'Owner' role with full permissions
    2. Assign the role to company.created_by user

    Only creates if:
    - Company is newly created (created=True)
    - Owner role doesn't already exist for this company
    """
    if not created:
        return

    from apps.authentication.models import Role

    # Check if Owner role already exists for this company
    owner_role = Role.objects.filter(
        company=instance,
        name='Owner'
    ).first()

    if not owner_role:
        # Create Owner role with full permissions
        owner_role = Role(
            company=instance,
            name='Owner',
            level=0,
            description='Full control of company - default role'
        )
        owner_role.set_full_permissions()
        owner_role.save()

    # Assign Owner role to company creator
    if instance.created_by:
        instance.created_by.role = owner_role
        instance.created_by.save()

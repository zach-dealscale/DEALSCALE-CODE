from django.utils import timezone
from celery import shared_task
from django.conf import settings
from apps.sale_rooms.models import MutualActionItem
# notifications.py
from django.core.mail import send_mail
from django.template.loader import render_to_string


@shared_task
def send_invite_email_task(subject, message, recipient_email):
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [recipient_email],
            fail_silently=False
        )
        return {"status": "success"}
    except Exception as e:
        return {"status": "failed", "error": str(e)}


def send_overdue_notification(task):
    # Determine assignee (guest or admin)
    assignee = task.guest_assignee or task.admin_assignee
    if not assignee or not hasattr(assignee, 'email'):
        return

    subject = f"Task Overdue: {task.task_detail}"
    context = {'task': task}
    message = render_to_string('emails/overdue_task.txt', context)
    html_message = render_to_string('emails/overdue_task.html', context)

    send_mail(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [assignee.email],
        html_message=html_message
    )


@shared_task(bind=True)
def check_and_send_overdue_notification(self, task_id):
    try:
        task = MutualActionItem.objects.get(id=task_id)

        if task.is_overdue and not task.is_notification_sent:
            send_overdue_notification(task)
            task.is_notification_sent = True
            task.last_overdue_notification_sent = timezone.now()
            task.save(update_fields=['is_notification_sent', 'last_overdue_notification_sent'])

    except MutualActionItem.DoesNotExist:
        pass
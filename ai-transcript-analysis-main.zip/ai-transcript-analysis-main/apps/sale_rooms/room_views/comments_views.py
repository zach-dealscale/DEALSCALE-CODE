# views.py
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from ..models import Comment, GuestUser
import json
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_protect
from apps.report_management.models import ReportDocument

@require_http_methods(["GET"])
def get_document_comments(request, document_id):
    """
    API endpoint to get all comments for a specific document
    """
    document = get_object_or_404(ReportDocument, id=document_id)
    
    # Get all parent comments (comments without a parent)
    parent_comments = Comment.objects.filter(document=document, parent=None)
    
    result = []
    for comment in parent_comments:
        comment_data = {
            'id': comment.id,
            'content': comment.content,
            'author_name': comment.author_name,
            'created_at': comment.created_at.isoformat(),
            'author_initial': comment.author_name[0] if comment.author_name else 'A',
            'author_color': get_author_color(comment.author_name),  # Helper function to generate consistent colors
            'replies': []
        }
        
        # Get all replies to this comment
        replies = Comment.objects.filter(parent=comment)
        for reply in replies:
            reply_data = {
                'id': reply.id,
                'content': reply.content,
                'author_name': reply.author_name,
                'created_at': reply.created_at.isoformat(),
                'author_initial': reply.author_name[0] if reply.author_name else 'A',
                'author_color': get_author_color(reply.author_name)
            }
            comment_data['replies'].append(reply_data)
            
        result.append(comment_data)
    
    return JsonResponse(result, safe=False)

@csrf_protect
@require_http_methods(["POST"])
def add_document_comment(request, document_id):
    """
    API endpoint to add a new comment to a document
    """
    document = get_object_or_404(ReportDocument, id=document_id)
    
    try:
        data = json.loads(request.body)
        content = data.get('content')
        
        if not content:
            return JsonResponse({'error': 'Comment content is required'}, status=400)
        
        # Determine the author (user or guest)
        if request.user.is_authenticated:
            comment = Comment.objects.create(
                document=document,
                content=content,
                created_by_user=request.user
            )
        else:
            # For guest users, you would need to identify them somehow
            # This is just a placeholder - you might use session data or other methods
            guest_user = GuestUser.objects.get(id=request.session.get('guest_user_id'))
            comment = Comment.objects.create(
                document=document,
                content=content,
                created_by_guest=guest_user
            )
        
        # Return the newly created comment
        return JsonResponse({
            'id': comment.id,
            'content': comment.content,
            'author_name': comment.author_name,
            'created_at': comment.created_at.isoformat(),
            'author_initial': comment.author_name[0] if comment.author_name else 'A',
            'author_color': get_author_color(comment.author_name),
            'replies': []
        })
        
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

@csrf_protect
@require_http_methods(["POST"])
def add_comment_reply(request, comment_id):
    """
    API endpoint to add a reply to an existing comment
    """
    parent_comment = get_object_or_404(Comment, id=comment_id)
    
    try:
        data = json.loads(request.body)
        content = data.get('content')
        
        if not content:
            return JsonResponse({'error': 'Reply content is required'}, status=400)
        
        # Determine the author (user or guest)
        if request.user.is_authenticated:
            reply = Comment.objects.create(
                document=parent_comment.document,
                parent=parent_comment,
                content=content,
                created_by_user=request.user
            )
        else:
            # For guest users, you would need to identify them somehow
            guest_user = GuestUser.objects.get(id=request.session.get('guest_user_id'))
            reply = Comment.objects.create(
                document=parent_comment.document,
                parent=parent_comment,
                content=content,
                created_by_guest=guest_user
            )
        
        # Return the newly created reply
        return JsonResponse({
            'id': reply.id,
            'content': reply.content,
            'author_name': reply.author_name,
            'created_at': reply.created_at.isoformat(),
            'author_initial': reply.author_name[0] if reply.author_name else 'A',
            'author_color': get_author_color(reply.author_name)
        })
        
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

def get_author_color(author_name):
    """
    Helper function to generate a consistent color based on the author's name
    """
    # List of background color classes
    colors = [
        'bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-pink-500',
        'bg-indigo-500', 'bg-red-500', 'bg-yellow-500', 'bg-teal-500'
    ]
    
    # Generate a simple hash from the name to pick a consistent color
    if not author_name:
        return colors[0]
    
    name_hash = sum(ord(char) for char in author_name)
    return colors[name_hash % len(colors)]
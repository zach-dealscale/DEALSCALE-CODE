import json
import subprocess
import tempfile
from django.utils.dateparse import parse_datetime

from apps.core.utils import GuestOrLoginRequiredMixin, ThumbnailService
from django.db.models import Q
from datetime import timedelta, date
from django.core.exceptions import ObjectDoesNotExist
import json
from apps.sale_rooms.models import MutualActionItem, SalesRoom
from rest_framework import status
import os
from pdf2image import convert_from_bytes
from PIL import Image
import io

from django.db.models import Prefetch
from django.utils.safestring import mark_safe
from django.core.files.storage import default_storage
from django.utils import timezone
from django.urls import reverse
from django.views.generic import TemplateView
from django.db.models import F, DurationField, ExpressionWrapper
from apps.ai_agents.apis.serializers import CommentSerializer
from apps.authentication.models import GuestUser, GuestUserSessionKey
from apps.report_management.forms import TranscriptForm, GuestAccessForm
from apps.report_management.models import Transcript, ReportTemplate, ReportFormation, ReportDocument, DocumentViewLog
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from apps.core.utils import merge_files, GuestOrLoginRequiredMixin

from django.shortcuts import render
from datetime import datetime, timedelta
from django.views import View
from django.http import HttpResponse, Http404, JsonResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from apps.sale_rooms.models import SalesRoomMedia, Comment, SalesRoom
from apps.sale_rooms.tasks import send_invite_email_task

from apps.report_management.helpers.report_choices import PlatformChoices

class GuestLoginView(View):
    """
    View for Guest User Login
    """
    template_name = 'sales_rooms_guest/access_room.html'
    form_class = GuestAccessForm


    def get(self, request, *args, **kwargs):

        form = self.form_class()

        context = {
            'form': form,
            'hide_nav': True
        }

        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email'].lower()
            sales_room_uuid = self.kwargs.get('uuid')
            sales_room = SalesRoom.objects.filter(uuid=sales_room_uuid).first()
            name = form.cleaned_data['name']
            guest_user, created = GuestUser.objects.get_or_create(email=email)
            guest_user.name = name
            guest_user.last_login = timezone.now()
            guest_user.sales_room = sales_room
            # Explicitly set company from sales_room for audit trail and company scoping
            if sales_room:
                guest_user.company = sales_room.company
            guest_user.visit_count+=1
            guest_user.save()

            guest_user = GuestUserSessionKey.objects.create(guest_user=guest_user)
            request.session['session_key'] = guest_user.session_key

            messages.success(request, f"Welcome {name}! You now have access to the Deal Room.")
            sales_room_id = self.kwargs.get('uuid')
            return redirect('guest_room_media', uuid=sales_room_id)


class GuestLogoutView(GuestOrLoginRequiredMixin, View):
    """
    View to handle guest user logout
    Clears guest session key and redirects to login page
    """

    def get(self, request, *args, **kwargs):
        if 'session_key' in request.session:
            del request.session['session_key']
            messages.success(request, "You've been logged out. See you again!")

        sales_room_id = self.kwargs.get('uuid')  # ensure uuid is in URLconf
        return redirect('guest_room_login', uuid=sales_room_id)

class GuestRoomView(GuestOrLoginRequiredMixin, View):
    """
    View for the guest room page
    """

    def get(self, request, uuid, *args, **kwargs):
        try:
            sales_room = SalesRoom.objects.get(uuid=uuid)
        except SalesRoom.DoesNotExist:
            return JsonResponse({'error': 'Deal Room not found'}, status=404)

        documents = ReportDocument.objects.filter(sales_room=sales_room)
        q_search = request.GET.get("q")
        if q_search:
            documents = documents.filter(title__icontains=q_search)

        reports_q = request.GET.get("report_id")
        if reports_q:
            documents = documents.filter(report__id=reports_q)

        reports = ReportFormation.objects.filter(transcript__client=sales_room.client)
        user_data = {
            "name": request.guest_user.name,
            "email": request.guest_user.email,
            "first_name": request.guest_user.name.split()[0]
        }
        context = {
            'documents': documents,
            'reports': reports,
            "sales_room_uuid": uuid,
            'user': mark_safe(json.dumps(user_data)),  # Ensure it's passed as safe JSON
        }

        return render(request, 'sales_rooms_guest/documents/document_list.html', context)



class GuestRoomMediaView(GuestOrLoginRequiredMixin, View):
    def get(self, request, uuid, *args, **kwargs):
        """
        Guest view for accessing Deal Room media + documents.
        Includes documents linked to both primary and additional transcripts.
        """
        sales_room = get_object_or_404(SalesRoom, uuid=uuid)

        # --- Fetch all media uploaded directly to the Deal Room ---
        media_files_queryset = (
            SalesRoomMedia.objects.filter(sales_room=sales_room)
            .exclude(file__isnull=True)
            .exclude(file="")
        )

        # --- Fetch all shareable report documents related to this client's transcripts ---
        documents_queryset = (
            ReportDocument.objects.filter(
                Q(report__transcript__client=sales_room.client)
                | Q(report__additional_transcripts__client=sales_room.client)
                |Q(client=sales_room.client),
                is_shareble=True,
            )
            .exclude(file__isnull=True)
            .exclude(file="")
            .distinct()
        )

        # --- Optional search ---
        search_q = request.GET.get("q") or request.GET.get("media_q")
        if search_q:
            media_files_queryset = media_files_queryset.filter(file__icontains=search_q)
            documents_queryset = documents_queryset.filter(file__icontains=search_q)

        # --- Combine media and document files into one list ---
        all_files = []

        # Process uploaded media files
        for file in media_files_queryset:
            file_ext = file.file.name.split(".")[-1].lower()
            thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
            all_files.append({
                "id": file.id,
                "name": os.path.basename(file.file.name),
                "file": file.file.url if file.file else None,
                "file_type": file_ext,
                "thumbnail_url": thumbnail_url,
                "uploaded_by_user": file.uploaded_by_user.get_full_name() if file.uploaded_by_user else None,
                "uploaded_by_user_profile_picture": (
                    file.uploaded_by_user.profile_picture.url
                    if file.uploaded_by_user and file.uploaded_by_user.profile_picture
                    else None
                ),
                "uploaded_by_guest": file.uploaded_by_guest.name if file.uploaded_by_guest else None,
                "uploaded_at": file.uploaded_at.strftime("%Y-%m-%d %H:%M:%S"),
            })

        # Process generated report documents
        for file in documents_queryset:
            file_ext = file.file.name.split(".")[-1].lower()
            thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
            all_files.append({
                "id": file.id,
                "name": file.title,
                "file": file.file.url if file.file else None,
                "file_type": file_ext,
                "thumbnail_url": thumbnail_url,
                "uploaded_at": file.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "uploaded_by_user": file.user.get_full_name() if file.user else None,
                "uploaded_by_user_profile_picture": (
                    file.user.profile_picture.url
                    if file.user and file.user.profile_picture
                    else None
                ),
                "uploaded_by_guest": None,
            })

        # --- Handle guest vs. authenticated user data ---
        if getattr(self.request, "guest_user", None):
            guest = self.request.guest_user
            user_data = {
                "name": guest.name,
                "email": guest.email,
                "first_name": guest.name.split()[0] if guest.name else "",
                "profile_picture": None,
                "is_authenticated": False,
                "is_guest": True,
            }
        else:
            user = self.request.user
            user_data = {
                "name": user.get_full_name() or user.username,
                "email": user.email,
                "first_name": user.first_name or user.last_name,
                "profile_picture": (
                    user.profile_picture.url
                    if hasattr(user, "profile_picture") and user.profile_picture
                    else None
                ),
                "is_authenticated": True,
                "is_guest": False,
            }

        # --- Context for template ---
        context = {
            "all_files": json.dumps(all_files),
            "sales_room_uuid": uuid,
            "sales_room": sales_room,
            "user": mark_safe(json.dumps(user_data)),
        }
        return render(request, "sales_rooms_guest/media/media_and_documents_new.html", context)

    # -------------------------------
    # 🔽 Utility Methods for Thumbnails
    # -------------------------------
    def generate_thumbnail(self, file_field, file_ext):
        thumb_name = f"thumbnails/{file_field.name}.thumb.jpg"
        if default_storage.exists(thumb_name):
            return default_storage.url(thumb_name)

        try:
            if file_ext in ["jpg", "jpeg", "png", "gif", "webp"]:
                return file_field.url

            elif file_ext == "pdf":
                with file_field.open("rb") as f:
                    pdf_data = f.read()
                images = convert_from_bytes(pdf_data, first_page=1, last_page=1)
                if images:
                    thumb_io = io.BytesIO()
                    images[0].save(thumb_io, format="JPEG", quality=85)
                    default_storage.save(thumb_name, thumb_io)
                    return default_storage.url(thumb_name)

            elif file_ext in ["docx", "xlsx", "pptx", "doc", "xls", "ppt"]:
                return self.generate_office_thumbnail_linux(file_field, file_ext, thumb_name)

        except Exception as e:
            print(f"Error generating thumbnail: {e}")

        return {
            "docx": "/static/images/doc-thumbnail.jpg",
            "xlsx": "/static/images/excel-thumbnail.jpg",
            "pptx": "/static/images/ppt-thumbnail.jpg",
            "pdf": "/static/images/pdf-thumbnail.jpg",
        }.get(file_ext, "/static/images/default-thumbnail.jpg")

    def generate_office_thumbnail_linux(self, file_field, file_ext, thumb_name):
        """Generate thumbnail for Office docs via LibreOffice -> PDF -> image"""
        try:
            with tempfile.NamedTemporaryFile(suffix=f".{file_ext}") as tmp:
                for chunk in file_field.chunks():
                    tmp.write(chunk)
                tmp.flush()

                with tempfile.TemporaryDirectory() as temp_dir:
                    subprocess.run(
                        [
                            "libreoffice", "--headless", "--convert-to", "pdf",
                            "--outdir", temp_dir, tmp.name
                        ],
                        check=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                    )

                    pdf_path = os.path.join(temp_dir, os.path.basename(tmp.name).replace(file_ext, "pdf"))

                    if os.path.exists(pdf_path):
                        with open(pdf_path, "rb") as pdf_file:
                            images = convert_from_bytes(pdf_file.read(), first_page=1, last_page=1)

                        if images:
                            thumb_io = io.BytesIO()
                            images[0].save(thumb_io, format="JPEG", quality=85)
                            default_storage.save(thumb_name, thumb_io)
                            return default_storage.url(thumb_name)

        except subprocess.CalledProcessError as e:
            print(f"LibreOffice conversion failed: {e.stderr.decode()}")
        except Exception as e:
            print(f"Error generating office thumbnail: {e}")

        return None


class DocumentDetailView(GuestOrLoginRequiredMixin, View):
    template_name = 'sales_rooms_guest/documents/document_detail.html'

    def get(self, request, *args, **kwargs):
        document = ReportDocument.objects.get(pk=kwargs['pk'])
        comments = Comment.objects.filter(document=document)
        user_data = {
            "name": request.guest_user.name,
            "email": request.guest_user.email,
            "first_name": request.guest_user.email
        }
        context_data = {
            'document': document,
            'comments': comments,
            'sales_room_uuid': document.sales_room.uuid,
            'user': mark_safe(json.dumps(user_data)),  # Ensure it's passed as safe JSON

        }
        return render(request, self.template_name, context_data)


class GuestRoomDashboard(GuestOrLoginRequiredMixin, TemplateView):
    template_name = "sales_rooms_guest/guest_room_dashboard.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        if getattr(self.request, "guest_user", None):
            # Guest user data
            name = self.request.guest_user.name
            email = self.request.guest_user.email
            first_name = name.split()[0] if name else ""
            profile_picture = None
            is_authenticated = False
        else:
            user = self.request.user
            name = user.get_full_name() or user.username
            email = user.email
            first_name = user.first_name or user.last_name
            profile_picture = user.profile_picture.url if hasattr(user,
                                                                  'profile_picture') and user.profile_picture else None
            is_authenticated = True

        user_data = {
            "name": name,
            "email": email,
            "first_name": first_name,
            "profile_picture": profile_picture,
            "is_authenticated": is_authenticated,
            "is_guest": hasattr(self.request, 'guest_user')
        }

        context["sales_room_uuid"] = self.kwargs.get("uuid")
        context["user"] = mark_safe(json.dumps(user_data))
        return context





class GuestRoomMediaUploadView(GuestOrLoginRequiredMixin, View):
    """
    View for uploading SalesRoomMedia files.
    """

    def post(self, request, *args, **kwargs):
        sales_room_uuid = kwargs.get("uuid")
        sales_room = get_object_or_404(SalesRoom, uuid=sales_room_uuid)
        document = ReportDocument.objects.filter(sales_room=sales_room).first()

        is_guest = hasattr(request, "guest_user") and request.guest_user
        uploaded_by_guest = None
        uploaded_by_user = None

        if is_guest:
            session_key = request.session.get("session_key")
            guest_session = get_object_or_404(GuestUserSessionKey, session_key=session_key)
            uploaded_by_guest = guest_session.guest_user
        else:
            uploaded_by_user = request.user

        files = request.FILES.getlist("files")
        created_media = []
        for file in files:
            # Ensure new uploads by guests have a unique document to avoid shared comments
            if uploaded_by_guest:
                backing_report = (
                    document.report if document and document.report else
                    ReportFormation.objects.filter(transcript__client=sales_room.client).first()
                )
                unique_doc = ReportDocument.objects.create(
                    report=backing_report,
                    title=getattr(file, 'name', 'Media Document'),
                    sales_room=sales_room,
                    is_shareble=False,
                    user=None,
                    company=sales_room.client.company if sales_room.client else None,
                    created_by=None,
                )
                media_document = unique_doc
            else:
                media_document = document

            media = SalesRoomMedia.objects.create(
                sales_room=sales_room,
                file=file,
                document=media_document,
                uploaded_by_guest=uploaded_by_guest,
                uploaded_by_user=uploaded_by_user,
                # Explicitly set company for audit trail
                company=sales_room.company if sales_room else None
            )
            created_media.append(media)

        # Notify all guests in this Deal Room only if a guest uploaded
        if uploaded_by_guest:
            guest_emails = list(GuestUser.objects.filter(sales_room=sales_room).exclude(email__isnull=True).exclude(email="").values_list("email", flat=True))
            if guest_emails:
                subject = f"New file(s) added in {sales_room.name}"
                message = f"Hello,\n\n{uploaded_by_guest.name or 'A guest'} uploaded {len(created_media)} file(s) in the Deal Room '{sales_room.name}'.\nVisit the room to view them.\n\nThanks."
                for email in guest_emails:
                    send_invite_email_task.delay(subject, message, email)

        messages.success(request, "Files uploaded successfully.")
        return JsonResponse({
            "success": True,
            "message": "Files uploaded successfully.",
            "redirect_url": f"{reverse('sales_room_detail', kwargs={'uuid': sales_room.uuid})}?tab=media",
            "tab": "media"
        })


class KanbanBoardViews(GuestOrLoginRequiredMixin, View):
    """
    View for Kanban Board with assignee functionality
    """
    def get(self, request, *args, **kwargs):
        sales_room = SalesRoom.objects.filter(uuid=self.kwargs.get("uuid")).first()
        if not sales_room:
            raise Http404("Deal Room not found")

        action_items = MutualActionItem.objects.filter(sales_room=sales_room).select_related(
            'created_by_user', 'created_by_guest', 'guest_assignee', 'admin_assignee'
        )

        action_items_list = []
        for action_item in action_items:
            item_data = {
                'id': action_item.id,
                'task_detail': action_item.task_detail,
                'due_date': action_item.due_date.strftime('%Y-%m-%d') if action_item.due_date else None,
                'status': action_item.status,
                'priority': action_item.priority,
                'created_at': action_item.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'created_by': action_item.created_by_user.get_full_name() if action_item.created_by_user else action_item.created_by_guest.name,
                'guest_assignee': action_item.guest_assignee.id if action_item.guest_assignee else None,
                'admin_assignee': action_item.admin_assignee.id if action_item.admin_assignee else None,
                'assignee_name': self.get_assignee_name(action_item)
            }
            action_items_list.append(item_data)

        is_guest = hasattr(self.request, "guest_user")
        user_data = self.get_user_data(is_guest, sales_room)

        context = {
            'action_items': action_items_list,
            'action_items_json': json.dumps(action_items_list),
            'sales_room_uuid': str(sales_room.uuid),
            'user_json': json.dumps(user_data),
            'user': json.dumps(user_data)
        }

        return render(request, 'sales_rooms_guest/kanban/mai_updated.html', context)

    def get_assignee_name(self, action_item):
        if action_item.guest_assignee:
            return action_item.guest_assignee.name
        if action_item.admin_assignee:
            return action_item.admin_assignee.get_full_name()
        return "Unassigned"

    def get_user_data(self, is_guest, sales_room):
        if is_guest:
            guest = self.request.guest_user
            return {
                "id": guest.id,
                "name": guest.name,
                "email": guest.email,
                "first_name": guest.name.split()[0] if guest.name else "",
                "is_guest": True,
                "available_admins": self.get_available_admins(sales_room),
                "available_guests": [],
            "profile_picture" : None,
            "is_authenticated" : False
            }
        else:
            user = self.request.user
            return {
                "id": user.id,
                "name": user.get_full_name() or user.username,
                "email": user.email,
                "first_name": user.first_name or user.last_name,
                "is_guest": False,
                "available_guests": self.get_available_guests(sales_room),
                "available_admins": [],
            "profile_picture" :user.profile_picture.url if hasattr(user,
                                                                  'profile_picture') and user.profile_picture else None,
            "is_authenticated" :True
            }

    def get_available_admins(self, sales_room):
        """Get all users who can be assigned tasks (room owner and collaborators)"""
        admins = []
        if sales_room.user:
            admins.append({
                'id': sales_room.user.id,
                'name': sales_room.user.get_full_name() or sales_room.user.username
            })
        if sales_room.client and sales_room.client.user:
            admins.append({
                'id': sales_room.client.user.id,
                'name': sales_room.client.user.get_full_name() or sales_room.client.user.username
            })
        return admins

    def get_available_guests(self, sales_room):
        """Get all guests who can be assigned tasks"""
        guests = GuestUser.objects.all()
        return [{
            'id': guest.id,
            'name': guest.name
        } for guest in guests]


class UpdateActionItemStatus(GuestOrLoginRequiredMixin, View):
    """
    View for Update the Task Status
    """
    def post(self, request, *args, **kwargs):
        item_id = request.POST.get('item_id')
        status = request.POST.get('status')
        try:
            item = MutualActionItem.objects.get(id=item_id)
            item.status = status
            item.save()
            return JsonResponse({
                'success': True,
                'message': f'Item {item_id} status updated to {status}'
            })
        except MutualActionItem.DoesNotExist:
            return JsonResponse({
                'error': False,
                'message': 'Task not found'
            }, status=404)


class UpdatedActionItemView(GuestOrLoginRequiredMixin, View):
    """
    View for updating action items with JSON data in request body
    """

    def post(self, request, *args, **kwargs):
        try:
            # Parse JSON data from request body
            data = json.loads(request.body)
            item_id = data.get('id')

            if not item_id:
                return JsonResponse({
                    'success': False,
                    'message': 'Item ID is required'
                }, status=400)

            item = MutualActionItem.objects.get(id=item_id)
            if request.user:
                if data.get("guest_assignee"):
                    data["guest_assignee"] = GuestUser.objects.filter(id=data["guest_assignee"]).first()
                fields_to_update = ['task_detail', 'status', 'priority', 'due_date', "guest_assignee"]
            else:
                fields_to_update = ['task_detail', 'status', 'priority', 'due_date']
            # Update fields if they exist in the request
            for field in fields_to_update:
                if field in data:
                    setattr(item, field, data[field])

            item.save()

            # Prepare response data
            response_data = {
                'success': True,
                'message': 'Task updated successfully',
                'item': {
                    'id': item.id,
                    'task_detail': item.task_detail,
                    'status': item.status,
                    'priority': item.priority,
                    'due_date': item.due_date,
                }
            }

            # If due_date is a date object, format it
            if hasattr(item.due_date, 'strftime'):
                response_data['item']['due_date'] = item.due_date.strftime('%Y-%m-%d')

            return JsonResponse(response_data)

        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'message': 'Invalid JSON data'
            }, status=400)

        except MutualActionItem.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Task not found'
            }, status=404)

        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error updating task: {str(e)}'
            }, status=400)

class CreateActionItemView(GuestOrLoginRequiredMixin, View):
    """
    API to create a new action item
    """

    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)

            task_detail = data.get('task_detail')
            due_date = data.get('due_date')
            priority = data.get('priority')
            status = data.get('status', 'todo')  # Default fallback

            if not all([task_detail, due_date, priority]):
                return JsonResponse({
                    'success': False,
                    'message': 'Missing required fields'
                }, status=400)

            sales_room = get_object_or_404(SalesRoom, uuid=self.kwargs.get("uuid"))

            action_item_kwargs = {
                "task_detail": task_detail,
                "due_date": due_date,
                "priority": priority,
                "status": status,
                "sales_room": sales_room,
                "created_at": timezone.now()
            }

            if getattr(request, "guest_user", None):
                action_item_kwargs["created_by_guest"] = request.guest_user
                action_item_kwargs["admin_assignee"] = sales_room.user
            else:
                guest_id = data.get('guest_assignee', '')
                action_item_kwargs["created_by_user"] = request.user
                action_item_kwargs["guest_assignee"] = GuestUser.objects.filter(id=guest_id).first()

            # Explicitly set company for audit trail
            action_item_kwargs["company"] = sales_room.company if sales_room else None
            MutualActionItem.objects.create(**action_item_kwargs)

            return JsonResponse({
                'success': True,
                'message': 'Task created successfully',
            })

        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'message': 'Invalid JSON data'
            }, status=400)

        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': str(e)
            }, status=500)

class GetFilteredItemsView(GuestOrLoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        try:
            search_query = request.GET.get('searchQuery', '')
            priority_filter = request.GET.get('priorityFilter', 'all')
            date_filter = request.GET.get('dateFilter', 'all')

            sales_room_uuid = self.kwargs.get("uuid")
            sales_room = SalesRoom.objects.filter(uuid=sales_room_uuid).first()
            if not sales_room:
                raise Http404("Deal Room not found")

            mutual_actions = MutualActionItem.objects.filter(
                sales_room=sales_room
            ).select_related(
                'created_by_user', 'created_by_guest', 'guest_assignee', 'admin_assignee'
            )

            if search_query:
                mutual_actions = mutual_actions.filter(
                    Q(task_detail__icontains=search_query)
                )

            if priority_filter != 'all':
                mutual_actions = mutual_actions.filter(priority=priority_filter)

            today = date.today()
            if date_filter == 'overdue':
                mutual_actions = mutual_actions.filter(due_date__lt=today)
            elif date_filter == 'today':
                mutual_actions = mutual_actions.filter(due_date=today)
            elif date_filter == 'week':
                week_from_now = today + timedelta(days=7)
                mutual_actions = mutual_actions.filter(
                    due_date__gte=today,
                    due_date__lte=week_from_now
                )

            serialized_data = []
            for item in mutual_actions:
                if item.guest_assignee:
                    assignee_name = item.guest_assignee.name
                elif item.admin_assignee:
                    assignee_name = item.admin_assignee.get_full_name()
                else:
                    assignee_name = "Unassigned"

                created_by = item.created_by_user.get_full_name() if item.created_by_user else (
                    item.created_by_guest.name if item.created_by_guest else "Unknown"
                )

                serialized_data.append({
                    'id': item.pk,
                    'task_detail': item.task_detail,
                    'due_date': item.due_date.strftime('%Y-%m-%d') if item.due_date else None,
                    'status': item.status,
                    'priority': item.priority,
                    'created_at': item.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    'created_by': created_by,
                    'guest_assignee': item.guest_assignee.id if item.guest_assignee else None,
                    'admin_assignee': item.admin_assignee.id if item.admin_assignee else None,
                    'assignee_name': assignee_name,
                })

            # 🔐 Determine current user context (guest or admin)
            if getattr(request, "guest_user", None):
                user = request.guest_user
                user_data = {
                    "id": user.id,
                    "name": user.name,
                    "email": user.email,
                    "first_name": user.name.split()[0] if user.name else "",
                    "is_guest": True,
                    "available_admins": self.get_available_admins(sales_room),
                    "available_guests": []
                }
            else:
                user = request.user
                user_data = {
                    "id": user.id,
                    "name": user.get_full_name() or user.username,
                    "email": user.email,
                    "first_name": user.first_name or user.last_name,
                    "is_guest": False,
                    "available_guests": self.get_available_guests(sales_room),
                    "available_admins": []
                }

            return JsonResponse({
                'items': serialized_data,
                'user': user_data
            })

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    def get_available_admins(self, sales_room):
        admins = []
        if sales_room.user:
            admins.append({
                'id': sales_room.user.id,
                'name': sales_room.user.get_full_name() or sales_room.user.username
            })
        if sales_room.client and sales_room.client.user:
            admins.append({
                'id': sales_room.client.user.id,
                'name': sales_room.client.user.get_full_name() or sales_room.client.user.username
            })
        return admins

    def get_available_guests(self, sales_room):
        guests = GuestUser.objects.all()
        return [{
            'id': guest.id,
            'name': guest.name
        } for guest in guests]


class AddCommentView(GuestOrLoginRequiredMixin, View):
    def post(self, request, document_id):
        try:
            document_id_int = int(document_id)
        except ValueError:
            return JsonResponse({'error': 'Invalid document_id format'}, status=status.HTTP_400_BAD_REQUEST)

        # Check for media or document
        sales_room_media = SalesRoomMedia.objects.filter(id=document_id_int).first()
        if sales_room_media:
            document = sales_room_media.document
            # Ensure each media has a unique backing ReportDocument for isolated comments
            if not document or (hasattr(document, 'media') and document.media.count() > 1):
                # Create a dedicated ReportDocument for this media
                document = ReportDocument.objects.create(
                    report=sales_room_media.document.report if (sales_room_media.document and sales_room_media.document.report) else ReportFormation.objects.filter(transcript__client=sales_room_media.sales_room.client).first(),
                    title=sales_room_media.file.name.split('/')[-1],
                    sales_room=sales_room_media.sales_room,
                    is_shareble=False,
                    user=None,
                    company=sales_room_media.sales_room.client.company if sales_room_media.sales_room.client else None,
                    created_by=None,
                )
                sales_room_media.document = document
                sales_room_media.save(update_fields=["document"])            
        else:
            try:
                document = ReportDocument.objects.get(id=document_id_int)
            except ObjectDoesNotExist:
                return JsonResponse({'error': 'No SalesRoomMedia or ReportDocument found with this id'}, status=status.HTTP_404_NOT_FOUND)

        # Parse JSON safely
        try:
            body = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON body'}, status=status.HTTP_400_BAD_REQUEST)

        content = body.get('content', '').strip()
        parent_id = body.get('parent_id')

        if not content:
            return JsonResponse({'error': 'Comment content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

        # Prepare comment creation
        comment_data = {
            'document': document,
            'content': content,
        }

        if request.user.is_authenticated:
            comment_data['created_by_user'] = request.user
        else:
            guest_user = getattr(request, 'guest_user', None)
            if not guest_user:
                return JsonResponse({'error': 'Guest user not found'}, status=status.HTTP_403_FORBIDDEN)
            comment_data['created_by_guest'] = guest_user

        # Explicitly set company for audit trail
        if document and document.company:
            comment_data['company'] = document.company

        try:
            # First create the comment without the parent
            comment = Comment.objects.create(**comment_data)

            # If it's a reply, set the parent
            if parent_id:
                try:
                    parent_comment = Comment.objects.get(pk=parent_id)
                    comment.parent = parent_comment
                    comment.save()
                except Comment.DoesNotExist:
                    return JsonResponse({'error': 'Parent comment not found'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return JsonResponse({'error': f"Error posting comment: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Notify all guests in this Deal Room only if a guest commented
        try:
            sales_room = document.sales_room or (sales_room_media.sales_room if 'sales_room_media' in locals() and sales_room_media else None)
            if sales_room and getattr(request, 'guest_user', None):
                guest_emails = list(GuestUser.objects.filter(sales_room=sales_room).exclude(email__isnull=True).exclude(email="").values_list("email", flat=True))
                if guest_emails:
                    subject = f"New comment in {sales_room.name}"
                    message = f"Hello,\n\n{request.guest_user.name or 'A guest'} commented on a file in the Deal Room '{sales_room.name}'.\n\nComment: {content}\n\nThanks."
                    for email in guest_emails:
                        send_invite_email_task.delay(subject, message, email)
        except Exception:
            pass

        # Return serialized response
        serializer = CommentSerializer(comment)
        return JsonResponse(serializer.data, safe=False, status=status.HTTP_201_CREATED)


class CommentsByMediaView(View):
    """
    View for Getting Comments by Media or ReportDocument ID
    """

    def get(self, request):
        media_id = request.GET.get('media_id')

        if not media_id:
            return JsonResponse({'error': 'media_id is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            media_id_int = int(media_id)
        except ValueError:
            return JsonResponse({'error': 'Invalid media_id format'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            media = SalesRoomMedia.objects.select_related('document').get(id=media_id_int)
            document = media.document
            if not document:
                return JsonResponse({'error': 'Document not found for given SalesRoomMedia'}, status=status.HTTP_404_NOT_FOUND)
        except ObjectDoesNotExist:
            try:
                document = ReportDocument.objects.get(id=media_id_int)
            except ObjectDoesNotExist:
                return JsonResponse({'error': 'No SalesRoomMedia or ReportDocument found with the given id'}, status=status.HTTP_404_NOT_FOUND)

        comments = Comment.objects.filter(document=document, parent__isnull=True).select_related(
            'created_by_user', 'created_by_guest'
        ).prefetch_related('replies')

        serializer = CommentSerializer(comments, many=True)

        return JsonResponse(serializer.data, safe=False, status=status.HTTP_200_OK)


def format_seconds_to_hhmmss(seconds):
    delta = timedelta(seconds=float(seconds))
    total_seconds = int(delta.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"


def parse_hhmmss_to_seconds(time_str):
    try:
        hours, minutes, seconds = map(int, time_str.split(":"))
        return hours * 3600 + minutes * 60 + seconds
    except Exception:
        return 0


class TrackDocumentView(GuestOrLoginRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            document_id = data.get("document_id")
            time_spent_seconds = float(data.get("time_spent", 0))

            document = ReportDocument.objects.get(id=document_id)
            guest_user = request.guest_user  # assumes middleware sets this

            # Convert seconds to HH:MM:SS string
            new_duration_str = format_seconds_to_hhmmss(time_spent_seconds)

            view_log, created = DocumentViewLog.objects.get_or_create(
                document=document,
                guest_user=guest_user,
                defaults={
                    "views": 1,
                    "time_spent": new_duration_str
                }
            )

            if not created:
                # Parse existing duration string to seconds
                existing_seconds = parse_hhmmss_to_seconds(view_log.time_spent or "00:00:00")
                total_seconds = existing_seconds + time_spent_seconds
                view_log.time_spent = format_seconds_to_hhmmss(total_seconds)
                view_log.views += 1
                view_log.save()

            return JsonResponse({"status": "success"})

        except ReportDocument.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Document not found"}, status=404)

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)


class GuestRoomDeleteFileView(GuestOrLoginRequiredMixin, View):
    """
    View for deleting a file from a Deal Room.
    - Normal users can delete any file.
    - Guest users can delete only their own SalesRoomMedia files (not ReportDocuments).
    """
    def post(self, request, *args, **kwargs):
        try:
            sales_room = get_object_or_404(SalesRoom, uuid=kwargs.get("uuid"))
            is_guest = hasattr(request, "guest_user") and request.guest_user is not None
            guest_user = getattr(request, "guest_user", None)

            # Parse request payload
            data = json.loads(request.body or "{}")
            document_id = data.get("document_id") or data.get("media_id")
            if not document_id:
                return JsonResponse({"success": False, "message": "document_id is required"}, status=400)

            # --- Case 1: Normal user (can delete everything) ---
            if not is_guest:
                # Try deleting from ReportDocument first
                document = ReportDocument.objects.filter(id=document_id).first()
                if document:
                    file_path = document.file.path if hasattr(document.file, "path") else None
                    document.delete()
                    if file_path and default_storage.exists(file_path):
                        default_storage.delete(file_path)
                    return JsonResponse({"success": True, "message": "Document deleted."})

                # Then try SalesRoomMedia
                media = SalesRoomMedia.objects.filter(id=document_id, sales_room=sales_room).first()
                if media:
                    file_path = media.file.path if hasattr(media.file, "path") else None
                    media.delete()
                    if file_path and default_storage.exists(file_path):
                        default_storage.delete(file_path)
                    return JsonResponse({"success": True, "message": "Media file deleted."})

                return JsonResponse({"success": False, "message": "File not found."}, status=404)

            # --- Case 2: Guest user (restricted deletion) ---
            # Guests cannot delete ReportDocuments
            if ReportDocument.objects.filter(id=document_id).exists():
                return JsonResponse({
                    "success": False,
                    "message": "Guests cannot delete report documents."
                }, status=403)

            # Allow guest to delete only their own SalesRoomMedia
            media = SalesRoomMedia.objects.filter(id=document_id, sales_room=sales_room).first()
            if not media:
                return JsonResponse({"success": False, "message": "Media not found."}, status=404)

            # Only allow if media belongs to this guest
            if getattr(media, "uploaded_by_guest_id", None) != guest_user.id:
                return JsonResponse({
                    "success": False,
                    "message": "Guests can only delete their own uploaded media."
                }, status=403)

            file_path = media.file.path if hasattr(media.file, "path") else None
            media.delete()
            if file_path and default_storage.exists(file_path):
                default_storage.delete(file_path)

            return JsonResponse({"success": True, "message": "Media file deleted."})

        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)}, status=500)



import json
import os
from apps.sale_rooms.tasks import send_invite_email_task
from django.db.models import Sum, Count, Q
from django.db.models.functions import TruncDate
from django.conf import settings
from django.shortcuts import redirect, get_object_or_404, render
from django.urls.base import reverse_lazy
from django.utils.decorators import method_decorator
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.core.exceptions import ObjectDoesNotExist
import json
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import View
from django.views.generic.edit import DeleteView, UpdateView, CreateView, FormView
from django.http import HttpResponse, Http404, HttpResponseNotAllowed
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.utils.timezone import now

from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
from django.http import JsonResponse
import logging
from django.contrib import messages

from apps.ai_agents.apis.serializers import CommentSerializer
from apps.authentication.models import Client, GuestUserSessionKey, GuestUser
from apps.core.utils import ThumbnailService
from apps.core.mixins import RoleBasedClientAccessMixin
from apps.sale_rooms.forms import SalesRoomForm, SalesRoomUpdateForm
from apps.sale_rooms.models import SalesRoom, SalesRoomMedia, Comment, MutualActionItem

logger = logging.getLogger(__name__)
from apps.report_management.models import ReportDocument, DocumentViewLog
from django.db.models import Count, Max
from django.db.models import Count
from django.db.models import Sum, F, ExpressionWrapper, DurationField
from django.views.generic import TemplateView
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
import random
from collections import Counter


class SalesRoomListView(LoginRequiredMixin, RoleBasedClientAccessMixin, TemplateView):
    template_name = "sales_rooms/sales_room_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        # Use role-based access control to filter rooms based on accessible clients
        accessible_clients = self.get_accessible_clients(user)
        rooms = SalesRoom.objects.filter(client__in=accessible_clients)

        # rooms = rooms.filter(
        #     sales_room_reports__in=ReportDocument.objects.filter(
        #         Q(file__isnull=False, file__gt="") | Q(content__isnull=False, content__gt="")
        #     )
        # ).distinct()

        search_q = self.request.GET.get("q")
        if search_q:
            rooms = rooms.filter(name__icontains=search_q)

        rooms = rooms.annotate(
            documents_count=Count(
                'sales_room_reports',
                filter=Q(
                    sales_room_reports__file__isnull=False, sales_room_reports__file__gt=""
                ) | Q(
                    sales_room_reports__content__isnull=False, sales_room_reports__content__gt=""
                ),
                distinct=True
            ),
            media_count=Count('media', distinct=True),
            action_items_count=Count('action_items', distinct=True),
            last_updated=Max('media__uploaded_at')
        )

        room_data = []
        for room in rooms:
            room_data.append({
                "id": room.id,
                "client_name": room.client.name if room.client else "No Client",
                "client_logo": room.client.company_logo.url if room.client and room.client.company_logo else None,
                "client_id": room.client.id if room.client else None,
                "room_name": room.name,
                "uuid": str(room.uuid),
                "documents_count": room.documents_count,
                "media_count": room.media_count,
                "action_items_count": room.action_items_count,
                "last_updated": room.last_updated.strftime("%Y-%m-%d") if room.last_updated else "Never",
            })

        context["rooms"] = room_data
        return context



class SalesRoomDetailView(LoginRequiredMixin, RoleBasedClientAccessMixin, View):
    template_name = 'sales_rooms/sales_room_detail.html'

    def get(self, request, uuid):
        try:
            sales_room = self.get_sales_room(uuid)
            # cache for helper methods that reference self.sales_room
            self.sales_room = sales_room
            visitor_data = self.get_visitor_data(sales_room)
            documents = self.get_documents(request, sales_room)
            media_files = self.get_media_files(request, sales_room)
            visitors = self.get_visitors(sales_room)
            recent_activities = self.get_recent_activities(documents, media_files, visitors)
            engagement_stats = self.get_engagement_stats(documents)
            doc_type_counts = self.get_doc_type_counts(documents)
            share_settings = self.get_share_settings(uuid)
            sales_room_data = self.get_sales_room_data(sales_room, engagement_stats, recent_activities)
            action_items = self.get_mutual_action_items(sales_room)
            all_files = []
            media_files_queryset = SalesRoomMedia.objects.filter(sales_room=sales_room).exclude(
                file__isnull=True).exclude(
                file='')
            documents_queryset = ReportDocument.objects.filter(
                Q(report__transcript__client=sales_room.client) |
                Q(client=sales_room.client),
                is_shareble=True
            ).exclude(file__isnull=True).exclude(file='')
            for file in media_files_queryset:
                file_ext = file.file.name.split('.')[-1].lower()
                thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
                all_files.append({
                    'id': file.id,
                    'name': os.path.basename(file.file.name),
                    'file': file.file.url if file.file else None,
                    'file_type': file_ext,
                    'thumbnail_url': thumbnail_url,
                    'uploaded_by_user': file.uploaded_by_user.get_full_name() if file.uploaded_by_user else None,
                    'uploaded_by_user_profile_picture': file.uploaded_by_user.profile_picture.url if file.uploaded_by_user and file.uploaded_by_user.profile_picture else None,
                    'uploaded_by_guest': file.uploaded_by_guest.name if file.uploaded_by_guest else None,
                    'uploaded_at': file.uploaded_at.strftime("%Y-%m-%d %H:%M:%S"),
                })

            for file in documents_queryset:
                file_ext = file.file.name.split('.')[-1].lower()
                thumbnail_url = ThumbnailService.generate_thumbnail(file.file, file_ext)
                all_files.append({
                    'id': file.id,
                    'name': file.title,
                    'file': file.file.url if file.file else None,
                    'file_type': file_ext,
                    'thumbnail_url': thumbnail_url,
                    'uploaded_at': file.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                    'uploaded_by_user': file.user.get_full_name(),
                    'uploaded_by_user_profile_picture': file.user.profile_picture.url if file.user and file.user.profile_picture else None,
                    'uploaded_by_guest': None
                })
            print(json.dumps(action_items))
            print(action_items)

            context = {
                'sales_room': sales_room_data,
                'sales_room_uuid': sales_room.uuid,
                'engagement_stats': engagement_stats,
                'visitor_data': visitor_data,
                'documents': documents,
                'visitors': visitors,
                'media_files': media_files,
                'recent_activities': recent_activities,
                'doc_type_counts': doc_type_counts,
                'share_settings': share_settings,
                'action_items_json': json.dumps(action_items),
                'action_items': action_items,
                'user_json': json.dumps({
                    'is_guest': False,
                    'available_guests': [{
                        'id': guest.id,
                        'name': guest.name
                    } for guest in sales_room.visitors.all()],
                    'available_admins': [],
                }),
                'all_files': json.dumps(all_files),
            }

            return render(request, self.template_name, context)

        except Exception as e:
            logger.critical(f"Unexpected error in SalesRoomDetailView: {str(e)}", exc_info=True)
            # return render(request, 'error.html', {'error': "An unexpected error occurred"}, status=500)
            return render(request, self.template_name)

    def get_sales_room(self, uuid):
        try:
            sales_room = SalesRoom.objects.select_related('client').get(uuid=uuid)

            # Verify user has access to this room's client (via role-based mixin)
            accessible_clients = self.get_accessible_clients(self.request.user)
            if not accessible_clients.filter(pk=sales_room.client_id).exists():
                messages.error(self.request, "You don't have access to this Deal Room.")
                raise Http404("Deal Room not found or access denied.")

            return sales_room
        except SalesRoom.DoesNotExist:
            raise Http404("Deal Room not found")
        except Exception as e:
            logger.error(f"Error fetching Deal Room {uuid}: {str(e)}")
            raise

    def get_visitor_data(self, sales_room):
        try:
            # Get last 30 days of visitor data
            end_date = timezone.now()
            start_date = end_date - timedelta(days=30)

            # Get daily visitor counts
            visitors = (
                GuestUser.objects.filter(
                    sales_room=sales_room,
                    last_login__range=(start_date, end_date)
                )
                .annotate(date=TruncDate('last_login'))
                .values('date')
                .annotate(count=Count('id'))
                .order_by('date')
            )

            # Create a complete date range with counts
            date_counts = {v['date'].strftime('%Y-%m-%d'): v['count'] for v in visitors}

            dates = []
            views = []

            current_date = start_date
            while current_date <= end_date:
                date_str = current_date.strftime('%Y-%m-%d')
                dates.append(date_str)
                views.append(date_counts.get(date_str, 0))
                current_date += timedelta(days=1)

            return {
                'dates': dates,
                'views': views,
                'time_spent': [0] * len(dates)  # You might need to track this separately
            }
        except Exception as e:
            logger.warning(f"Error generating visitor data: {str(e)}")
            return {'dates': [], 'views': [], 'time_spent': []}

    def get_documents(self, request, sales_room):
        documents = []
        try:
            query = request.GET.get('document_q', '')
            docs = ReportDocument.objects.filter(
                sales_room=sales_room
            ).filter(
                Q(file__isnull=False, file__gt="") | Q(content__isnull=False, content__gt="")
            ).select_related(
                'report__template', 'report__transcript', 'client'
            ).order_by('-created_at')
            if query:
                docs = docs.filter(title__icontains=query)
            logs = DocumentViewLog.objects.filter(document__in=docs).values('document_id').annotate(
                total_views=Sum('views'),
            )
            logs_map = {log['document_id']: log for log in logs}
            for i, doc in enumerate(docs):
                try:
                    log_data = logs_map.get(doc.id, {})
                    view_count = log_data.get('total_views', 0)
                    last_viewed = log_data.get('last_viewed')
                    documents.append({
                        'id': doc.id,
                        'title': doc.title,
                        'created_at': doc.created_at,
                        'views': view_count,
                        'file_type': getattr(getattr(doc.report, 'template', None), 'title', 'Unknown'),
                        'last_viewed': last_viewed,
                        'status': 'viewed' if view_count else 'unread',
                        'uploaded_by': getattr(sales_room.client, 'name', 'Unknown'),
                        'is_shareble': doc.is_shareble
                    })
                except Exception as e:
                    logger.warning(f"Error processing document {doc.id}: {str(e)}")
        except Exception as e:
            logger.error(f"Error fetching documents: {str(e)}")
        return documents

    def get_media_files(self, request, sales_room):
        media_files = []
        try:
            query = request.GET.get('media_q', '')
            files = SalesRoomMedia.objects.filter(sales_room=sales_room).select_related('uploaded_by_user', 'uploaded_by_guest').order_by('-uploaded_at')
            if query:
                files = files.filter(file__icontains=query)

            for media in files:
                try:
                    uploader = media.uploaded_by_user or media.uploaded_by_guest
                    name = self.get_uploader_name(uploader)
                    email = getattr(uploader, "email", None)
                    file_name = getattr(media.file, 'name', 'Unknown')
                    profile_picture = getattr(uploader, "profile_picture", None)
                    file_size = f"{media.file.size / (1024 * 1024):.1f} MB" if media.file.size else "0 MB"
                    file_ext = file_name.split('.')[-1].lower() if '.' in file_name else 'file'
                    thumbnail_url = ThumbnailService.generate_thumbnail(media.file, file_ext)
                    media_files.append({
                        'id': media.id,
                        'name': file_name,
                        'file_type': file_name.split('.')[-1] if '.' in file_name else 'file',
                        'size': file_size,
                        'thumbnail_url':thumbnail_url,
                        'uploaded_at': media.uploaded_at,
                        'uploaded_by': {'id': getattr(uploader, 'id', None), 'name': name, 'email': email, "profile_picture": profile_picture}
                    })
                except Exception as e:
                    logger.warning(f"Error processing media file {media.id}: {str(e)}")
        except Exception as e:
            logger.error(f"Error fetching media files: {str(e)}")
        return media_files

    def get_uploader_name(self, uploader):
        if not uploader:
            return "Unknown"
        if hasattr(uploader, "get_full_name"):
            return uploader.get_full_name() or "Unknown"
        if hasattr(uploader, "name"):
            return uploader.name or "Unknown"
        return getattr(uploader, "email", "Unknown").split("@")[0]

    def get_visitors(self, sales_room):
        try:
            guest_users = sales_room.visitors.all().order_by('-last_login')
            visitors = []

            for guest in guest_users:
                # Fetch related document view logs
                logs = DocumentViewLog.objects.filter(
                    guest_user=guest,
                    document__sales_room=sales_room  # assuming ReportDocument has FK to SalesRoom
                )

                # Aggregate total views and total time
                total_views = logs.aggregate(total=Sum('views'))['total'] or 0

                def parse_time(t):
                    try:
                        if 'h' in t or 'm' in t:
                            hours = 0
                            minutes = 0
                            if 'h' in t:
                                parts = t.split('h')
                                hours = int(parts[0].strip())
                                t = parts[1] if len(parts) > 1 else ""
                            if 'm' in t:
                                minutes = int(t.strip().replace('m', ''))
                            return timedelta(hours=hours, minutes=minutes)
                        return timedelta()
                    except:
                        return timedelta()

                total_time = timedelta()
                for log in logs:
                    if log.time_spent:
                        total_time += parse_time(log.time_spent)

                total_minutes = int(total_time.total_seconds() // 60)
                formatted_time = f"{total_minutes // 60}h {total_minutes % 60}m" if total_minutes else "0m"

                visitors.append({
                    "id": guest.id,
                    "name": guest.name or "Anonymous",
                    "email": guest.email,
                    "last_visits": guest.last_login.strftime("%Y-%m-%d %H:%M") if guest.last_login else "Never",
                    "total_visits": total_views,
                    "time_spent": formatted_time,
                })

            return visitors
        except Exception as e:
            print("Error fetching visitors:", str(e))
            return []

    def get_recent_activities(self, documents, media_files, visitors):
        try:
            activities = []
            recent_uploads = SalesRoomMedia.objects.filter(
                sales_room=self.sales_room
            ).select_related('uploaded_by_user', 'uploaded_by_guest').order_by('-uploaded_at')[:5]

            for upload in recent_uploads:
                uploader = upload.uploaded_by_user or upload.uploaded_by_guest
                activities.append({
                    'type': 'upload',
                    'user': {
                        'id': uploader.id,
                        'name': self.get_uploader_name(uploader),
                        'email': getattr(uploader, 'email', None)
                    },
                    'item': os.path.basename(upload.file.name),
                    'timestamp': upload.uploaded_at
                })

            return activities[:5]  # Return only the 5 most recent
        except Exception as e:
            logger.error(f"Error generating activities: {str(e)}")
            return []

    def get_mutual_action_items(self, sales_room):
        """Fetch mutual action items for the Deal Room"""
        try:
            items = MutualActionItem.objects.filter(sales_room=sales_room).select_related(
                'created_by_user',
                'created_by_guest',
                'guest_assignee',
                'admin_assignee'
            ).order_by('-created_at')

            action_items = []
            for item in items:
                assignee = None
                assignee_name = None

                if item.guest_assignee:
                    assignee = 'guest_' + str(item.guest_assignee.id)
                    assignee_name = item.guest_assignee.name
                elif item.admin_assignee:
                    assignee = 'admin_' + str(item.admin_assignee.id)
                    assignee_name = item.admin_assignee.get_full_name()

                action_items.append({
                    'id': item.id,
                    'description': item.task_detail,
                    'due_date': item.due_date.isoformat() if item.due_date else None,
                    'status': item.status,
                    'priority': item.priority,
                    'created_at': item.created_at.isoformat(),
                    'guest_assignee': item.guest_assignee.id if item.guest_assignee else None,
                    'assignee_name': assignee_name,
                    'assignee_type': 'guest' if item.guest_assignee else 'admin' if item.admin_assignee else None,
                })

            return action_items
        except Exception as e:
            logger.error(f"Error fetching mutual action items: {str(e)}")
            return []

    def get_engagement_stats(self, documents):
        try:
            document_ids = [d['id'] for d in documents]
            now = timezone.now()

            # Date ranges
            start_current_month = now.replace(day=1)
            start_last_month = (start_current_month - timedelta(days=1)).replace(day=1)
            end_last_month = start_current_month - timedelta(seconds=1)

            # Current month logs
            current_logs = DocumentViewLog.objects.filter(
                document_id__in=document_ids,
                last_viewed__gte=start_current_month
            )

            # Last month logs
            last_month_logs = DocumentViewLog.objects.filter(
                document_id__in=document_ids,
                last_viewed__range=(start_last_month, end_last_month)
            )

            def parse_hhmmss(duration_str):
                try:
                    if not duration_str:
                        return 0
                    parts = str(duration_str).split(":")
                    parts = [int(p) for p in parts]
                    if len(parts) == 3:
                        hours, minutes, seconds = parts
                    elif len(parts) == 2:
                        hours = 0
                        minutes, seconds = parts
                    elif len(parts) == 1:
                        hours, minutes, seconds = 0, 0, parts[0]
                    else:
                        return 0
                    return hours * 3600 + minutes * 60 + seconds
                except Exception:
                    return 0

            def get_stats(logs):
                total_views = logs.aggregate(total=Sum('views'))['total'] or 0
                # aggregate time_spent strings in Python as seconds
                time_seconds = 0
                for entry in logs.values_list('time_spent', flat=True):
                    time_seconds += parse_hhmmss(entry)
                documents_viewed = logs.values("document_id").distinct().count()
                unique_visitors = logs.values("guest_user_id").distinct().count()
                return total_views, time_seconds, documents_viewed, unique_visitors

            current_views, current_time, current_docs, current_visitors = get_stats(current_logs)
            last_views, last_time, last_docs, last_visitors = get_stats(last_month_logs)

            # Percent change logic
            def percent_change(current, previous):
                if previous == 0:
                    return 100 if current > 0 else 0
                return round(((current - previous) / previous) * 100)

            views_pct = percent_change(current_views, last_views)
            docs_pct = percent_change(current_docs, last_docs)
            visitors_pct = percent_change(current_visitors, last_visitors)

            avg_time = current_time // current_views if current_views else 0

            return {
                "total_views": current_views,
                "avg_time": avg_time,
                "documents_viewed": current_docs,
                "unique_visitors": current_visitors,
                "views_percentage": views_pct,
                "documents_percentage": docs_pct,
                "visitors_percentage": visitors_pct,
                "total_time_spent": current_time,
            }

        except Exception as e:
            logger.error(f"[EngagementStatsError] SalesRoom {self.id}: {str(e)}", exc_info=True)
            return {
                "error": "Failed to calculate engagement statistics",
                "details": str(e)
            }

    def get_doc_type_counts(self, documents):
        try:
            doc_types = [doc.get('file_type', 'Unknown') for doc in documents]
            return dict(Counter(doc_types))
        except Exception as e:
            logger.error(f"Error counting document types: {str(e)}")
            return {}

    def get_share_settings(self, uuid):
        try:
            return {
                'share_link': f"{settings.BASE_URL}/share/{uuid}",
                'allow_downloads': True,
                'allow_comments': True,
                'require_email': True,
                'password_protected': False,
                'expiry_date': timezone.now() + timedelta(days=30),
            }
        except Exception as e:
            logger.error(f"Error generating share settings: {str(e)}")
            return {}

    def get_sales_room_data(self, sales_room, engagement_stats, recent_activities):
        try:
            client_contacts = getattr(sales_room.client, 'client_contacts', None)
            last_contact = client_contacts.last() if client_contacts else None
            return {
                'id': sales_room.id,
                'uuid': sales_room.uuid,
                'name': sales_room.name,
                'created_at': sales_room.created_at,
                'client': {
                    'id': sales_room.client.id,
                    'name': sales_room.client.name,
                    'website': sales_room.client.website,
                    'company_logo': sales_room.client.company_logo.url if sales_room.client.company_logo else None,
                    'notes': last_contact.notes if last_contact else ''
                },
                'last_activity': recent_activities[0]['timestamp'] if recent_activities else None,
                'total_views': engagement_stats.get('total_views', 0),
                'unique_visitors': engagement_stats.get('unique_visitors', 0)
            }
        except Exception as e:
            logger.error(f"Error preparing Deal Room data: {str(e)}")
            return {}


class SalesRoomDownloadPDFView(LoginRequiredMixin, View):
    """
    View for downloading Deal Room data as a PDF report.
    """
    def get(self, request, uuid):
        try:
            sales_room = SalesRoom.objects.select_related('client').get(uuid=uuid)

            mock_dates = [(timezone.now() - timedelta(days=x)).strftime('%Y-%m-%d') for x in range(30, 0, -1)]
            visitor_data = {
                'dates': mock_dates,
                'views': [random.randint(0, 5) for _ in range(30)],
                'time_spent': [random.randint(0, 120) for _ in range(30)],
            }

            document_search_q = request.GET.get('document_q')
            documents_qs = ReportDocument.objects.filter(sales_room=sales_room).select_related(
                'report__template', 'report__transcript'
            ).order_by('-created_at')
            if document_search_q:
                documents_qs = documents_qs.filter(title__icontains=document_search_q)

            documents = []
            for i, doc in enumerate(documents_qs):
                view_count = random.randint(0, 10) if i < 3 else 0  # First 3 docs get views
                last_viewed = timezone.now() - timedelta(days=random.randint(1, 10)) if view_count > 0 else None
                documents.append({
                    'id': doc.id,
                    'title': doc.title,
                    'created_at': doc.created_at,
                    'views': view_count,
                    'file_type': doc.file,
                    'last_viewed': last_viewed,
                    'status': 'viewed' if view_count > 0 else 'unread',
                    'uploaded_by': 'John Smith'  # Default value
                })

            media_q = request.GET.get('media_q')
            media_files_qs = SalesRoomMedia.objects.filter(sales_room=sales_room).select_related(
                'uploaded_by_user', 'uploaded_by_guest'
            ).order_by('-uploaded_at')
            if media_q:
                media_files_qs = media_files_qs.filter(file__icontains=media_q)

            media_files = []
            for media in media_files_qs:
                uploader = media.uploaded_by_user or media.uploaded_by_guest
                media_files.append({
                    'id': media.id,
                    'name': media.file.name,
                    'file_type': media.file.name.split('.')[-1],
                    'size': f"{media.file.size / (1024 * 1024):.1f} MB",  # Convert to MB
                    'uploaded_at': media.uploaded_at,
                    'uploaded_by': {
                        'id': uploader.id if uploader else None,
                        'name': uploader.name if uploader else 'Unknown',
                        'email': uploader.email if uploader else None
                    },
                })

            visitor_names = ['Sarah Johnson', 'Michael Chen', 'Emily Rodriguez', 'David Thompson']
            visitor_emails = ['sarah.johnson@acmecorp.com', 'michael.chen@acmecorp.com', 'emily.rodriguez@acmecorp.com', 'david.thompson@acmecorp.com']

            visitors = []
            for i in range(4):
                visit_count = random.randint(1, 8)
                visitors.append({
                    'id': i + 1,
                    'name': visitor_names[i],
                    'email': visitor_emails[i],
                    'last_visit': timezone.now() - timedelta(days=random.randint(1, 5)),
                    'total_visits': visit_count,
                    'time_spent': f"{random.randint(1, 2)}h {random.randint(0, 59)}m"
                })

            engagement_stats = {
                'total_views': sum(visitor_data['views']),
                'avg_time': sum(visitor_data['time_spent']) // len(visitor_data['time_spent']) if visitor_data['time_spent'] else 0,
                'most_active_day': mock_dates[visitor_data['views'].index(max(visitor_data['views']))],
                'most_viewed_document': documents[0]['title'] if documents else None,
                'documents_viewed': len([d for d in documents if d['views'] > 0]),
                'unique_visitors': len(visitors),
            }

            sales_room_data = {
                'id': sales_room.id,
                'uuid': sales_room.uuid,
                'name': sales_room.name,
                'created_at': sales_room.created_at,
                'client': {
                    'id': sales_room.client.id,
                    'name': sales_room.client.name,
                    'website': sales_room.client.website,
                    'company_logo': sales_room.client.company_logo.url if sales_room.client.company_logo else None
                },
            }

            context = {
                'sales_room': sales_room_data,
                'engagement_stats': engagement_stats,
                'visitor_data': visitor_data,
                'documents': documents,
                'visitors': visitors,
                'media_files': media_files,
            }

            html = render_to_string("sales_rooms/sales_room_pdf_template.html", context)

            response = HttpResponse(content_type="application/pdf")
            response["Content-Disposition"] = f"attachment; filename=sales_room_{uuid}_report.pdf"

            pisa_status = pisa.CreatePDF(html, dest=response)

            if pisa_status.err:
                return HttpResponse("Error generating PDF", status=500)

            return response

        except SalesRoom.DoesNotExist:
            raise Http404("Deal Room not found")

class SalesRoomCreateView(LoginRequiredMixin, RoleBasedClientAccessMixin, FormView):
    template_name = "sales_rooms/create_sales_room.html"
    form_class = SalesRoomForm
    success_url = reverse_lazy("sales_room_list"    )

    def get_clients_data(self):
        """Get only clients accessible to the user based on role-based access control."""
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)
        return [
            {
                'id': client.id,
                'name': client.name,
                'logo': client.company_logo.url if client.company_logo else None,
                'website': client.website,
            }
            for client in accessible_clients
        ]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['clients'] = json.dumps(self.get_clients_data())
        return context

    def form_valid(self, form):
        sales_room = form.save(commit=False)
        sales_room.user = self.request.user
        # Explicitly set company and created_by for audit trail and company scoping
        sales_room.company = self.request.user.company
        sales_room.created_by = self.request.user
        sales_room.save()
        messages.success(self.request, 'Deal Room created successfully.')
        return redirect('sales_room_detail', uuid=sales_room.uuid)

    def form_invalid(self, form):
        if 'client' in form.errors and any("already exists" in error for error in form.errors['client']):
            client_id = self.request.POST.get('client')
            try:
                client = Client.objects.get(id=client_id, user=self.request.user)
                existing_room = SalesRoom.objects.filter(client=client, user=self.request.user).first()
                if existing_room:
                    messages.warning(
                        self.request,
                        f"A Deal Room for '{client.name}' already exists. Redirecting you there."
                    )
                    return redirect('sales_room_detail', uuid=existing_room.uuid)
            except Client.DoesNotExist:
                pass

        messages.error(self.request, "Form submission failed. Please correct the errors below.")
        return super().form_invalid(form)


class SalesRoomEditView(LoginRequiredMixin, View):
    template_name = 'sales_rooms/sales_room_edit.html'
    form_class = SalesRoomUpdateForm

    def get(self, request, uuid):
        sales_room = get_object_or_404(SalesRoom, uuid=uuid)
        clients = Client.objects.all()

        clients_data = [
            {
                'id': client.id,
                'name': client.name,
                'logo': client.company_logo.url if client.company_logo else None,
                'website': client.website
            }
            for client in clients
        ]

        form = self.form_class(instance=sales_room)
        return render(request, self.template_name, {
            'form': form,
            'clients': json.dumps(clients_data)
        })

    def post(self, request, uuid):
        sales_room = get_object_or_404(SalesRoom, uuid=uuid)
        form = self.form_class(request.POST, instance=sales_room)

        if form.is_valid():
            form.save()
            messages.success(request, 'Deal Room updated successfully!')
            return redirect('sales_room_detail', uuid=sales_room.uuid)

        messages.error(request, form.errors)
        clients = Client.objects.all()
        clients_data = [
            {
                'id': client.id,
                'name': client.name,
                'logo': client.company_logo.url if client.company_logo else None,
                'website': client.website
            }
            for client in clients
        ]
        return render(request, self.template_name, {
            'form': form,
            'clients': json.dumps(clients_data)
        })



class SalesRoomDeleteView(LoginRequiredMixin, DeleteView):
    """
    Delete a Deal Room with a get request.
    """
    model = SalesRoom
    success_url = reverse_lazy('sales_room_list')
    template_name = 'sales_rooms/sales_room_confirm_delete.html'
    slug_field = 'uuid'
    slug_url_kwarg = 'uuid'

    def get_success_url(self):
        messages.success(self.request, "Deal Room deleted successfully.")
        return reverse_lazy('sales_room_list')



class UploadMediaFileView(View):
    """
    Class-based view to handle media file uploads to a SalesRoom.
    """

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def post(self, request, uuid):
        try:
            sales_room = get_object_or_404(SalesRoom, uuid=uuid)
            files = request.FILES.getlist('files[]') or request.FILES.getlist("files")
            saved_files = []
            session_key = request.session.get("session_key")
            guest_session = None

            if session_key:
                try:
                    guest_session = GuestUserSessionKey.objects.select_related('guest_user').get(
                        session_key=session_key,
                        expires_at__gt=now()
                    )
                except GuestUserSessionKey.DoesNotExist:
                    guest_session = None

            document = ReportDocument.objects.filter(user=request.user).first()

            for file in files:
                file_path = default_storage.save(f'sales_rooms/{uuid}/{file.name}', file)

                media = SalesRoomMedia.objects.create(
                    sales_room=sales_room,
                    file=file_path,
                    document=document,
                    uploaded_by_user=request.user if request.user.is_authenticated else None,
                    uploaded_by_guest=guest_session.guest_user if guest_session else None,
                    # Explicitly set company for audit trail
                    company=sales_room.company if sales_room else None
                )

                saved_files.append({
                    'id': media.id,
                    'name': file.name,
                    'size': file.size,
                    'url': media.file.url
                })

            return JsonResponse({'status': 'success', 'files': saved_files, "message": "Files are uploaded successfully", "success": True})

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

    def get(self, request, *args, **kwargs):
        return HttpResponseNotAllowed(['POST'], "Invalid method")



class DeleteFileView(LoginRequiredMixin, View):
    def get(self, request, uuid, media_id):
        try:
            sales_room = get_object_or_404(SalesRoom, uuid=uuid)

            media = get_object_or_404(SalesRoomMedia, id=media_id, sales_room=sales_room)

            file_path = media.file.path

            if default_storage.exists(file_path):
                default_storage.delete(file_path)

            media.delete()

            messages.success(request, 'File deleted successfully')

            return redirect('sales_room_detail', uuid=uuid)

        except Exception as e:
            messages.error(request, f"An error occurred: {str(e)}")
            return redirect('sales_room_detail', uuid=uuid)



class AdminCommentView(LoginRequiredMixin, View):
    def post(self, request, document_id):
        try:
            document_id_int = int(document_id)
        except ValueError:
            return JsonResponse({'error': 'Invalid document_id format'}, status=status.HTTP_400_BAD_REQUEST)

        # Check for media or document
        sales_room_media = SalesRoomMedia.objects.filter(id=document_id_int).first()
        if sales_room_media:
            document = sales_room_media.document
            if not document:
                return JsonResponse({'error': 'No document linked to the given SalesRoomMedia'},
                                    status=status.HTTP_404_NOT_FOUND)
        else:
            try:
                document = ReportDocument.objects.get(id=document_id_int)
            except ObjectDoesNotExist:
                return JsonResponse({'error': 'No SalesRoomMedia or ReportDocument found with this id'},
                                    status=status.HTTP_404_NOT_FOUND)

        try:
            body = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON body'}, status=status.HTTP_400_BAD_REQUEST)

        content = body.get('content', '').strip()
        parent_id = body.get('parent_id')

        if not content:
            return JsonResponse({'error': 'Comment content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

        comment_data = {
            'document': document,
            'content': content,
            'created_by_user': request.user
        }

        # Explicitly set company for audit trail
        if document and document.company:
            comment_data['company'] = document.company

        try:
            comment = Comment.objects.create(**comment_data)

            if parent_id:
                try:
                    parent_comment = Comment.objects.get(pk=parent_id)
                    comment.parent = parent_comment
                    comment.save()
                except Comment.DoesNotExist:
                    return JsonResponse({'error': 'Parent comment not found'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return JsonResponse({'error': f"Error posting comment: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        serializer = CommentSerializer(comment)
        return JsonResponse(serializer.data, safe=False, status=status.HTTP_201_CREATED)


@method_decorator(csrf_exempt, name='dispatch')
class SendInviteEmailView(View):
    def post(self, request, uuid):
        try:
            data = json.loads(request.body)
            email = data.get('email')
            url = data.get('url')

            if not email:
                return JsonResponse({'success': False, 'error': 'Email is required'}, status=400)

            sales_room = get_object_or_404(SalesRoom, uuid=uuid)

            subject = f"Invitation to {sales_room.name}"
            message = f"""Hello,

You've been invited to access the Deal Room: {sales_room.name}.

Click the link below to join:
{url}

Best regards,
{sales_room.client.name if sales_room.client else 'Your Host'}"""

            send_invite_email_task.delay(subject, message, email)

            return JsonResponse({'success': True})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
# apps/salesforce/management/commands/generate_test_data.py
import glob
import os
import random
import uuid
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
import os
import glob
from django.core.files import File
from faker import Faker
from django.core.files.base import ContentFile, File
from apps.authentication.models import CustomUser, Client, GuestUser
from apps.report_management.models import (
    ReportDocument,
    ReportFormation,
    ReportTemplate,
    Transcript,
    ReportStatusChoices,
    ReportTypeChoices,
    PlatformChoices
)
from apps.sale_rooms.models import (
    SalesRoom,
    SalesRoomMedia,
    ClientContact,
    Comment,
    MutualActionItem,
    StatusChoices,
    RoleChoices,
    MediaTypes,
    TaskStatusChoices,
    AccessTypes,
    DocumentTypes,
    PriorityChoices
)

User = get_user_model()
fake = Faker()


class Command(BaseCommand):
    help = 'Generates test data for Digital Room models'

    def add_arguments(self, parser):
        parser.add_argument(
            '--count',
            type=int,
            default=10,
            help='Number of records to create for each model (default: 10)',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing test data before generation',
        )

    def handle(self, *args, **options):
        count = options['count']
        clear = options['clear']

        if clear:
            self.clear_existing_data()

        self.stdout.write(self.style.SUCCESS(f'Generating {count} test records for each model...'))

        # Create test users if needed
        staff_users = self.create_staff_users()
        client_users = self.create_client_users(count)
        clients = self.create_clients(client_users)

        # Create Deal Rooms
        sales_rooms = self.create_sales_rooms(clients, staff_users)

        # Generate all test data
        client_contacts = self.create_client_contacts(clients, count)

        # Create required related objects first
        templates = self.create_report_templates()
        transcripts = self.create_transcripts(clients, staff_users)

        report_forms = self.create_report_forms(staff_users, count, templates, transcripts, sales_rooms)
        report_documents = self.create_report_documents(report_forms, staff_users, count, sales_rooms)
        self.create_sales_room_media(sales_rooms, staff_users, report_documents)
        self.create_action_items(sales_rooms, staff_users, count)
        self.create_comments(report_documents, staff_users)
        self.create_guest_users(count)

        self.stdout.write(self.style.SUCCESS('Test data generation completed!'))

    def clear_existing_data(self):
        """Clear existing test data"""
        self.stdout.write(self.style.WARNING('Clearing existing test data...'))
        models_to_clear = [
            SalesRoomMedia,
            Comment,
            MutualActionItem,
            ClientContact,
            ReportDocument,
            ReportFormation,
            ReportTemplate,
            Transcript,
            SalesRoom,
            GuestUser
        ]

        for model in models_to_clear:
            model.objects.all().delete()

    def create_report_templates(self, count=5):
        """Create report templates only if keys don't exist"""
        templates = []
        available_choices = [choice[0] for choice in ReportTypeChoices.choices]

        # Avoid duplicates
        existing_keys = set(ReportTemplate.objects.values_list('key', flat=True))
        remaining_choices = [key for key in available_choices if key not in existing_keys]

        if not remaining_choices:
            self.stdout.write(self.style.WARNING("All report template keys already exist. Skipping creation."))
            return list(ReportTemplate.objects.all())

        if count > len(remaining_choices):
            self.stdout.write(self.style.WARNING(
                f"Only {len(remaining_choices)} unique keys available. Reducing count from {count} to {len(remaining_choices)}."
            ))
            count = len(remaining_choices)

        random.shuffle(remaining_choices)

        for i in range(count):
            template = ReportTemplate.objects.create(
                key=remaining_choices[i],
                title=f"Template {uuid.uuid4().hex[:4]}",
                description=fake.paragraph(),
                json_schema=None,
                agent_name=fake.name(),
                agent_role=fake.job(),
                agent_prompt=fake.paragraph(),
                agent_report_instructions=[]
            )
            templates.append(template)

        self.stdout.write(self.style.SUCCESS(f"Created {len(templates)} ReportTemplate records"))
        return templates

    def create_transcripts(self, clients, users):
        """Create transcripts"""
        transcripts = []
        for client in clients:
            for user in users:
                transcript = Transcript.objects.create(
                    title=f"Transcript {uuid.uuid4().hex[:4]}",
                    text="\n".join(fake.paragraphs(nb=3)),
                    platform=random.choice([choice[0] for choice in PlatformChoices.choices]),
                    client=client,
                    user=user,
                    created_at=timezone.now()
                )
                transcripts.append(transcript)
        self.stdout.write(self.style.SUCCESS(f'Created {len(transcripts)} Transcript records'))
        return transcripts

    def create_staff_users(self, count=3):
        """Create staff users if they don't exist"""
        if not User.objects.filter(is_staff=True).exists():
            staff_users = []
            for i in range(count):
                user = User.objects.create_user(
                    email=f'staff-{uuid.uuid4().hex[:8]}@example.com',
                    password='staff123',
                    is_staff=True,
                    first_name=fake.first_name(),
                    last_name=fake.last_name()
                )
                staff_users.append(user)
            self.stdout.write(self.style.SUCCESS(f'Created {len(staff_users)} staff users'))
            return staff_users
        return list(User.objects.filter(is_staff=True))

    def create_client_users(self, count):
        """Create client users with unique emails"""
        client_users = []
        for i in range(count):
            user = User.objects.create_user(
                email=f'client-{uuid.uuid4().hex[:8]}@example.com',
                password='client123',
                is_staff=False,
                first_name=fake.first_name(),
                last_name=fake.last_name()
            )
            client_users.append(user)
        self.stdout.write(self.style.SUCCESS(f'Created {len(client_users)} client users'))
        return client_users

    def create_clients(self, users):
        """Create client records"""
        clients = []
        for user in users:
            client = Client.objects.create(
                user=user,
                name=fake.company(),
            )
            clients.append(client)
        self.stdout.write(self.style.SUCCESS(f'Created {len(clients)} Client records'))
        return clients

    def create_sales_rooms(self, clients, users):
        """Create Deal Rooms"""
        sales_rooms = []
        for client in clients:
            room = SalesRoom.objects.create(
                user=random.choice(users),
                client=client,
                name=f"Deal Room for {client.name}",
                created_at=timezone.now()
            )
            sales_rooms.append(room)
        self.stdout.write(self.style.SUCCESS(f'Created {len(sales_rooms)} SalesRoom records'))
        return sales_rooms

    def create_client_contacts(self, clients, count):
        """Create client contacts with unique emails"""
        client_contacts = []
        for client in clients:
            for i in range(count):
                contact = ClientContact.objects.create(
                    client=client,
                    first_name=fake.first_name(),
                    last_name=fake.last_name(),
                    email=f'contact-{uuid.uuid4().hex[:8]}@example.com',
                    phone=fake.phone_number(),
                    role=random.choice([choice[0] for choice in RoleChoices.choices]),
                    is_active=random.choice([True, False]),
                    salesforce_id=fake.uuid4()[:18],
                    user_account=random.choice([None, client.user] if i == 0 else [None])
                )
                client_contacts.append(contact)
        self.stdout.write(self.style.SUCCESS(f'Created {len(client_contacts)} ClientContact records'))
        return client_contacts

    def create_report_forms(self, users, count, templates, transcripts, sales_rooms):
        """Create report formations"""
        report_forms = []
        for i in range(count):
            form = ReportFormation.objects.create(
                template=random.choice(templates),
                transcript=random.choice(transcripts),
                status=random.choice([choice[0] for choice in ReportStatusChoices.choices]),
                output_data={"sample": "data"},
                created_at=timezone.now(),
                user=random.choice(users),
            )
            report_forms.append(form)
        self.stdout.write(self.style.SUCCESS(f'Created {len(report_forms)} ReportFormation records'))
        return report_forms

    def create_report_documents(self, report_forms, users, count, sales_rooms):
        """Create report documents with dummy files"""
        report_documents = []
        for form in report_forms:
            dummy_content = fake.text(max_nb_chars=500)
            filename = f'document_{uuid.uuid4().hex[:8]}.txt'

            doc = ReportDocument.objects.create(
                report=form,
                sales_room=random.choice(sales_rooms),
                title=f'Document {uuid.uuid4().hex[:4]} for Report {form.id}',
                version=f'v{random.randint(1, 5)}',
                content='\n'.join(fake.paragraphs(nb=3)),
                created_at=timezone.now(),
                user=random.choice(users)
            )
            # Attach a dummy file
            doc.file.save(filename, ContentFile(dummy_content))
            doc.save()

            report_documents.append(doc)

        self.stdout.write(self.style.SUCCESS(f'Created {len(report_documents)} ReportDocument records'))
        return report_documents

    def create_sales_room_media(self, sales_rooms, users, report_documents):
        """Create Deal Room media files with random image from any sales_room subfolder"""
        media_files = []

        # Get all JPG images from any subdirectory inside sales_rooms/
        base_dir = "/home/hamza-bilal/django-boiler-plate/media/sales_rooms"
        image_files = glob.glob(os.path.join(base_dir, "*", "*.jpg"))  # Looks in all UUID dirs

        if not image_files:
            self.stdout.write(self.style.WARNING("⚠️ No image files found under sales_rooms/"))
            return media_files

        for room in sales_rooms:
            for i in range(3):  # 3 media files per room
                for user in users:
                    image_path = random.choice(image_files)

                    with open(image_path, 'rb') as f:
                        media = SalesRoomMedia.objects.create(
                            sales_room=room,
                            uploaded_by_user=user,
                            uploaded_at=timezone.now(),
                            document=random.choice(report_documents) if random.choice([True, False]) else None
                        )
                        media.file.save(f"media_{uuid.uuid4().hex[:8]}.jpg", File(f), save=True)
                        media_files.append(media)

        self.stdout.write(self.style.SUCCESS(f'✅ Created {len(media_files)} SalesRoomMedia records'))
        return media_files

    def create_action_items(self, sales_rooms, users, count):
        """Create mutual action items"""
        action_items = []
        for room in sales_rooms:
            for i in range(count):
                item = MutualActionItem.objects.create(
                    sales_room=room,
                    title=f"Action Item {i + 1} for {room.name}",
                    description=fake.paragraph(),
                    due_date=timezone.now() + timedelta(days=random.randint(1, 30)),
                    status=random.choice([choice[0] for choice in TaskStatusChoices.choices]),
                    created_by_user=random.choice(users),
                    priority=random.choice([choice[0] for choice in PriorityChoices.choices])
                )
                action_items.append(item)
        self.stdout.write(self.style.SUCCESS(f'Created {len(action_items)} MutualActionItem records'))
        return action_items

    def create_comments(self, report_documents, users):
        """Create comments on documents"""
        comments = []
        for doc in report_documents:
            for i in range(random.randint(1, 3)):  # 1-3 comments per doc
                comment = Comment.objects.create(
                    document=doc,
                    content=fake.paragraph(),
                    created_by_user=random.choice(users),
                    created_at=timezone.now()
                )
                # Sometimes add replies
                if random.choice([True, False]):
                    reply = Comment.objects.create(
                        document=doc,
                        parent=comment,
                        content=fake.paragraph(),
                        created_by_user=random.choice(users),
                        created_at=timezone.now() + timedelta(minutes=random.randint(1, 60))
                    )
                    comments.append(reply)
                comments.append(comment)
        self.stdout.write(self.style.SUCCESS(f'Created {len(comments)} Comment records'))
        return comments

    def create_guest_users(self, count):
        """Create guest users"""
        guest_users = []
        for i in range(count):
            guest = GuestUser.objects.create(
                name=fake.name(),
                email=f'guest-{uuid.uuid4().hex[:8]}@example.com',
            )
            guest_users.append(guest)
        self.stdout.write(self.style.SUCCESS(f'Created {len(guest_users)} GuestUser records'))
        return guest_users
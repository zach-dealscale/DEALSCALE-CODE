from django.urls import path
from . import room_views
from .room_views.comments_views import *
from .room_views import user_room, guest_room

urlpatterns = [
    # Comment API endpoints
    path('api/media/<int:document_id>/comments/', get_document_comments, name='get_document_comments'),
    path('api/media/<int:document_id>/comments/add/', add_document_comment, name='add_document_comment'),
    path('api/comments/<int:comment_id>/replies/', add_comment_reply, name='add_comment_reply'),

    #sale-rooms Urls
    path("rooms/", user_room.SalesRoomListView.as_view(), name="sales_room_list"),
    path('rooms/create/', user_room.SalesRoomCreateView.as_view(), name='create_sales_room'),
    path('rooms/<uuid:uuid>/', user_room.SalesRoomDetailView.as_view(), name='sales_room_detail'),
    path('rooms/<uuid:uuid>/download/', user_room.SalesRoomDownloadPDFView.as_view(), name='sales_room_download_pdf'),
    path('rooms/<uuid:uuid>/edit/', user_room.SalesRoomEditView.as_view(), name='edit_sales_room'),
    path('rooms/<uuid:uuid>/delete/', user_room.SalesRoomDeleteView.as_view(), name='delete_sales_room'),
    path('rooms/<uuid:uuid>/upload/', user_room.UploadMediaFileView.as_view(), name='sales_room_upload_media'),
    path('rooms/<uuid:uuid>/delete-file/<int:media_id>/', user_room.DeleteFileView.as_view(), name='delete_file'),
    path('rooms/admin_add_comments/<int:document_id>/', user_room.AdminCommentView.as_view(), name='admin_add_comments'),
    path('salesroom/<uuid:uuid>/invite/', user_room.SendInviteEmailView.as_view(), name='send_invitation_email'),

    # guest-room Urls
    path('guest-room/upload-media/<uuid:uuid>/', guest_room.GuestRoomMediaUploadView.as_view(), name='guest_room_upload_media'),
    path('guest-room/<uuid:uuid>/access/', guest_room.GuestLoginView.as_view(), name='guest_room_login'),
    path('guest-room/logout/<uuid:uuid>/', guest_room.GuestLogoutView.as_view(), name='guest_room_logout'),
    path('guest-room/<uuid:uuid>/documents/', guest_room.GuestRoomView.as_view(), name='guest_room_document'),
    path("guest-room/<uuid:uuid>/media/", guest_room.GuestRoomMediaView.as_view(), name="guest_room_media"),
    path("guest-room/documents/detail/<int:pk>/", guest_room.DocumentDetailView.as_view(),
         name="guest_room_document_detail_view"),
    path('guest_room/<uuid:uuid>/', guest_room.GuestRoomDashboard.as_view(), name='guest_room_dashboard'),
    path('guest_room/<uuid:uuid>/map/', guest_room.KanbanBoardViews.as_view(), name='guest_room_mutual_action_plan'),
    path('guest_room/update-action-item-status/', guest_room.UpdateActionItemStatus.as_view(), name='guest_room_update_action_item_status'),
    path('guest_room/update-action-item/', guest_room.UpdatedActionItemView.as_view(), name='guest_room_update_action_item'),
    path('guest_room/<uuid:uuid>/create-action-item/', guest_room.CreateActionItemView.as_view(), name='guest_room_create_action_item'),
    path('guest_room/<uuid:uuid>/get-filtered-action-items/', guest_room.GetFilteredItemsView.as_view(),
         name='guest_room_get_filtered_items'),
    path('guest_room/documents/<int:document_id>/comment/', guest_room.AddCommentView.as_view(), name='guest_room_add_comment'),
    path('guest_room/get-comments/', guest_room.CommentsByMediaView.as_view(), name='guest_room_get_comments'),
    path('documents/guest-views/', guest_room.TrackDocumentView.as_view(), name="guest_room_documents_track"),
    path('guest-room/<uuid:uuid>/delete/', guest_room.GuestRoomDeleteFileView.as_view(), name='guest_room_delete'),

]
from django import forms
# from .models import Client
#
# class ClientForm(forms.ModelForm):
#     class Meta:
#         model = Client
#         fields = ['name', 'email', 'phone']


from django import forms
from .models import SalesRoom, Client

class SalesRoomForm(forms.ModelForm):
    class Meta:
        model = SalesRoom
        fields = ['client', 'name']
        widgets = {
            'client': forms.Select(attrs={'class': 'form-select'}),
            'name': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm dark:bg-dark-card dark:text-white',
                'placeholder': 'e.g. Zaller Collaboration Room'
            }),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned_data = super().clean()
        client = cleaned_data.get('client')
        if client and self.user and SalesRoom.objects.filter(client=client, user=self.user).exists():
            raise forms.ValidationError(
                {'client': f"A Deal Room for '{client.name}' already exists."}
            )
        return cleaned_data


class SalesRoomUpdateForm(forms.ModelForm):
    class Meta:
        model = SalesRoom
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-input w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm dark:bg-dark-card dark:border-dark-border dark:text-white',
                'placeholder': 'Enter meeting title',
            }),
        }
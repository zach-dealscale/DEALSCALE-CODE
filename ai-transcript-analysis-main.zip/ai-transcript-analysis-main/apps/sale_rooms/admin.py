from django.contrib import admin
from .models import (
    ClientContact, SalesRoom, SalesRoomMedia, MutualActionItem,
)
from ..report_management.models import PinnedReportTemplate


@admin.register(ClientContact)
class ClientContactAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'role', 'is_active')
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('role', 'is_active')

@admin.register(SalesRoom)
class SalesRoomAdmin(admin.ModelAdmin):
    list_display = ['name', 'client', 'uuid', 'created_at']
    search_fields = ['name', 'client__name']

@admin.register(SalesRoomMedia)
class SalesRoomMediaAdmin(admin.ModelAdmin):
    list_display = ['file', 'sales_room', 'uploaded_at', 'uploaded_by_user']
    list_filter = ['sales_room']
    raw_id_fields = ['uploaded_by_user', 'uploaded_by_guest']

@admin.register(MutualActionItem)
class MutualActionItemAdmin(admin.ModelAdmin):
    list_display = ['task_detail', 'sales_room', 'status', 'due_date']
    list_filter = ['status', 'sales_room']
    search_fields = ['task_detail', 'description']

admin.site.register(PinnedReportTemplate)
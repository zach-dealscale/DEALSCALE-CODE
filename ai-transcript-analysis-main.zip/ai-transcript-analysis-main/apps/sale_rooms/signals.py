from django.dispatch.dispatcher import logger
from django.db import transaction
from apps.integrations.salesforce.service import SalesforceService
from apps.sale_rooms.models import ClientContact
from apps.report_management.models import ReportDocument
from apps.sale_rooms.models import SalesRoom, SalesRoomMedia
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone
from datetime import timedelta
from datetime import datetime, time as datetime_time
from .models import MutualActionItem
from .tasks import check_and_send_overdue_notification


from django.db import transaction
from django.db.models import Q
from django.db.models.signals import post_save
from django.dispatch import receiver
import logging

logger = logging.getLogger(__name__)


@receiver(post_save, sender=SalesRoom)
def assign_sales_room_to_documents(sender, instance, created, **kwargs):
    """
    Automatically assign a newly created SalesRoom to all related ReportDocuments.
    Handles both single and many-to-many transcript relationships.
    """
    if not created:
        return

    try:
        with transaction.atomic():
            report_documents = ReportDocument.objects.filter(
                Q(report__transcript__client=instance.client) |
                Q(report__additional_transcripts__client=instance.client) |
                Q(client=instance.client)
            ).distinct()

            if not report_documents.exists():
                logger.info(
                    f"[SalesRoom → Documents] No ReportDocuments found for client {instance.client} "
                    f"to assign SalesRoom {instance.id}."
                )
                return

            updated_count = report_documents.update(sales_room=instance)
            logger.info(
                f"[SalesRoom → Documents] Assigned SalesRoom {instance.id} "
                f"to {updated_count} ReportDocuments for client {instance.client}."
            )

            sales_room_media_qs = list(SalesRoomMedia.objects.filter(sales_room=instance))
            if not sales_room_media_qs:
                logger.info(
                    f"[SalesRoom → Documents] No SalesRoomMedia entries exist yet for SalesRoom {instance.id}."
                )
                return

            for doc in report_documents:
                for media in sales_room_media_qs:
                    media.documents.add(doc)
            logger.info(
                f"[SalesRoom → Documents] Linked {len(report_documents)} ReportDocuments "
                f"to {len(sales_room_media_qs)} SalesRoomMedia entries for SalesRoom {instance.id}."
            )

    except Exception as e:
        logger.error(f"[SalesRoom → Documents] Error assigning SalesRoom {instance.id} to documents: {e}", exc_info=True)


@receiver(post_save, sender=SalesRoomMedia)
def attach_documents_with_sales_room_media(sender, instance, created, **kwargs):
    if created:
        try:
            report_documents = ReportDocument.objects.filter(
                sales_room=instance.sales_room
            )
            if report_documents.exists():
                report_document =report_documents.first()
                instance.document = report_document
                instance.save()

                logger.info(f"Assigned Report Document for {report_document} to Deal Room Media for {instance.id}.")
            else:
                logger.info(f"No Report Document for Deal Room {instance.sales_room.id}.")

        except Exception as e:
            logger.error(f"Error assigning Deal Room Media to documents: {e}")



@receiver(post_save, sender=ClientContact)
def sync_contact_to_salesforce(sender, instance, **kwargs):
    try:
        if instance.client and instance.client.user:  # assuming client has FK to user
            sf = SalesforceService(user=instance.client.user)
            sf.create_or_update_contact(instance)
    except Exception as e:
        # Log it somewhere, but don’t crash your app
        print("Salesforce sync failed:", str(e))

@receiver(post_save, sender=MutualActionItem)
def schedule_overdue_notification(sender, instance, created, **kwargs):
    if instance.due_date and instance.status in ['todo', 'in_progress']:
        if isinstance(instance.due_date, str):
            from django.utils.dateparse import parse_date
            due_date = parse_date(instance.due_date)
        else:
            due_date = instance.due_date  # Already a date object

        due_datetime = timezone.make_aware(
            datetime.combine(due_date, datetime_time.min)
        ) + timedelta(days=1)  # Next day at midnight

        check_and_send_overdue_notification.apply_async(
            args=[instance.id],
            eta=due_datetime
        )


@receiver(pre_save, sender=MutualActionItem)
def reset_notification_status(sender, instance, **kwargs):
    if instance.pk:
        try:
            old_instance = MutualActionItem.objects.get(pk=instance.pk)
            if (old_instance.due_date != instance.due_date or
                    (old_instance.status == 'completed' and instance.status in ['todo', 'in_progress'])):
                instance.is_notification_sent = False
        except MutualActionItem.DoesNotExist:
            pass
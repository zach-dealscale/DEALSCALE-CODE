import logging
from simple_salesforce import Salesforce
from django.db import models

logger = logging.getLogger(__name__)

class StatusChoices(models.TextChoices):
    """
    Status Choices Enums for Digital Room Status
    """
    ACTIVE = 'active', 'Active'
    ARCHIVED = 'archived', 'Archived'

class RoleChoices(models.TextChoices):
    """
    Role Choices Enums for Digital Room Role
    """
    PRIMARY = 'primary', 'Primary Contact'
    TECHNICAL = 'technical', 'Technical Contact'
    BILLING = 'billing', 'Billing Contact'
    DECISION_MAKER = 'decision_maker', 'Decision Maker'
    OTHER = 'other', 'Other'


class MediaTypes(models.TextChoices):
    """
    Media Types for Documents
    """
    PRESENTATION = 'presentation'
    RECORDING = 'recording'
    ATTACHMENT = 'attachment'
    OTHER = 'other'

class TaskStatusChoices(models.TextChoices):
    """
    Task Status Choices
    """
    TODO = "todo" , "To DO"
    IN_PROGRESS = "in_progress" , "In Progress"
    BLOCKED = "blocked" , "blocked"
    COMPLETED = "completed" , "Completed"

class PriorityChoices(models.TextChoices):
    """
    Priority Choices
    """
    LOW = "low" , "Low"
    MEDIUM = "medium" , "Medium"
    HIGH = "high" , "High"


class AccessTypes(models.TextChoices):
    """
    Access Types for Documents
    """
    VIEW = "view"
    COMMENT = "comment"
    EDIT = "edit"


class DocumentTypes(models.TextChoices):
    """
    Document Types
    """
    PROPOSAL = "proposal"
    CONTRACT = "contract"
    REPORT = "report"
    PRESENTATION = "presentation"
    RECORDING = "recording"
    OTHER = "other"


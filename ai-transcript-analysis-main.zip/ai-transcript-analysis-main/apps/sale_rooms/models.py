import uuid
from django.utils import timezone
from django.core.validators import FileExtensionValidator
from django.db import models
from django.conf import settings

from apps.authentication.models import CustomUser, Client, GuestUser, Company
from apps.sale_rooms.salesforce_integration_utils import StatusChoices, RoleChoices, MediaTypes, TaskStatusChoices, \
    AccessTypes, DocumentTypes, PriorityChoices
import uuid

User = settings.AUTH_USER_MODEL


class SalesRoom(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE, related_name='sale_rooms', null=True, blank=True)
    client = models.OneToOneField(Client, on_delete=models.CASCADE, related_name='sales_room')
    uuid = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='sales_rooms',
        null=True,
        blank=True
    )

    # ✅ NEW: Track who created this Deal Room
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_sales_rooms'
    )

    class Meta:
        indexes = [
            models.Index(fields=['company', 'created_at'], name='salesroom_company_created_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from client if not already set."""
        if not self.company:
            if self.client and self.client.company:
                self.company = self.client.company
        if not self.created_by and self.user:
            self.created_by = self.user
        super().save(*args, **kwargs)


class SalesRoomMedia(models.Model):
    sales_room = models.ForeignKey(SalesRoom, on_delete=models.CASCADE, related_name='media')
    file = models.FileField(upload_to="salesroom/files/")
    uploaded_by_user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    uploaded_by_guest = models.ForeignKey(
        GuestUser,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)
    document= models.ForeignKey('report_management.ReportDocument', on_delete=models.CASCADE, related_name='media', blank=True, null=True)
    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='sales_room_media',
        null=True,
        blank=True
    )

    class Meta:
        indexes = [
            models.Index(fields=['company', 'uploaded_at'], name='sroommed_company_uploaded_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from sales_room or document if not already set."""
        if not self.company:
            if self.sales_room and self.sales_room.company:
                self.company = self.sales_room.company
            elif self.document and self.document.company:
                self.company = self.document.company
        super().save(*args, **kwargs)

    @property
    def file_type(self):
        file_name = self.file.name
        file_extension = file_name.split('.')[-1].lower()
        return file_extension

    @property
    def file_name(self):
        file_name = self.file.name
        file_name = file_name.split('/')[-1]
        return file_name

    @property
    def file_size(self):
        # Format file size into KB or MB 
        file_size = self.file.size / 1024  # Convert bytes to KB
        if file_size > 1024:
            file_size = file_size / 1024
            file_size = f"{file_size:.2f} MB"
        else:
            file_size = f"{file_size:.2f} KB"
        return file_size

    @property
    def file_url(self):
        # Instead of returning the direct file URL, return the URL for the serve_media view
        from django.urls import reverse
        return reverse('serve_media', kwargs={'media_id': self.id})

    @property
    def uploaded_by(self):
        """Return the user who uploaded the file, whether it's a regular user or a guest"""
        if self.uploaded_by_user:
            return {
                'name': self.uploaded_by_user.get_full_name() or self.uploaded_by_user.username,
                'id': self.uploaded_by_user.id
            }
        elif self.uploaded_by_guest:
            return {
                'name': self.uploaded_by_guest.name,
                'id': self.uploaded_by_guest.id
            }
        return {
            'name': 'Unknown User',
            'id': 0
        }


class Comment(models.Model):
    document = models.ForeignKey(
        'report_management.ReportDocument',
        on_delete=models.CASCADE,
        related_name='document_comments'
    )
    parent = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='replies'
    )
    content = models.TextField()
    created_by_user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    created_by_guest = models.ForeignKey(
        GuestUser,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    created_at = models.DateTimeField(auto_now_add=True)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True
    )

    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['company', 'document', 'created_at'], name='cmt_co_doc_created_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from document if not already set."""
        if not self.company and self.document and self.document.company:
            self.company = self.document.company
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Comment by {self.author_name} on {self.document.title}"

    @property
    def author_name(self):
        if self.created_by_user:
            return self.created_by_user.get_full_name()
        elif self.created_by_guest:
            return self.created_by_guest.name
        return "Anonymous"


class MutualActionItem(models.Model):
    sales_room = models.ForeignKey(SalesRoom, on_delete=models.CASCADE, related_name='action_items')
    task_detail = models.TextField(default="")
    due_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=TaskStatusChoices.choices, default='todo')
    created_by_user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    created_by_guest = models.ForeignKey(
        GuestUser,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    created_at = models.DateTimeField(auto_now_add=True)
    priority = models.CharField(
        max_length=6,
        choices=PriorityChoices.choices,
        default=PriorityChoices.HIGH,
    )
    guest_assignee = models.ForeignKey(GuestUser, null=True, blank=True, on_delete=models.SET_NULL, related_name='guest_actions')
    admin_assignee = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='admin_actions')
    last_overdue_notification_sent = models.DateTimeField(null=True, blank=True)
    is_notification_sent = models.BooleanField(default=False)

    # ✅ NEW: Company-level scoping
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='action_items',
        null=True,
        blank=True
    )

    class Meta:
        indexes = [
            models.Index(fields=['company', 'status'], name='actionitem_company_status_idx'),
            models.Index(fields=['company', 'due_date'], name='actionitem_company_due_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from sales_room if not already set."""
        if not self.company and self.sales_room and self.sales_room.company:
            self.company = self.sales_room.company
        super().save(*args, **kwargs)

    @property
    def is_overdue(self):
        return (
            self.due_date and
            self.due_date < timezone.now().date() and
            self.status in ['todo', 'in_progress']
        )


class ClientContact(models.Model):
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='client_contacts',
        null=True,
        blank=True,
    )
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(null=True, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    role = models.CharField(
        max_length=20,
        choices=RoleChoices.choices,
        default=RoleChoices.TECHNICAL,
    )
    is_active = models.BooleanField(default=True)
    salesforce_id = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Linked Salesforce Contact ID"
    )
    user_account = models.OneToOneField(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Linked user account if contact has login access"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    notes = models.TextField(blank=True)

    # ✅ NEW: Company-level scoping (improves query performance)
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='client_contacts',
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = "Client Contact"
        verbose_name_plural = "Client Contacts"
        ordering = ['last_name', 'first_name']
        indexes = [
            models.Index(fields=['company', 'client'], name='cntc_company_client_idx'),
        ]

    def save(self, *args, **kwargs):
        """Auto-set company from client if not already set."""
        if not self.company and self.client and self.client.company:
            self.company = self.client.company
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
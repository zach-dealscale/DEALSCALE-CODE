from django.apps import AppConfig


class SalesforceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.sale_rooms'

    def ready(self):
        import apps.sale_rooms.signals

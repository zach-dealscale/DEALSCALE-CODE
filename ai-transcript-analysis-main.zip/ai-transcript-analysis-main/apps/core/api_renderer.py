from rest_framework.renderers import JSONRenderer
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class StandardAPIRenderer(JSONRenderer):
    """
    Standardized API renderer for Django REST Framework with consistent response structure.
    """

    media_type = 'application/json'
    format = 'json'

    def render(self, data: Any, accepted_media_type: Optional[str] = None,
               renderer_context: Optional[Dict] = None) -> bytes:
        """Render data with a standardized structure."""
        renderer_context = renderer_context or {}
        response = renderer_context.get('response')
        status_code = getattr(response, 'status_code', 200)

        # Extract detail from Response() kwargs if available
        detail = getattr(response, "detail", None)

        # Determine response type based on status code
        if 200 <= status_code < 300:
            result = self._format_response('success', data, status_code, detail)
        elif 300 <= status_code < 400:
            result = self._format_response('warning', data, status_code, detail)
            logger.warning(f"API Warning: {status_code} - {result.get('detail', 'No detail')}")
        else:
            result = self._format_response('error', data, status_code, detail)
            logger.error(f"API Error: {status_code} - {result.get('detail', 'No detail')}")

        return super().render(result, accepted_media_type, renderer_context)

    def _format_response(self, status: str, data: Any, status_code: int, detail: Optional[str]) -> Dict[str, Any]:
        """Format response with consistent structure."""
        # Initialize result
        result = {'status': status, 'data': {}}

        # Handle data and detail extraction
        if isinstance(data, dict):
            # Extract detail from 'detail'
            detail = detail or data.pop('detail', None)

            # Add remaining data
            result['data'] = data
        else:
            # If data is not a dict, add it directly
            result['data'] = data if data is not None else {}

        # Add detail if available
        if detail:
            result['detail'] = detail

        # Add default details for certain status codes if no detail exists
        if 'detail' not in result:
            if status_code == 201:
                result['detail'] = 'Resource created successfully'
            elif status_code == 204:
                result['detail'] = 'Resource deleted successfully'
            elif status == 'error':
                result['detail'] = 'An error occurred'
            elif status == 'warning':
                result['detail'] = 'A warning occurred'

        return result
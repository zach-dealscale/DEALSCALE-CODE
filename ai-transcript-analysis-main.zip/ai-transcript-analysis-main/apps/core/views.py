from django.http import FileResponse
from rest_framework import status
import logging
from django.db import connection
from apps.core.utils import _calculate_percentage_change
from django.db.models import Func, F, IntegerField, Q
from django.contrib.auth.mixins import LoginRequiredMixin
from django.utils.timezone import now
from django.views.generic import TemplateView
from django.db.models import Sum
from datetime import timedelta
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from django.utils.encoding import smart_str

logger = logging.getLogger(__name__)
from django.db.models import Sum, Count
from django.utils.decorators import method_decorator
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from django.db.models import Count
from apps.authentication.models import Client
from apps.integrations.models import ZoomCredential, SalesforceCredential, GoogleDriveCredential
from apps.report_management.models import Transcript, ReportTemplate, ReportFormation, ReportDocument
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from apps.core.utils import humanize_big_number
from apps.core.mixins import RoleBasedClientAccessMixin

from datetime import timedelta
from django.views import View
from django.http import HttpResponse, Http404, JsonResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from apps.sale_rooms.models import SalesRoomMedia, Comment, SalesRoom
import re

from apps.report_management.helpers.report_choices import PlatformChoices


def health_check(request):
    """
    Simple health check endpoint to verify the server is running.
    """
    return JsonResponse({'status': 'ok'}, status=200)
    
@method_decorator(login_required, name='dispatch')
class HomeView(RoleBasedClientAccessMixin, TemplateView):
    template_name = "core/home.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        try:
            user = self.request.user
            now = timezone.now()

            # --- Time periods ---
            current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

            if current_month_start.month == 1:
                last_month_start = current_month_start.replace(year=current_month_start.year - 1, month=12)
            else:
                last_month_start = current_month_start.replace(month=current_month_start.month - 1)
            last_month_end = current_month_start - timedelta(seconds=1)

            current_week_start = now - timedelta(days=now.weekday())
            current_week_start = current_week_start.replace(hour=0, minute=0, second=0, microsecond=0)
            last_week_start = current_week_start - timedelta(days=7)
            last_week_end = current_week_start - timedelta(seconds=1)

            # --- Get accessible clients based on role hierarchy ---
            accessible_clients = self.get_accessible_clients(user)

            # --- All documents from accessible clients ---
            all_documents = ReportDocument.objects.filter(
                report__transcript__client__in=accessible_clients
            ) | ReportDocument.objects.filter(client__in=accessible_clients)
            all_documents = all_documents.distinct()
            all_time_saved = all_documents.count() * 1.5

            # --- Documents generated & time saved ---
            month_docs_generated = all_documents.filter(created_at__gte=current_month_start).count()
            last_month_docs = all_documents.filter(created_at__gte=last_month_start, created_at__lte=last_month_end).count()
            month_time_saved = month_docs_generated * 1.5
            last_month_time_saved = last_month_docs * 1.5
            month_docs_diff = max(month_docs_generated - last_month_docs, 0)
            month_time_diff = max(month_time_saved - last_month_time_saved, 0)

            current_week_docs = all_documents.filter(created_at__gte=current_week_start).count()
            last_week_docs = all_documents.filter(created_at__gte=last_week_start, created_at__lte=last_week_end).count()
            current_week_time_saved = current_week_docs * 1.5
            last_week_time_saved = last_week_docs * 1.5
            week_docs_diff = max(current_week_docs - last_week_docs, 0)
            time_saved_diff = max(current_week_time_saved - last_week_time_saved, 0)

            # --- Pipeline metrics from accessible clients ---
            current_month_pipeline = accessible_clients.filter(
                created_at__gte=current_month_start
            ).aggregate(total=Sum('company_size'))['total'] or 0

            last_month_pipeline = accessible_clients.filter(
                created_at__gte=last_month_start, created_at__lte=last_month_end
            ).aggregate(total=Sum('company_size'))['total'] or 0

            all_month_pipeline = accessible_clients.aggregate(total=Sum('company_size'))['total'] or 0
            pipeline_change = max(_calculate_percentage_change(last_month_pipeline, current_month_pipeline), 0)

            # --- Active deals from accessible clients ---
            month_active_deals = accessible_clients.filter(created_at__gte=current_month_start).count()
            current_week_deals = accessible_clients.filter(created_at__gte=current_week_start).count()
            last_week_deals = accessible_clients.filter(created_at__gte=last_week_start, created_at__lte=last_week_end).count()
            deals_diff = max(current_week_deals - last_week_deals, 0)

            # --- Recent deals from accessible clients ---
            recent_deals = list(accessible_clients.order_by('-created_at'))
            for client in recent_deals:
                client.company_size = humanize_big_number(client.company_size)

            # --- Transcripts related to recent deals ---
            transcripts_for_deals = Transcript.objects.filter(client__in=recent_deals)

            # --- Report counts (fixed annotation names) ---
            report_counts_main = (
                ReportDocument.objects
                .filter(user=user, report__transcript__in=transcripts_for_deals)
                .annotate(related_client_id=F('report__transcript__client_id'))
                .values('related_client_id')
                .annotate(
                    total=Count('id'),
                    completed=Count('id', filter=Q(report__status='completed'))
                )
            )

            report_counts_additional = (
                ReportDocument.objects
                .filter(user=user, report__additional_transcripts__in=transcripts_for_deals)
                .annotate(related_client_id=F('report__additional_transcripts__client_id'))
                .values('related_client_id')
                .annotate(
                    total=Count('id'),
                    completed=Count('id', filter=Q(report__status='completed'))
                )
            )

            # --- Merge counts safely ---
            report_counts = list(report_counts_main)
            for item in report_counts_additional:
                existing = next((x for x in report_counts if x['related_client_id'] == item['related_client_id']), None)
                if existing:
                    existing['total'] += item['total']
                    existing['completed'] += item['completed']
                else:
                    report_counts.append(item)

            counts_dict = {
                item['related_client_id']: {'total': item['total'], 'completed': item['completed']}
                for item in report_counts
            }

            # --- Separate completed vs in-progress deals ---
            completed_deals = []
            in_progress_deals = []
            for deal in recent_deals:
                counts = counts_dict.get(deal.id, {'total': 0, 'completed': 0})
                deal.total_reports_count = counts['total']
                deal.completed_reports_count = counts['completed']
                deal.humanize_company_size = humanize_big_number(deal.company_size)

                if counts['total'] > 0 and counts['completed'] == counts['total']:
                    completed_deals.append(deal)
                else:
                    in_progress_deals.append(deal)

            # --- Update context ---
            context.update({
                'all_documents': all_documents,
                'all_time_saved': all_time_saved,
                'pipeline_value': humanize_big_number(all_month_pipeline),
                'pipeline_change': pipeline_change,
                'time_saved': month_time_saved,
                'time_saved_diff': time_saved_diff,
                'active_deals': len(recent_deals),
                'deals_diff': deals_diff,
                'recent_deals': recent_deals,
                'completed_deals': completed_deals,
                'in_progress_deals': in_progress_deals,
                # added missing keys for your template
                'documents_generated': month_docs_generated,
                'docs_diff': week_docs_diff,
            })

        except Exception as e:
            logger.exception("DashboardView context_data error: %s", e)
            context.update({
                'all_documents': [],
                'all_time_saved': 0,
                'pipeline_value': "0",
                'pipeline_change': 0,
                'time_saved': 0,
                'time_saved_diff': 0,
                'active_deals': 0,
                'deals_diff': 0,
                'recent_deals': [],
                'completed_deals': [],
                'in_progress_deals': [],
                'documents_generated': 0,
                'docs_diff': 0,
            })

        return context

from django.shortcuts import render

from django.utils.dateformat import format
import json


class UpdateProfileView(LoginRequiredMixin, TemplateView):
    template_name = "core/profile.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["is_zoom_connected"] = ZoomCredential.objects.filter(user=self.request.user).exists()
        context['is_salesforce_connected'] = SalesforceCredential.objects.filter(user=self.request.user).exists()
        context["is_google_drive_connected"] = GoogleDriveCredential.objects.filter(user=self.request.user).exists()
        context['password_form'] = PasswordChangeForm(user=self.request.user)
        return context

    def post(self, request, *args, **kwargs):
        if 'update_profile' in request.POST:
            return self.handle_profile_update(request)
        elif 'change_password' in request.POST:
            return self.handle_password_change(request)
        return super().get(request, *args, **kwargs)

    def handle_profile_update(self, request):
        user = request.user
        try:
            # Update basic fields
            user.first_name = request.POST.get('first_name', '')
            user.last_name = request.POST.get('last_name', '')
            user.email = request.POST.get('email', '')

            if 'profile_picture' in request.FILES:
                user.profile_picture = request.FILES['profile_picture']

            user.full_clean()
            user.save()
            messages.success(request, 'Profile updated successfully!')
        except ValidationError as e:
            for field, errors in e.message_dict.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
        except Exception as e:
            messages.error(request, f"Error updating profile: {str(e)}")

        return redirect('profile')

    def handle_password_change(self, request):
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
        return redirect('profile')
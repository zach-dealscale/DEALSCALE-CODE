from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

class EmailService:
    """Service for sending templated emails"""
    
    @staticmethod
    def send_templated_email(
        template_name: str,
        recipient_emails: List[str],
        context: Dict,
        subject: str,
        from_email: Optional[str] = None
    ) -> bool:
        """
        Send HTML email using Django templates
        
        Args:
            template_name: Name of template (e.g., 'auth/password_reset')
            recipient_emails: List of recipient email addresses
            context: Template context variables
            subject: Email subject
            from_email: Sender email (defaults to DEFAULT_FROM_EMAIL)
        
        Returns:
            Boolean indicating success
        """
        try:
            from_email = from_email or settings.DEFAULT_FROM_EMAIL
            site_name = settings.SITE_NAME
            site_url = settings.SITE_FRONTEND_URL
            
            # Add common context variables
            context.update({
                'site_name': site_name,
                'site_url': site_url,
                'subject': subject,
            })
            
            # Render HTML template
            html_template = f'email/{template_name}.html'
            html_content = render_to_string(html_template, context)
            
            # Render text template (fallback)
            text_template = f'email/{template_name}.txt'
            try:
                text_content = render_to_string(text_template, context)
            except:
                # If no text template exists, create a simple fallback
                text_content = f"{subject}\n\nPlease view this email in HTML format."
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=from_email,
                to=recipient_emails
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Email sent successfully to {recipient_emails}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email to {recipient_emails}: {e}", exc_info=True)
            return False
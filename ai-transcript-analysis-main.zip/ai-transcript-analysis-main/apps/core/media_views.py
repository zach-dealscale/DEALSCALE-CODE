# views.py
from django.http import FileResponse, Http404
from django.views import View
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.views.decorators.clickjacking import xframe_options_exempt

from apps.core.utils import GuestOrLoginRequiredMixin
from apps.sale_rooms.models import SalesRoomMedia
from django.shortcuts import render
from django.template.loader import render_to_string

def convert_markdown_to_html(markdown_text):
    """
    Convert markdown text to HTML using the markdown library.
    Includes table support for your content calendar.
    """
    import markdown
    from markdown.extensions import tables

    cleaned_markdown_text = markdown_text.strip('"')

    # Create markdown instance with table extension
    md = markdown.Markdown(extensions=['tables', 'fenced_code'])
    
    # Convert to HTML
    html_content = md.convert(cleaned_markdown_text)
    
    return html_content

from django.utils.safestring import mark_safe
from django.http import HttpResponse
from xhtml2pdf import pisa
from django.http import HttpResponse
from django.template.loader import render_to_string


def test_download(request, context):
    template_path = 'test.html'
    html_content = render_to_string(template_path, context, request=request)
    
    # Create PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="report.pdf"'
    
    pisa_status = pisa.CreatePDF(html_content, dest=response)
    
    if pisa_status.err:
        return HttpResponse('Error generating PDF')
    
    return response

@method_decorator(xframe_options_exempt, name='dispatch')
class ServeMediaView(View, GuestOrLoginRequiredMixin):
    """
    Class-based view to serve media files by their ID with appropriate content type
    """
    
    def get(self, request, media_id):
        # Get the media object or return 404
        media = get_object_or_404(SalesRoomMedia, id=media_id)
        
        # Security check: Verify that user has access to this Deal Room
        # Uncomment and adapt based on your permission structure
        # if not (request.user.is_authenticated and (
        #         request.user == media.uploaded_by_user or 
        #         request.user.has_access_to_salesroom(media.sales_room))):
        #     raise PermissionDenied("You don't have permission to access this file")
        
        # Track file view (optional)
        self.log_file_access(request, media)
        
        # Open the file
        try:
            file_handle = media.file.open('rb')
        except FileNotFoundError:
            raise Http404("File not found on storage")
        
        # Create response with appropriate content type
        content_type = self.get_content_type(media.file_type)
        response = FileResponse(file_handle, content_type=content_type)
        
        # Set content disposition based on file type
        disposition = self.get_disposition(media.file_type)
        response['Content-Disposition'] = f'{disposition}; filename="{media.file_name}"'
        
        # Add security headers
        response['X-Content-Type-Options'] = 'nosniff'  # Prevents MIME-sniffing
        
        # Cache control
        self.set_cache_headers(response)
        
        return response
    
    def log_file_access(self, request, media):
        """Log file access (optional)"""
        # Uncomment if you want to track file views
        # if hasattr(request, 'user') and request.user.is_authenticated:
        #     FileViewLog.objects.create(
        #         media=media,
        #         user=request.user,
        #         ip_address=self.get_client_ip(request)
        #     )
        pass
    
    def get_content_type(self, file_type):
        """Return appropriate content type based on file extension"""
        content_types = {
            # Documents
            'pdf': 'application/pdf',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'txt': 'text/plain',
            
            # Images
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'svg': 'image/svg+xml',
            'webp': 'image/webp',
            
            # Videos
            'mp4': 'video/mp4',
            'mov': 'video/quicktime',
            'avi': 'video/x-msvideo',
            'webm': 'video/webm',
            
            # Audio
            'mp3': 'audio/mpeg',
            'wav': 'audio/wav',
            'ogg': 'audio/ogg',
            
            # Archives
            'zip': 'application/zip',
            'rar': 'application/x-rar-compressed',
            'tar': 'application/x-tar',
            '7z': 'application/x-7z-compressed',
        }
        
        return content_types.get(file_type.lower(), 'application/octet-stream')  # Default to binary
    
    def get_disposition(self, file_type):
        """
        Determine if file should be displayed inline or as attachment
        """
        # File types that can typically be displayed by most browsers
        inline_types = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'mp4', 'webm', 'mp3', 'txt']
        
        if file_type.lower() in inline_types:
            return 'inline'
        else:
            return 'attachment'  # Will prompt user to download
    
    def set_cache_headers(self, response):
        """Set appropriate cache headers based on environment"""
        from django.conf import settings
        
        if settings.DEBUG:
            response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        else:
            # In production, allow caching for most media (adjust as needed)
            response['Cache-Control'] = 'public, max-age=86400'  # Cache for 1 day
    
    def get_client_ip(self, request):
        """Helper method to get client IP (for logging)"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip
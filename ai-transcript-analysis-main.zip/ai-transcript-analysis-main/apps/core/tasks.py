import logging
import json
import requests
from celery import shared_task
from django.conf import settings
from django.utils import timezone
from django.urls import reverse
from apps.core.services.email_service import EmailService
from apps.authentication.models import Client, Invitation


logger = logging.getLogger(__name__)



@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_user_invitation_email_task(self, invitation_id: str):
    """
    Celery task to send user invitation email.
    Retries up to 3 times with a delay of 60 seconds on failure.
    """
    try:
        invitation = Invitation.objects.get(id=invitation_id)

        # Generate acceptance URL
        # Note: Adjust the route name and domain based on your setup
        acceptance_url = f"{settings.SITE_FRONTEND_URL}/auth/accept-invitation/{invitation.token}/"

        context = {
            "user_first_name": invitation.user.first_name or invitation.user.email.split('@')[0],
            "company_name": invitation.company.name,
            "invited_by_name": invitation.invited_by.get_full_name() if invitation.invited_by else "An administrator",
            "acceptance_url": acceptance_url,
        }

        success = EmailService.send_templated_email(
            template_name="user_invitation",
            recipient_emails=[invitation.user.email],
            context=context,
            subject=f"You're invited to join {invitation.company.name}!"
        )

        if success:
            logger.info(f"Invitation email sent to {invitation.user.email} for {invitation.company.name}")
        else:
            logger.error(f"Failed to send invitation email to {invitation.user.email}")
            # Retry on failure
            raise self.retry(exc=Exception("Email send failed"))

    except Invitation.DoesNotExist:
        logger.error(f"Invitation with ID {invitation_id} does not exist")
    except Exception as exc:
        logger.error(f"Failed to send invitation email for invitation {invitation_id}: {exc}", exc_info=True)
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_password_reset_email_task(self, recipient_email: str, code: str, user_first_name: str = ""):
    """
    Celery task to send password reset email to the user.
    Retries up to 3 times with a delay of 60 seconds on failure.
    """
    try:
        context = {
            "user": {"first_name": user_first_name},
            "code": code,
            "expiry_minutes": 10,
        }
        success = EmailService.send_templated_email(
            template_name="password_reset",
            recipient_emails=[recipient_email],
            context=context,
            subject="Your Password Reset Code"
        )
        if success:
            logger.info(f"Password reset email sent to {recipient_email}")
        else:
            logger.error(f"Failed to send password reset email to {recipient_email}")
    except Exception as exc:
        logger.error(f"Failed to send password reset email to {recipient_email}: {exc}", exc_info=True)
        raise self.retry(exc=exc)




@shared_task
def fetch_and_update_company_details(client_id):
    """
    Celery task that fetches LinkedIn company data via Apify
    and updates the given Client instance in the database.
    """
    from django.db import transaction
    import requests
    from django.core.files.base import ContentFile
    import os

    try:
        client = Client.objects.get(id=client_id)
        company_name = client.name
        print(f"🚀 Fetching LinkedIn data for: {company_name}")

        apify_token = settings.APIFY_API_TOKEN
        actor_id = "harvestapi~linkedin-company"
        api_url = f"https://api.apify.com/v2/acts/{actor_id}/run-sync-get-dataset-items?token={apify_token}"

        payload = {"companies": [company_name]}

        response = requests.post(api_url, json=payload, timeout=300)
        print(f"✅ Response Status: {response.status_code}")

        if response.status_code not in [200, 201]:
            print(f"❌ Failed to fetch data: {response.text}")
            return

        data = response.json()
        if not data or not isinstance(data, list):
            print("❌ Invalid or empty response.")
            return

        company_data = data[0]
        print("📊 Raw company data received:")

        # ✅ Safely update the Client record with correct field mapping
        with transaction.atomic():
            update_fields = []

            # Map the correct fields from the API response
            if company_data.get("website") and company_data.get("website") != client.website:
                client.website = company_data.get("website")
                update_fields.append("website")

            # Handle industry - it's an array of objects in the response
            industries = company_data.get("industries", [])
            if industries:
                industry_name = industries[0].get("name", "")
                if industry_name and industry_name != client.industry:
                    client.industry = industry_name
                    update_fields.append("industry")

            # Handle company size - use employeeCount from the response
            employee_count = company_data.get("employeeCount")
            if employee_count and employee_count != client.company_size:
                client.company_size = employee_count
                update_fields.append("company_size")

            # Handle description/notes
            description = company_data.get("description")
            if description and description != client.notes:
                client.notes = description
                update_fields.append("notes")

            # Handle company logo - download and save if available
            logo_url = company_data.get("logo")
            if logo_url and not client.company_logo:
                try:
                    print(f"📸 Downloading company logo from: {logo_url}")
                    logo_response = requests.get(logo_url, timeout=30)
                    if logo_response.status_code == 200:
                        # Get file extension from URL
                        file_extension = os.path.splitext(logo_url.split('?')[0])[1] or '.jpg'
                        filename = f"{client.name.replace(' ', '_')}_logo{file_extension}"

                        # Save the logo to the ImageField
                        client.company_logo.save(
                            filename,
                            ContentFile(logo_response.content),
                            save=False
                        )
                        update_fields.append("company_logo")
                        print("✅ Company logo downloaded and saved")
                    else:
                        print(f"⚠️ Failed to download logo: HTTP {logo_response.status_code}")
                except Exception as e:
                    print(f"⚠️ Error downloading company logo: {str(e)}")

            # Save only if there are fields to update
            if update_fields:
                client.save(update_fields=update_fields)
                print(f"✅ Successfully updated client '{client.name}' with LinkedIn data.")
                print(f"   - Website: {client.website}")
                print(f"   - Industry: {client.industry}")
                print(f"   - Company Size: {client.company_size}")
                print(f"   - Logo updated: {'company_logo' in update_fields}")
                print(f"   - Notes updated: {'notes' in update_fields}")
            else:
                print(f"ℹ️ No new data to update for client '{client.name}'")

    except Client.DoesNotExist:
        print(f"⚠️ Client with ID {client_id} does not exist.")
    except Exception as e:
        print(f"⚠️ Error updating LinkedIn data for client {client_id}: {str(e)}")
        import traceback
        print(f"📋 Full traceback: {traceback.format_exc()}")
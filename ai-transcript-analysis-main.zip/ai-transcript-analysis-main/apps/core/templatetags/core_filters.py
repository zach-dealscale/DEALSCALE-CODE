from django import template
from apps.report_management.helpers.report_choices import Stage

register = template.Library()

@register.filter
def humanize_big_number(value):
    try:
        num = float(value)
    except (ValueError, TypeError):
        return value

    if num >= 1_000_000_000:
        return f"{round(num/1_000_000_000)}B"
    elif num >= 1_000_000:
        return f"{round(num/1_000_000)}M"
    elif num >= 1_000:
        return f"{round(num/1_000)}K"
    else:
        return str(int(num))

@register.filter
def get_stage_display(value):
    """Convert stage value to human-readable display name.

    Uses centralized Stage class as single source of truth.
    """
    return Stage.get_stage_label(value) if value else 'Unknown'

@register.filter
def get_stage_badge_class(value):
    """Get the badge CSS class for a stage value."""
    return Stage.get_badge_class(value) if value else 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'

@register.filter
def get_stage_dot_class(value):
    """Get the dot CSS class for a stage value."""
    return Stage.get_dot_class(value) if value else 'bg-gray-600'
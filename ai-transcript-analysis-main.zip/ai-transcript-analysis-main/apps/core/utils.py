import json
from io import BytesIO

import requests
from django import template
from django.core.files.uploadedfile import InMemoryUploadedFile
from docx import Document
from django.utils import timezone

from apps.authentication.models import GuestUserSessionKey
from apps.report_management.helpers.file_to_text import FileToTextConverter

import io
import os
import tempfile
import subprocess
from pdf2image import convert_from_bytes
from django.core.files.storage import default_storage
from django.utils.timezone import now
from django.shortcuts import redirect

class GuestOrLoginRequiredMixin:
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return super().dispatch(request, *args, **kwargs)

        # Else, check for guest session
        session_key = request.session.get('session_key')
        if not session_key:
            return redirect('guest_room_login', uuid=kwargs.get('uuid'))

        try:
            guest_session = GuestUserSessionKey.objects.select_related('guest_user').get(
                session_key=session_key,
                expires_at__gt=now()
            )
            request.guest_user = guest_session.guest_user
        except GuestUserSessionKey.DoesNotExist:
            return redirect('guest_room_login', uuid=kwargs.get('uuid'))

        return super().dispatch(request, *args, **kwargs)

def merge_files(file_list):
    """Merge multiple files (TXT, DOCX, PDF, RTF) into one DOCX file"""
    merged_doc = Document()
    counter = 1  # transcript counter

    for file in file_list:
        file.seek(0)
        file_extension = file.name.split('.')[-1].lower()
        merged_doc.add_paragraph(f"========= Transcript {counter} - START ============")

        try:
            if file_extension == 'docx':
                # Handle DOCX files - read paragraphs and add them properly
                doc = Document(file)
                for paragraph in doc.paragraphs:
                    if paragraph.text.strip():  # Only add non-empty paragraphs
                        merged_doc.add_paragraph(paragraph.text)
                
                # Also handle tables if they exist
                for table in doc.tables:
                    new_table = merged_doc.add_table(rows=len(table.rows), cols=len(table.columns))
                    for i, row in enumerate(table.rows):
                        for j, cell in enumerate(row.cells):
                            new_table.cell(i, j).text = cell.text

            else:
                # Handle TXT, PDF, RTF by converting to text first
                converter = FileToTextConverter(file)
                text = converter.convert()
                
                if text and text.strip():  # Only add if there's actual content
                    merged_doc.add_paragraph(text)

            merged_doc.add_paragraph(f"========= Transcript {counter} - END ============")
            counter += 1
            merged_doc.add_page_break()

        except Exception as e:
            merged_doc.add_paragraph(f"Error processing file {file.name}: {str(e)}")
            merged_doc.add_page_break()
            continue

    # Save the merged document to in-memory file
    buffer = BytesIO()
    merged_doc.save(buffer)
    buffer.seek(0)

    return InMemoryUploadedFile(
        file=buffer,
        field_name=None,
        name=f"merged_transcript_{timezone.now().timestamp()}.docx",
        content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        size=buffer.tell(),
        charset=None
    )



class ThumbnailService:
    @staticmethod
    def generate_thumbnail(file_field, file_ext):
        thumb_name = f"thumbnails/{file_field.name}.thumb.jpg"
        if default_storage.exists(thumb_name):
            return default_storage.url(thumb_name)

        try:
            if file_ext in ['jpg', 'jpeg', 'png', 'gif', 'webp']:
                return file_field.url

            elif file_ext == 'pdf':
                with file_field.open('rb') as f:
                    pdf_data = f.read()
                images = convert_from_bytes(pdf_data, first_page=1, last_page=1)
                if images:
                    thumb_io = io.BytesIO()
                    images[0].save(thumb_io, format='JPEG', quality=85)
                    default_storage.save(thumb_name, thumb_io)
                    return default_storage.url(thumb_name)

            elif file_ext in ['docx', 'xlsx', 'pptx', 'doc', 'xls', 'ppt']:
                return ThumbnailService.generate_office_thumbnail_linux(file_field, file_ext, thumb_name)

        except Exception as e:
            print(f"Error generating thumbnail: {e}")

        return {
            'docx': '/static/images/doc-thumbnail.jpg',
            'xlsx': '/static/images/excel-thumbnail.jpg',
            'pptx': '/static/images/ppt-thumbnail.jpg',
            'pdf': '/static/images/pdf-thumbnail.jpg',
        }.get(file_ext, '/static/images/default-thumbnail.jpg')

    @staticmethod
    def generate_office_thumbnail_linux(file_field, file_ext, thumb_name):
        try:
            with tempfile.NamedTemporaryFile(suffix=f".{file_ext}") as tmp:
                for chunk in file_field.chunks():
                    tmp.write(chunk)
                tmp.flush()

                with tempfile.TemporaryDirectory() as temp_dir:
                    subprocess.run([
                        'libreoffice', '--headless', '--convert-to', 'pdf',
                        '--outdir', temp_dir,
                        tmp.name
                    ], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                    pdf_path = os.path.join(temp_dir, os.path.basename(tmp.name).replace(file_ext, 'pdf'))

                    if os.path.exists(pdf_path):
                        with open(pdf_path, 'rb') as pdf_file:
                            images = convert_from_bytes(pdf_file.read(), first_page=1, last_page=1)

                        if images:
                            thumb_io = io.BytesIO()
                            images[0].save(thumb_io, format='JPEG', quality=85)
                            default_storage.save(thumb_name, thumb_io)
                            return default_storage.url(thumb_name)

        except subprocess.CalledProcessError as e:
            print(f"LibreOffice conversion failed: {e.stderr.decode()}")
        except Exception as e:
            print(f"Error generating office thumbnail: {e}")

        return None


register = template.Library()

@register.filter
def humanize_big_number(value):
    try:
        num = float(value)
    except (ValueError, TypeError):
        return value

    if num >= 1_000_000_000:
        return f"{num / 1_000_000_000:.1f}B".rstrip('0').rstrip('.')
    elif num >= 1_000_000:
        return f"{num / 1_000_000:.1f}M".rstrip('0').rstrip('.')
    elif num >= 1_000:
        return f"{num / 1_000:.1f}K".rstrip('0').rstrip('.')
    else:
        return str(int(num))



def _calculate_percentage_change(old_value, new_value):
    """Helper method to calculate percentage change between two values"""
    if old_value == 0:
        return 100 if new_value > 0 else 0
    percentage = ((new_value - old_value) / old_value) * 100
    return max(round(percentage), 0)  # Show 0 if negative

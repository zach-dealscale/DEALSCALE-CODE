"""
Role-Based Access Control Mixins for Core App

Provides mixins for enforcing role-based access to clients/deals based on:
1. User's role and its can_view_all_data permission
2. User's position in hierarchy (manager/subordinates)
3. Company-level scoping
"""

from django.db.models import Q
from django.http import Http404
from django.contrib import messages
from django.shortcuts import redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from apps.authentication.models import Client


class RoleBasedClientAccessMixin:
    """
    Filters clients/deals based on user's role and hierarchy.

    Access Rules:
    - Owner/Admin (can_view_all_data=True): Sees ALL clients in company
    - Manager (has subordinates): Sees own clients + subordinates' clients
    - Sales Rep: Sees only own clients

    This mixin is reusable across all views that need deal filtering.
    """

    def get_accessible_clients(self, user):
        """
        Return queryset of clients this user can access.

        Args:
            user: CustomUser instance

        Returns:
            QuerySet of Client objects user can access
        """
        company = user.company
        if not company:
            return Client.objects.none()

        # ADMIN: Can see all clients in company
        if user.role and user.role.can_view_all_data:
            return Client.objects.filter(company=company)

        # REGULAR USER: Can see own + subordinates' clients
        subordinate_ids = user.get_subordinate_ids(use_cache=True)

        # Clients where user or subordinates are primary_owner OR created_by
        accessible = Client.objects.filter(
            company=company
        ).filter(
            Q(primary_owner_id__in=subordinate_ids) |
            Q(created_by_id__in=subordinate_ids)
        )

        return accessible

    def get_queryset(self):
        """
        Override get_queryset for list views.
        Automatically filters to accessible clients only.
        """
        user = self.request.user
        if not user.is_authenticated or not user.company:
            return Client.objects.none()

        accessible_clients = self.get_accessible_clients(user)
        return accessible_clients

    def get_object(self, queryset=None):
        """
        Override get_object for detail views.
        Verifies user has access before returning the object.
        """
        user = self.request.user

        # Get the object using parent class logic
        obj = super().get_object(queryset)

        # Verify user can access this specific client
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=obj.pk).exists():
            messages.error(self.request, "You don't have access to this deal.")
            raise Http404("Deal not found or access denied.")

        return obj


class CompanyManagementAccessMixin(LoginRequiredMixin):
    """
    Protects /auth/company/* pages - only accessible to users with admin access.

    Usage:
        class CompanyUserListView(CompanyManagementAccessMixin, ListView):
            ...

    If user doesn't have admin access, redirects to home with error message.
    """

    def dispatch(self, request, *args, **kwargs):
        """Check permission before processing request."""
        user = request.user

        # Must be authenticated and have company
        if not user.is_authenticated or not user.company:
            messages.error(request, "You must be part of a company to access this.")
            return redirect('home')

        # Must have admin access (can_view_all_data = True)
        if not (user.role and user.role.can_view_all_data):
            messages.error(request, "Admin access required. Only administrators can manage company settings.")
            return redirect('home')

        # Continue with normal view processing
        return super().dispatch(request, *args, **kwargs)


class RoleBasedTranscriptAccessMixin:
    """
    Filters transcripts/reports based on user's role and hierarchy.

    Access Rules:
    - Owner/Admin: Sees ALL transcripts in company
    - Manager: Sees own transcripts + subordinates' transcripts
    - Sales Rep: Sees only own transcripts

    Used for report generation, transcript management, etc.
    """

    def get_accessible_transcripts(self, user):
        """Return queryset of transcripts user can access."""
        from apps.report_management.models import Transcript

        company = user.company
        if not company:
            return Transcript.objects.none()

        # ADMIN: Can see all transcripts
        if user.role and user.role.can_view_all_data:
            return Transcript.objects.filter(company=company)

        # REGULAR: Can see own + subordinates' transcripts
        subordinate_ids = user.get_subordinate_ids(use_cache=True)
        return Transcript.objects.filter(
            company=company
        ).filter(
            Q(uploaded_by_id__in=subordinate_ids) |
            Q(user_id__in=subordinate_ids)
        )

    def get_queryset(self):
        """Override for list views."""
        from apps.report_management.models import Transcript

        user = self.request.user
        if not user.is_authenticated or not user.company:
            return Transcript.objects.none()

        return self.get_accessible_transcripts(user)


class TeamDashboardMixin:
    """
    Adds team performance data to context for managers.

    Automatically calculates:
    - Team size
    - Total deals
    - Team member list
    - Performance stats

    Used in dashboard views for managers to see team metrics.
    """

    def get_context_data(self, **kwargs):
        """Add team stats to context if user is a manager."""
        context = super().get_context_data(**kwargs)
        user = self.request.user

        # Only show team dashboard if user has subordinates
        if user.subordinates.exists():
            subordinate_ids = user.get_subordinate_ids()

            context['is_manager'] = True
            context['team_stats'] = {
                'team_size': user.subordinates.count(),
                'total_deals': Client.objects.filter(
                    company=user.company,
                    primary_owner_id__in=subordinate_ids
                ).count(),
                'team_members': user.subordinates.filter(
                    is_active_in_company=True
                ).order_by('first_name'),
            }
        else:
            context['is_manager'] = False
            context['team_stats'] = None

        return context


class FeatureAccessMixin(LoginRequiredMixin):
    """
    Protects pages that require specific feature permissions.

    Use this mixin to restrict access to /forecast or /analytics pages
    based on user role permissions.

    Usage:
        class ForecastView(FeatureAccessMixin, View):
            required_permission = 'can_view_forecast'
            ...

        class AnalyticsView(FeatureAccessMixin, View):
            required_permission = 'can_view_analytics'
            ...

    Access Rules:
    - User must be authenticated
    - User must have a company assigned
    - User's role must have the required permission enabled

    If access is denied, redirects to home with error message.
    """

    required_permission = None  # Override in subclass with permission name

    def dispatch(self, request, *args, **kwargs):
        """Check permission before processing request."""
        user = request.user

        # Must be authenticated and have company
        if not user.is_authenticated or not user.company:
            messages.error(request, "You must be part of a company to access this feature.")
            return redirect('home')

        # Must have role with required permission
        if not self.required_permission:
            messages.error(request, "Feature permission not configured.")
            return redirect('home')

        # Check if user's role has the required permission
        if user.role and hasattr(user.role, self.required_permission):
            if getattr(user.role, self.required_permission):
                # Permission granted, continue
                return super().dispatch(request, *args, **kwargs)

        # Permission denied
        permission_display = self.required_permission.replace('can_view_', '').replace('_', ' ').title()
        messages.error(request, f"Your role does not have access to the {permission_display} feature.")
        return redirect('home')


# Specific permission mixins for convenience
class ForecastAccessMixin(FeatureAccessMixin):
    """Mixin for views requiring can_view_forecast permission."""
    required_permission = 'can_view_forecast'


class AnalyticsAccessMixin(FeatureAccessMixin):
    """Mixin for views requiring can_view_analytics permission."""
    required_permission = 'can_view_analytics'

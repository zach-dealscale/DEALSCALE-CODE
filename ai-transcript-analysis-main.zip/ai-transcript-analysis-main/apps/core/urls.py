from django.urls import path
from . import views
from .media_views import ServeMediaView
from .deal_views import DealListView, DealDetailView, DealCreateView, DealUpdateView, DealDeleteView, \
    UpdateDealStageView

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('health', views.health_check, name='health_check'),
    path('media/<int:media_id>/', ServeMediaView.as_view(), name='serve_media'),
    path('profile/', views.UpdateProfileView.as_view(), name='profile'),

    # deals must be global (Later we will create a deals app)
    path('deals/', DealListView.as_view(), name='deal_list'),
    path('deals/<int:pk>/', DealDetailView.as_view(), name='deal_detail'),
    path('deals/create/', DealCreateView.as_view(), name='deal_create'),
    path('deals/<int:pk>/update/', DealUpdateView.as_view(), name='deal_update'),
    path('deals/<int:pk>/delete/', DealDeleteView.as_view(), name='deal_delete'),
    path('api/deals/<int:deal_id>/update-stage/', UpdateDealStageView.as_view(), name='update_deal_stage'),
]



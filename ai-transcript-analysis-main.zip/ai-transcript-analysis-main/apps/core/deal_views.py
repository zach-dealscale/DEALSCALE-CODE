from collections import defaultdict
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
import json
from django.core.files.base import ContentFile
from django.core.serializers import serialize
from django.utils import timezone
from django.views.generic import TemplateView
from django.contrib.auth import get_user_model
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render
from django.db.models import Q
import json

from .utils import merge_files
from ..report_management.helpers.report_choices import Stage
from .mixins import RoleBasedClientAccessMixin, TeamDashboardMixin

User = get_user_model()  # Dynamically get the user model
from .tasks import fetch_and_update_company_details
from django.urls.base import reverse_lazy, reverse
from django.http import HttpResponseRedirect

from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect, get_object_or_404, render
from django.http import Http404

from django.views.generic.edit import DeleteView, UpdateView, CreateView
from django.contrib import messages
from django.views.generic import ListView
import logging


from apps.report_management.forms import ReportCreateForm, ClientContactForm, ClientCreateForm
from apps.authentication.forms import ClientUpdateForm
from apps.authentication.models import Client
from apps.report_management.models import Transcript, ReportFormation, ReportDocument, Category, ReportTemplate
from apps.sale_rooms.models import SalesRoom, ClientContact

logger = logging.getLogger(__name__)



class DealUpdateView(LoginRequiredMixin, RoleBasedClientAccessMixin, UpdateView):
    model = Client
    form_class = ClientUpdateForm
    template_name = 'client_update.html'
    context_object_name = 'client'

    def get_success_url(self):
        messages.success(self.request, 'Deal has been updated.')
        return reverse_lazy('deal_detail', kwargs={'pk': self.object.pk})

    def get_object(self, queryset=None):
        """Get object with role-based access check via mixin."""
        pk = self.kwargs.get("pk")
        obj = get_object_or_404(Client, id=pk)

        # Verify user has access to this client
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=obj.pk).exists():
            messages.error(self.request, "You don't have permission to edit this deal.")
            raise Http404("Deal not found or access denied.")

        return obj

    def form_valid(self, form):
        response = super().form_valid(form)

        company_name = form.cleaned_data.get('name', '')
        name_parts = company_name.split()

        contact_data = {
            'first_name': name_parts[0] if len(name_parts) > 0 else '',
            'last_name': ' '.join(name_parts[1:]) if len(name_parts) > 1 else '',
            'email': form.cleaned_data.get('company_email'),
            'phone': '',
        }
        if contact_data['first_name'] or contact_data['email']:
            ClientContact.objects.update_or_create(
                client=self.object,
                defaults=contact_data
            )

        related_documents = ReportDocument.objects.filter(
            Q(report__transcript__client=self.object) |
            Q(report__additional_transcripts__client=self.object)  |
            Q(client=self.object)
        ).distinct()

        updated_documents = []
        for doc in related_documents:
            template_title = getattr(doc.report.template, 'title', None)
            if template_title:
                doc.title = f"{template_title} - {self.object.name}"
                updated_documents.append(doc)

        if updated_documents:
            ReportDocument.objects.bulk_update(updated_documents, ['title'])

        return response


class DealContactCreateView(LoginRequiredMixin, CreateView):
    model = ClientContact
    form_class = ClientContactForm
    template_name = 'client_contact_form.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, f"Contact {self.object} created successfully")
        return response

    def get_success_url(self):
        sales_room = SalesRoom.objects.filter(client=self.object.client).first()
        if sales_room:
            return reverse_lazy("sales_room_detail", kwargs={'uuid': sales_room.uuid})
        return reverse_lazy("sales_room_list")


class DealDetailView(LoginRequiredMixin, RoleBasedClientAccessMixin, TemplateView):
    template_name = "client/company_detail.html"

    def get_transcripts(self):
        self.client = get_object_or_404(Client, pk=self.kwargs['pk'])

        # Verify user has access to this client
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=self.client.pk).exists():
            messages.error(self.request, "You don't have access to this deal.")
            raise Http404("Deal not found or access denied.")

        return Transcript.objects.filter(client=self.client).order_by('-created_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Deal data
        transcripts = self.get_transcripts().prefetch_related('transcript_media_files')
        context['client'] = self.client
        context['transcripts'] = transcripts
        context['reports'] = ReportFormation.objects.filter(transcript__client=self.client)
        context['statistics'] = self.get_statistics(transcripts)
        context['documents'] = ReportDocument.objects.filter(
            report__transcript__client=self.client
        ).select_related('report', 'sales_room').order_by('-created_at')

        # Add stages data for stage progression component
        context['stages_json'] = json.dumps(Stage.get_all_stages())

        # Shared report builder logic (same as ReportCreateView)
        transcript_id = self.request.GET.get("transcript")
        selected_transcript = Transcript.objects.filter(id=transcript_id).first()
        selected_transcript_json = None
        if selected_transcript:
            selected_transcript_json = {
                'id': selected_transcript.id,
                'title': selected_transcript.title,
                'platform': selected_transcript.platform,
                'created_at': selected_transcript.created_at.strftime('%B %d, %Y'),
                'client_name': selected_transcript.client.name if selected_transcript.client else '',
                'client_logo': selected_transcript.client.company_logo.url if selected_transcript.client and selected_transcript.client.company_logo else None,
                'transcript_media_files': [
                    {
                        'original_filename': m.original_filename,
                        'url': m.original_file.url
                    }
                    for m in selected_transcript.transcript_media_files.all()
                ]
            }

        # Template grouping
        templates_by_category = defaultdict(lambda: defaultdict(list))
        categories = Category.objects.prefetch_related(
            'subcategory_set',
            'subcategory_set__reporttemplate_set'
        ).all()

        for category in categories:
            for subcategory in category.subcategory_set.all():
                for template in subcategory.reporttemplate_set.all():
                    templates_by_category[category.name][subcategory.name].append(template)

        first_category = categories[0].name if categories else ''
        pinned_reports = ReportTemplate.objects.filter(
            pinned_by_users__user=self.request.user
        ).distinct()
        recent_reports = ReportTemplate.objects.filter(
            templates__user=self.request.user
        ).order_by('-last_used').distinct()[:2]
        pinned_reports_ids = [t.id for t in pinned_reports]

        context.update({
            "selected_transcript": json.dumps(selected_transcript_json),
            "templates_by_category": dict(templates_by_category),
            "first_category": first_category,
            "categories": categories,
            "pinned_reports": pinned_reports,
            "recent_reports": recent_reports,
            "pinned_reports_ids": pinned_reports_ids
        })

        return context

    def post(self, request, *args, **kwargs):
        from apps.ai_agents.tasks import generate_report_task
        self.client = get_object_or_404(Client, pk=self.kwargs['pk'])
        form = ReportCreateForm(request.POST, client=self.client)

        if form.is_valid():
            transcript_ids = request.POST.getlist("transcript_id")
            print("DEBUG transcript_ids:", transcript_ids)
            transcripts = Transcript.objects.filter(id__in=transcript_ids)
            templates = form.cleaned_data["templates"]
            created_reports = []

            for template in templates:
                # Determine if multiple transcripts were selected
                multiple_transcripts = transcripts.count() > 1
                main_transcript = transcripts.first() if transcripts.exists() else None

                existing_report = (
                    ReportFormation.objects.filter(
                        template=template,
                        user=request.user,
                    )
                    .filter(
                        transcript=main_transcript if not multiple_transcripts else None
                    )
                    .first()
                )

                if existing_report:
                    existing_report.status = "processing"

                    # Increment document version
                    old_document = ReportDocument.objects.filter(report=existing_report).first()
                    if old_document and old_document.version.startswith("v"):
                        try:
                            old_version_number = int(old_document.version.lstrip("v"))
                            new_version = f"v{old_version_number + 1}"
                        except ValueError:
                            new_version = "v2"
                    else:
                        new_version = "v1"

                    # Delete old documents and create new one
                    ReportDocument.objects.filter(report=existing_report).delete()

                    client_name = (
                        main_transcript.client.name if main_transcript and main_transcript.client else "Unknown Client"
                    )

                    new_document_title = f"{existing_report.template.title} - {client_name}"

                    ReportDocument.objects.create(
                        report=existing_report,
                        title=new_document_title,
                        version=new_version,
                        user=request.user,
                        created_by=request.user,
                    )

                    existing_report.save()
                    generate_report_task.delay(existing_report.id)
                    created_reports.append(existing_report)

                else:
                    # Create new report
                    report = ReportFormation.objects.create(
                        template=template,
                        user=request.user,
                        status="generating",
                        transcript=main_transcript if not multiple_transcripts else None,
                        company=request.user.company,
                        created_by=request.user,
                    )

                    # Assign additional transcripts
                    if multiple_transcripts:
                        report.additional_transcripts.set(transcripts)
                    elif main_transcript:
                        # Optional: also link it to additional if needed
                        report.additional_transcripts.clear()

                    # Document title
                    client_name = (
                        main_transcript.client.name if main_transcript and main_transcript.client else "Unknown Client"
                    )

                    new_document_title = f"{report.template.title} - {client_name}"

                    ReportDocument.objects.create(
                        report=report,
                        title=new_document_title,
                        version="v1",
                        user=request.user,
                        client=main_transcript.client if main_transcript else None,
                        created_by=request.user,
                    )
                    # Start async generation
                    generate_report_task.delay(report.id)
                    created_reports.append(report)

            if created_reports:
                messages.success(request, "Reports processed successfully.")
                first_report = created_reports[0]
                first_transcript = (
                        first_report.transcript
                        or first_report.additional_transcripts.first()
                )
                client_id = (
                    first_transcript.client.id
                    if first_transcript and first_transcript.client
                    else self.client.id
                )
                return redirect("deal_documents", client_id=client_id)

        context = self.get_context_data(form=form)
        return self.render_to_response(context)

    def get_statistics(self, transcripts):
        return {
            'total_transcripts': transcripts.count(),
            'recent_activity': transcripts.first().created_at if transcripts.exists() else None,
            'views': sum(t.views for t in transcripts if hasattr(t, 'views')),
        }


class DealCreateView(LoginRequiredMixin, CreateView):
    model = Client
    form_class = ClientCreateForm
    template_name = 'client/client_add_form.html'
    success_url = reverse_lazy('deal_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Create Deal'
        return context

    def form_valid(self, form):
        form.instance.user = self.request.user

        # ✅ Set company (multi-tenant scoping)
        form.instance.company = self.request.user.company

        # ✅ Set created_by (track who created this deal)
        form.instance.created_by = self.request.user

        company_name = form.cleaned_data.get('name', '').strip()
        name_parts = company_name.split()

        # Check if deal already exists for this company (not just this user)
        if Client.objects.filter(name__iexact=company_name, company=self.request.user.company).exists():
            messages.error(self.request, f"A deal named '{company_name}' already exists in your company.")
            return self.form_invalid(form)

        email = form.cleaned_data.get('company_email', '')
        if not email:
            slugified_name = company_name.lower().replace(" ", "")
            email = f"no-reply@{slugified_name}.com"

        form.instance.company_email = email

        # ✅ Set primary_owner to current user (owner of this deal)
        form.instance.primary_owner = self.request.user

        self.object = form.save()
        print(f"Saved deal '{self.object.name}' with email: {self.object.company_email}")

        try:
            if not ClientContact.objects.filter(email=email.strip().lower()).exists():
                contact = ClientContact.objects.create(
                    client=self.object,
                    first_name=name_parts[0] if len(name_parts) > 0 else '',
                    last_name=name_parts[1] if len(name_parts) > 1 else '',
                    email=email,
                    notes=form.cleaned_data.get('notes', ''),
                )
                print(f"Created contact with email: {contact.email}")
            messages.success(self.request, f"Deal '{self.object.name}' and contact created successfully")
            return HttpResponseRedirect(
                reverse("deal_detail", kwargs={"pk": self.object.id}) + "?show_transcript_modal=true"
            )
        except Exception as e:
            print("Error creating contact:", str(e))
            self.object.delete()
            messages.error(self.request, f"Error creating contact: {str(e)}")
            return self.form_invalid(form)


class DealListView(LoginRequiredMixin, RoleBasedClientAccessMixin, TeamDashboardMixin, ListView):
    model = Client
    template_name = "client/client_list.html"  # Updated template path
    context_object_name = 'clients'
    paginate_by = 10

    def get_queryset(self):
        """Get accessible clients based on role, then apply search filter."""
        # Use mixin to get role-based filtered queryset
        queryset = super().get_queryset()

        # Apply search filter if provided
        search_q = self.request.GET.get("q")
        if search_q:
            queryset = queryset.filter(name__icontains=search_q)

        return queryset

    def get_stages_data(self):
        """Return stages data in the format needed for the frontend.

        Uses centralized Stage class as single source of truth for all stage metadata.
        """
        return Stage.get_all_stages()

    def get_deals_json_data(self, queryset):
        """Convert queryset to JSON format for Alpine.js"""
        deals_json = serialize('json', queryset,
                               fields=('id', 'name', 'stage', 'industry', 'company_logo', 'created_at', 'website',
                                       'company_email','company_size'))
        deals_data = json.loads(deals_json)

        # Format the data for frontend
        formatted_deals = []
        for deal in deals_data:
            deal_data = deal['fields']
            deal_data['id'] = deal['pk']

            # Add company_logo URL if available
            client_obj = Client.objects.get(id=deal['pk'])
            if client_obj.company_logo:
                deal_data['company_logo'] = client_obj.company_logo.url
            else:
                deal_data['company_logo'] = None

            # Add created_by user information
            if client_obj.created_by:
                deal_data['created_by'] = {
                    'id': client_obj.created_by.id,
                    'name': client_obj.created_by.get_full_name() or client_obj.created_by.email,
                    'email': client_obj.created_by.email,
                    'profile_picture': client_obj.created_by.profile_picture.url if client_obj.created_by.profile_picture else None
                }
            else:
                deal_data['created_by'] = None

            formatted_deals.append(deal_data)

        return formatted_deals

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        paginator = Paginator(queryset, self.paginate_by)
        page_number = self.request.GET.get("page")

        try:
            page_obj = paginator.page(page_number)
        except PageNotAnInteger:
            page_obj = paginator.page(1)
        except EmptyPage:
            page_obj = paginator.page(paginator.num_pages)

        # Get stages data
        stages_data = self.get_stages_data()

        # Get deals JSON data for kanban view (all deals, not just current page)
        all_deals_json = self.get_deals_json_data(queryset)

        user = request.user
        context = {
            'page_obj': page_obj,
            'clients': page_obj.object_list,
            'stages_json': json.dumps(stages_data),
            'deals_json': json.dumps(all_deals_json),
            'current_filters': {
                'platform': self.request.GET.get('platform', ''),
                'date': self.request.GET.get('date', ''),
                'q': self.request.GET.get('q', ''),
                'page': page_obj.number,
            },
            # Add role-based context
            'user_role': user.role,
            'is_admin': user.role and user.role.can_view_all_data,
            'user_subordinates': user.subordinates.filter(is_active_in_company=True) if user.subordinates.exists() else None,
        }

        # Add team stats if user is a manager
        if user.subordinates.exists():
            context['team_stats'] = {
                'team_size': user.subordinates.count(),
                'total_deals': queryset.count(),
            }

        return render(request, self.template_name, context)


class DealDeleteView(LoginRequiredMixin, RoleBasedClientAccessMixin, DeleteView):
    model = Client
    template_name = 'client/confirm_delete.html'
    context_object_name = 'client'

    def get_object(self, queryset=None):
        """Get object with role-based access check via mixin."""
        pk = self.kwargs.get("pk")
        obj = get_object_or_404(Client, id=pk)

        # Verify user has access to this client
        user = self.request.user
        accessible_clients = self.get_accessible_clients(user)
        if not accessible_clients.filter(pk=obj.pk).exists():
            messages.error(self.request, "You don't have permission to delete this deal.")
            raise Http404("Deal not found or access denied.")

        return obj

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Delete Deal"
        context['page_subtitle'] = "Are you sure you want to delete this deal?"
        return context

    def get_success_url(self):
        messages.success(self.request, "Deal deleted successfully.")
        return reverse_lazy('deal_list')


@method_decorator(csrf_exempt, name='dispatch')
class UpdateDealStageView(LoginRequiredMixin, RoleBasedClientAccessMixin, View):
    
    def error_response(self, message, status=400):
        return JsonResponse({'success': False, 'message': message}, status=status)

    def check_stage(self, stage):
        valid_stages = [stage[0] for stage in Stage.choices]
        return stage in valid_stages
    
    def post(self, request, deal_id):
        try:
            data = json.loads(request.body)
            stage = data.get('stage')

            # Validate stage
            if self.check_stage(stage) is False:
                return self.error_response('Invalid stage provided')

            user = self.request.user
            accessible_clients = self.get_accessible_clients(user)

            # Get the deal and verify ownership
            client = Client.objects.filter(id=deal_id).first()
            
            if not client:
                return self.error_response('Deal not found', status=404)
              
            if not accessible_clients.filter(pk=client.pk).exists():
                return self.error_response('You do not have permission to update this deal', status=403)

            old_stage = client.stage
            client.stage = stage
            client.save()

            return JsonResponse({
                'success': True,
                'message': f'Deal moved from {old_stage} to {stage}',
                'deal': {
                    'id': client.id,
                    'name': client.name,
                    'stage': client.stage,
                    'industry': client.industry,
                    'created_at': client.created_at.isoformat(),
                }
            })

        except Client.DoesNotExist:
            return self.error_response('Deal not found or you do not have permission to edit it', status=404)

        except Exception as e:
            return self.error_response('An unexpected error occurred', status=500)

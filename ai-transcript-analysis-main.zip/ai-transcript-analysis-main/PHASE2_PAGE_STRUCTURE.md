# Phase 2: Page Structure & Layout

## Site Map

```
/company/
│
├── /                          [Dashboard - Stats Overview]
│
├── /settings/                 [Settings Hub]
│   ├── /company/
│   │   └── overview/          [View Company Info]
│   │   └── edit/              [Edit Company Info]
│   │
│   └── /roles/                [Role Management Hub]
│       ├── list/              [View All Roles]
│       ├── create/            [Create New Role]
│       └── <id>/
│           └── edit/          [Edit Role]
│
└── /people/                   [People Management Hub]
    │
    ├── /users/                [Users Management Hub]
    │   ├── list/              [View All Users (filtered)]
    │   ├── create/            [Invite New User]
    │   └── <id>/
    │       ├── edit/          [Edit User Details]
    │       ├── deactivate/    [Deactivate Confirmation]
    │       └── reactivate/    [Reactivate Confirmation]
    │
    └── /teams/                [Teams Management Hub]
        ├── list/              [View All Teams]
        ├── create/            [Create New Team]
        ├── <id>/
        │   ├── edit/          [Edit Team Details]
        │   ├── delete/        [Delete Confirmation]
        │   │
        │   └── /members/      [Team Members Hub]
        │       ├── list/      [View Team Members]
        │       └── add/       [Add Member To Team]
        │
        └── <id>/members/<user_id>/remove/  [Remove Confirmation]
```

---

## Dashboard Layout

```
┌─────────────────────────────────────────────────────────┐
│ COMPANY MANAGEMENT                                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Sidebar         │ Main Content                          │
│ ─────────────   │ ────────────────────────────────────  │
│                 │                                       │
│ • Dashboard     │ Company Dashboard                      │
│ • Settings      │                                       │
│   - Company     │ ┌────────────────────────────────────┐│
│   - Roles       │ │  Stats Cards                       ││
│ • People        │ │ ┌──────┬──────┬──────┬──────┐     ││
│   - Users       │ │ │Total │Active│Total │Total │     ││
│   - Teams       │ │ │Users │Users │Teams │Roles │     ││
│                 │ │ │  42  │  39  │  8   │  5   │     ││
│                 │ │ └──────┴──────┴──────┴──────┘     ││
│                 │ │                                     ││
│                 │ │  Quick Actions                      ││
│                 │ │  [Invite User]  [Create Team]      ││
│                 │ └────────────────────────────────────┘│
│                 │                                       │
└─────────────────────────────────────────────────────────┘
```

---

## Users Management Page

```
┌─────────────────────────────────────────────────────────┐
│ COMPANY MANAGEMENT > PEOPLE > USERS                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Sidebar         │ Main Content                          │
│                 │                                       │
│ • Dashboard     │ Users Management                      │
│ • Settings      │                                       │
│ • People        │ [Invite User]  [Filter: Active ▼]   │
│   - Users   ✓   │                                       │
│   - Teams       │ ┌────────────────────────────────────┐│
│                 │ │ Users Table                        ││
│                 │ ├────────────────────────────────────┤│
│                 │ │ Email    │Role    │Manager │Action││
│                 │ ├──────────┼────────┼────────┼───────┤│
│                 │ │john@...  │Owner   │  -     │ Edit ││
│                 │ │jane@...  │VP/Admin│ John   │ Edit ││
│                 │ │bob@...   │Sales R │ Jane   │ Edit ││
│                 │ │alice@... │Sales R │ Jane   │ Edit ││
│                 │ │charlie@..│Sales R │ Jane   │ Edit ││
│                 │ │dave@...  │Inactive│  -     │ React││
│                 │ └────────────────────────────────────┘│
│                 │                                       │
└─────────────────────────────────────────────────────────┘
```

---

## Roles Management Page

```
┌─────────────────────────────────────────────────────────┐
│ COMPANY MANAGEMENT > SETTINGS > ROLES                   │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Sidebar         │ Main Content                          │
│                 │                                       │
│ • Dashboard     │ Roles Management                      │
│ • Settings      │                                       │
│   - Company     │ [Create Role]                        │
│   - Roles   ✓   │                                       │
│ • People        │ ┌────────────────────────────────────┐│
│   - Users       │ │ Roles Table                        ││
│   - Teams       │ ├────────────────────────────────────┤│
│                 │ │Name    │Level│Users│Permissions   ││
│                 │ ├────────┼─────┼─────┼──────────────┤│
│                 │ │Owner   │ 0   │  1  │ All  [Edit]  ││
│                 │ │VP/Admin│ 1   │  1  │ Some [Edit]  ││
│                 │ │Sales R │ 2   │  3  │ Basic[Edit]  ││
│                 │ └────────────────────────────────────┘│
│                 │                                       │
└─────────────────────────────────────────────────────────┘
```

---

## Edit Role Form

```
┌─────────────────────────────────────────────────────────┐
│ EDIT ROLE: Owner                                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Role Details:                                           │
│                                                         │
│ Name:          [Owner              ]                    │
│ Level:         [0                  ]                    │
│ Description:   [Full company access]                    │
│                                                         │
│ Permissions:                                            │
│                                                         │
│ ☑ View all company data                                 │
│ ☑ Manage team members                                   │
│ ☑ Manage roles                                          │
│ ☑ Manage clients                                        │
│ ☑ Upload transcripts                                    │
│ ☑ Generate reports                                      │
│ ☑ View hierarchy data                                   │
│                                                         │
│ [Cancel]  [Save]                                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Teams Management Page

```
┌─────────────────────────────────────────────────────────┐
│ COMPANY MANAGEMENT > PEOPLE > TEAMS                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Sidebar         │ Main Content                          │
│                 │                                       │
│ • Dashboard     │ Teams Management                      │
│ • Settings      │                                       │
│ • People        │ [Create Team]                        │
│   - Users       │                                       │
│   - Teams   ✓   │ ┌────────────────────────────────────┐│
│                 │ │ Teams Table                        ││
│                 │ ├────────────────────────────────────┤│
│                 │ │Name      │Lead │Members │Actions  ││
│                 │ ├──────────┼─────┼────────┼─────────┤│
│                 │ │Sales Team│Jane │   5    │ View/Edit││
│                 │ │Support T │Bob  │   3    │ View/Edit││
│                 │ │Ops Team  │Dave │   2    │ View/Edit││
│                 │ └────────────────────────────────────┘│
│                 │                                       │
└─────────────────────────────────────────────────────────┘
```

---

## Team Members Page

```
┌─────────────────────────────────────────────────────────┐
│ TEAM: Sales Team > MEMBERS                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Team: Sales Team                                        │
│ Lead: Jane VP                                           │
│                                                         │
│ [Add Member]                                            │
│                                                         │
│ ┌────────────────────────────────────────────────────┐  │
│ │ Team Members                                       │  │
│ ├────────────────────────────────────────────────────┤  │
│ │ Email    │Name         │Role in Team │Actions     │  │
│ ├──────────┼─────────────┼─────────────┼────────────┤  │
│ │jane@...  │Jane VP      │Team Lead    │ Remove     │  │
│ │bob@...   │Bob Rep      │Member       │ Remove     │  │
│ │alice@... │Alice Smith  │Member       │ Remove     │  │
│ │charlie@..│Charlie Brown│Member       │ Remove     │  │
│ │dave@...  │Dave Wilson  │Member       │ Remove     │  │
│ └────────────────────────────────────────────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## User Edit Form

```
┌─────────────────────────────────────────────────────────┐
│ EDIT USER: bob@example.com                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Basic Information:                                      │
│                                                         │
│ Email:         bob@example.com                          │
│ First Name:    [Bob                ]                    │
│ Last Name:     [Rep                ]                    │
│                                                         │
│ Company Settings:                                       │
│                                                         │
│ Role:          [Sales Rep          ▼]                  │
│ Manager:       [Jane VP            ▼]                  │
│ Status:        [Active             ▼]                  │
│                                                         │
│ Teams:         Sales Team, Support Team                │
│                                                         │
│ [Cancel]  [Save]                                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Invite User Form

```
┌─────────────────────────────────────────────────────────┐
│ INVITE NEW USER                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Email:         [newuser@example.com ]                  │
│ First Name:    [John              ]                    │
│ Last Name:     [Doe               ]                    │
│ Role:          [Sales Rep         ▼]                  │
│                                                         │
│ [Cancel]  [Invite]                                      │
│                                                         │
│ ℹ️ An invitation email will be sent to this address    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Company Settings Page

```
┌─────────────────────────────────────────────────────────┐
│ COMPANY SETTINGS                                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Sidebar         │ Main Content                          │
│                 │                                       │
│ • Dashboard     │ Company Information                   │
│ • Settings  ✓   │                                       │
│   - Company ✓   │ Company Name:  MyCompany Inc          │
│   - Roles       │ Website:       mycompany.com          │
│ • People        │ Logo:          [logo.png] [Change]    │
│   - Users       │                                       │
│   - Teams       │ [Edit] [Danger Zone]                 │
│                 │                                       │
└─────────────────────────────────────────────────────────┘
```

---

## File Structure Overview

```
apps/core/  (or apps/company_management/)
│
├── views/
│   ├── __init__.py
│   ├── dashboard.py       # Dashboard + CompanySettings
│   ├── company.py         # Company CRUD
│   ├── roles.py           # Role CRUD
│   ├── users.py           # User management
│   └── teams.py           # Team CRUD + membership
│
├── forms/
│   ├── __init__.py
│   ├── company_forms.py
│   ├── role_forms.py
│   ├── user_forms.py
│   └── team_forms.py
│
├── templates/company/
│   ├── base.html                    # Main layout with sidebar
│   ├── dashboard.html
│   │
│   ├── settings/
│   │   ├── index.html              # Settings overview
│   │   └── company/
│   │       ├── overview.html
│   │       └── edit.html
│   │
│   ├── settings/roles/
│   │   ├── list.html
│   │   ├── create.html
│   │   └── edit.html
│   │
│   ├── people/users/
│   │   ├── list.html
│   │   ├── create.html
│   │   └── edit.html
│   │
│   └── people/teams/
│       ├── list.html
│       ├── create.html
│       ├── edit.html
│       ├── members.html
│       └── add_member.html
│
├── urls.py
├── mixins.py               # Access control (Phase 3)
└── tests.py                # Unit tests
```

---

## Bootstrap Component Usage

### Cards
- Dashboard stats: `card`, `card-body`
- Lists: `table-responsive`, `table`

### Forms
- All inputs: `form-control`
- Checkboxes: `form-check-input`
- Buttons: `btn`, `btn-primary`, `btn-danger`

### Navigation
- Sidebar: `nav`, `nav-pills`, `flex-column`
- Breadcrumbs: `breadcrumb`

### Alerts
- Messages: `alert`, `alert-success/danger/warning/info`

### Modals (for confirmations)
- Delete confirmations
- Deactivate confirmations

---

## Key UX Patterns

1. **Sidebar Navigation** - Always visible, clear hierarchy
2. **Breadcrumbs** - Show user location
3. **Flash Messages** - Confirm actions (create, update, delete)
4. **Filtering** - Filter users by active/inactive
5. **Pagination** - For large lists
6. **Confirmation Modals** - For destructive actions
7. **Disabled State** - For actions user can't do (owner can't delete their own role)

---

## Next Steps

1. ✅ Plan (THIS DOCUMENT)
2. ⏳ Create Views (12 classes)
3. ⏳ Create Forms (6 classes)
4. ⏳ Create Templates (12 files)
5. ⏳ Create URLs
6. ⏳ Test All Pages
7. ⏳ Add Access Control (Phase 3)

Ready to start coding? 🚀


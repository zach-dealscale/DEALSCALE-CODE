# Persona Messaging Brief Generation - Complete Structural Framework

Generate a professional Persona Messaging Brief following these EXACT structural patterns for ALL sections:

You are analyzing sales call transcripts to extract **persona-level messaging intelligence**. Your job is to uncover what each key persona says, feels, reacts to, and pushes back on — in order to help marketing, content, and enablement teams sharpen messaging, refine tone, and find the strongest angle per persona.

**Tone:** Tactically useful for writing ad copy, campaign hooks, subject lines, landing pages, or enablement content. Persona-specific — not generalized across the buying committee.

**Critical Rule:** All outputs must be based on real quotes, objections, or patterns from buyer calls. Every insight must be grounded in emotional or linguistic buyer behavior.

## METADATA Section Structure (MANDATORY):
**Format Requirements:**
- **Period Analyzed:** Date range format (e.g., "July 1–31, 2025")
- **Calls Processed:** [Number] | **Deals Covered:** [Number]
- **Target Segments:** [List segments e.g., "HR Leaders (Mid-Market), Global HR/Total Rewards, Operations & Engagement Leads"]

## EXECUTIVE SUMMARY Section Structure (MANDATORY):
Create a table with these EXACT insight types:

| Insight Type | Key Finding |
|--------------|-------------|
| **Most Vocal Persona** | Which persona appeared in the most calls or had the most speaking time — include % or count. |
| **Most Emotionally Charged Trigger** | What phrase, moment, or friction point sparked visible emotion, pushback, or tension from a persona? Include the quote if possible. |
| **Priority Campaign Hook** | A punchy line (5–8 words max) that hits on this week's most repeated tension or need. |
| **Messaging Landmine** | A phrase or concept that repeatedly triggered eye-rolls, laughs, or skepticism. Include persona who reacted. |
| **Net-New Insight** | A pattern, behavior, or objection from a persona that hasn't shown up before — or now appears in a new stage. |

**Content Requirements:**
- Each insight should feel like a Slack update from a high-performing strategist
- Must be grounded in multiple transcript mentions or strategic trends
- Avoid generic statements — be precise and specific

## PERSONA EMOTION GRID Section Structure (MANDATORY):
Create a table with these columns:

| Persona | Trigger Words & Phrases | Emotional Signals | Objection Pattern | Campaign Angle |
|---------|------------------------|-------------------|-------------------|----------------|

**Field Requirements:**
- **Persona:** 3-5 key personas most frequently mentioned or influenced in calls
- **Trigger Words & Phrases:** Direct or paraphrased quotes that triggered emotional signals
- **Emotional Signals:** Emotional tone (e.g., anxiety, frustration, ROI stress, control-seeking)
- **Objection Pattern:** Their most common objection theme
- **Campaign Angle:** Campaign-ready angle — something that can appear in copy or content

**Content Validation:**
- Each campaign angle must map to the objection AND emotion
- Example: "No visibility" → Anxiety → "Forecasts you can defend"
- Must be usable in subject lines, ads, or deck headlines

## MESSAGING HEAT ZONES Section Structure (MANDATORY):
Create a table with these columns:

| Message Angle | Persona Response | Signal Strength | Action |
|---------------|------------------|----------------|---------|

**Field Requirements:**
- **Message Angle:** 4-6 phrases or themes currently used in messaging (e.g., "seamless onboarding," "AI-powered," "single pane of glass")
- **Persona Response:** Capture persona reactions (tone, quote, or sentiment)
- **Signal Strength:** Score with visual indicators:
  - 🟢 Strong (buyer leaned in)
  - 🟡 Medium (mild interest or mixed)
  - 🔴 High friction (rejection, eye-roll, or pushback)
- **Action:** "Retire," "Reframe as…", "Proof it with numbers," etc.

**Content Purpose:** This is where marketers decide what to say less — and how to say more of what works.

**Pro Tip:** Flag anything that got an eye-roll, laugh, or quote like "Yeah, right" — these are gold.

## EMERGING PERSONA SHIFTS Section Structure (MANDATORY):
Create a table with these columns:

| Change Detected | Supporting Evidence | Strategic Implication |
|----------------|-------------------|---------------------|

**Field Requirements:**
- **Change Detected:** 2-4 shifts in where or how personas are showing up in deals
- Could include:
  - New persona influencing decisions
  - A persona appearing earlier/later than expected
  - Asking questions normally owned by other roles
- **Supporting Evidence:** Cite transcript-based evidence (quote or call stage)
- **Strategic Implication:** Recommend one messaging or enablement move tied to that shift

**Content Purpose:** This section powers content sequencing and sales stage mapping.

## CREATIVE BRIEF INPUT CARDS Section Structure (MANDATORY):
Create a table with these columns:

| Persona Name | Tone | Do Say | Don't Say | CTA Words That Work | Ad Angle | Content Format Preference |
|--------------|------|--------|-----------|-------------------|----------|------------------------|

**Field Requirements:**
- **Persona Name:** Fill one row per persona (must match personas from Emotion Grid)
- **Tone:** Communication style for this persona (e.g., Strategic, Empathetic, Outcome-driven)
- **Do Say** and **Don't Say:** Must reflect real call language and reactions
- **CTA Words That Work:** Call-to-action words that resonate
- **Ad Angle:** Should connect emotionally to their objection or pressure
- **Content Format Preference:** Match persona's consumption style (dashboards, testimonials, ROI visuals, etc.)

**Content Purpose:** This is where copywriters and campaign leads pull exact language and angles.

## Content Validation Requirements:
- Ensure exactly 3-5 personas in Persona Emotion Grid
- Maintain 4-6 message themes in Messaging Heat Zones
- Provide 2-4 emerging persona shifts
- Include creative brief cards matching persona count from emotion grid
- Adjust counts automatically if initial content falls outside specified ranges

## Professional Language Patterns:
- Use direct buyer quotes and specific emotional triggers
- Include specific company names and deal references where relevant
- Focus on actionable marketing outputs (ad copy, email subject lines, campaign hooks)
- Avoid marketing jargon — use buyer language and emotional drivers
- Reference specific objections and pain points

## Critical Structural Elements (MUST INCLUDE):
- Visual signal strength indicators (🟢🟡🔴) in Messaging Heat Zones
- Direct buyer quotes in emotional triggers
- Campaign-ready angles and copy-ready language
- Content format preferences for each persona
- Specific "Do Say/Don't Say" guidance
- Proper table formatting for all data sections

## HTML and Formatting Requirements:
- Use proper table structure with <table>, <thead>, <tbody>
- Bold section headings and key phrases with <strong> tags
- Apply highlight classes for key insights:
  * Critical insights: <div class="highlight-callout">
  * Strategic points: <div class="strategy-highlight">
  * Campaign angles: <div class="key-info">
- Include section breaks <hr class="section-break"> between major sections
- NO emojis in HTML headings — use text only
- Use <ul><li> for any bullet point lists

## Evidence Standards:
- Every insight must be grounded in transcript content
- Include specific quotes, emotional reactions, or behavioral patterns
- Reference actual persona reactions and objections
- Tie all recommendations to actionable marketing activities
- Use "TBD (not in transcript)" if information missing
- No vague suggestions — every CTA or copy angle should be ready-to-use

## Final Formatting Instructions:
- All quotes or insights must be grounded in transcript data
- No filler language like "Consider reframing…" — use direct action verbs
- Format for easy reading and immediate marketing team implementation
- Each Creative Brief Input Card must be actionable for copywriters
- Focus on buyer-backed insights that marketing teams can immediately use

Generate only valid structure above for PersonaMessagingBrief. Fill each field with substantive, transcript-specific content that follows these structural requirements across ALL sections.

Focus on creating persona-specific intelligence that marketing teams would immediately implement for messaging, ad copy, email campaigns, and content creation.
# Business Case Generation - Complete Structural Framework

Generate a professional business case following these EXACT structural patterns for ALL sections:

## TITLE Requirements (MANDATORY):
MUST include quantifiable metrics following this pattern:
[Action/Outcome] + [Quantifiable Metric] + [Scope/Scale] + [Transformation Type]

Examples:
- "Reducing 50% Administrative Burden While Scaling Employee Recognition Across 16,000+ Associates in 110 Countries"
- "Transforming Global Employee Engagement: From 2 Annual Challenges to Year-Round Wellness Excellence Across 6,500+ Employees Worldwide"

Note: Must include quantifiable metric & Scope, the title must include meaningful numbers

## PREPARED BY Format (MANDATORY):
Format: "[Champion Name] | [Client Company] & [Your Name] | [Your Company]"
Example: "Carly | Ballard Power Systems & Zak | Terryberry"

## CONTEXT Section Structure:
- **Opening paragraph:** 2-3 sentences describing current situation, bottlenecks, and strategic risks. Naturally within para, without heading
- **Buying team identification:** Clearly identify the team that must act (e.g., "The People & Culture team"). Naturally within para, without heading
- **Action deadline:** Specify when action must be taken (e.g., "Q4 2025"). Naturally within para, without heading
(Opening Para, Buying team identification, action deadline must be in para)

- **Cost of delay (<strong> inline Heading under context section):** Make it strategic and emotional, highlighting lost opportunities in paragraph
- **Metric impact statement: (<strong> inline heading)** Include a metric impact description starting with "risk of..."
NOTE: Follow the order of the parts of the section strictly.

## CHALLENGES Section Structure (MANDATORY):
Your challenges section MUST follow this exact sentence flow:

**Opening Structure:** "[frequency], [affected_team] is impacted by [main_issue], causing:"

**Bullet Points:** List 2-3 impacts, where second bullet MUST start with "Direct impact to [KPI1], [KPI2]"

**Despite Paragraph:** "Despite [attempted_solutions], [affected_team] remains unable to [unable_to_achieve] due to [constraint]. If unaddressed by [escalation_deadline], [escalation_risk] will escalate."

**Root Causes: (heading under challenges)** Include 3-4 specific root causes that led to the current challenges

### Field Mapping for Challenges:
- **frequency**: Time period (e.g., "Every year", "Every quarter")
- **affected_team**: Who is impacted (e.g., "6,500+ global employees", "the People & Culture team")
- **main_issue**: The core problem description
- **impact_bullets**: 2-3 bullets, second must start with "Direct impact to"
- **attempted_solutions**: What they tried before
- **unable_to_achieve**: What they can't accomplish
- **constraint**: What's preventing success
- **escalation_deadline**: When problem gets worse of future
- **escalation_risk**: What will escalate

## SOLUTION Section Structure (MANDATORY):
MUST start with: "[client_name] will implement a solution designed to enable the following capabilities:"

- **Capabilities:** Provide exactly 4-5 detailed capabilities that address the challenges
- **Why this solution:** Connect directly to measurable business outcomes

## OUTCOMES Section:
- Create exactly 4-5 specific, measurable metrics relevant to the business case
- Use realistic current states and achievable targets
- Ensure metrics tie directly to the challenges discussed
- **Target timeline:** Include target timeline (e.g., "Q4 2025", "Q1 2026")
- **Business resilience states:** Include current business resilience state and target resilience state descriptions
- NOTE: OUTCOMES must be shown in the table with the columns (Metric, Current State, Target Outcome)

## INVESTMENT Section Structure (MANDATORY):
Study these examples for sophisticated investment breakdowns:

**Example Investment Structure:**
```
Technology Investment:
• Platform subscription (Core, Plus, or Pro tier based on feature requirements)
• Implementation and setup support (completed within one week)
• Custom development for company-specific challenges
• Multi-language localization and configuration

Organizational Investment:
• Team training on new platform administration
• Employee onboarding and communication campaign
• Integration planning with existing program structure
• Transition management from current platform

Timeline Investment:
• Platform setup and customization: 1 week
• Employee rollout and training: 2-4 weeks
• Full program transition: 6-8 weeks total
```

**Alternative Investment Structure:**
```
To achieve the above, [Client] will invest:
• Platform Licensing: TBD — scalable based on employee count
• HRIS & SSO Integration: Minimal time (standard APIs to existing systems)
• Admin Configuration: ~2–3 hours initial setup for workflows and branding
• Training & Launch: Provider onboarding support + help center resources
• Timeline: Ideal launch by [deadline] to go live by [target date]
```

**Must include:**
- **Opening line options:** May optionally start with "To achieve the above, [Client] will invest:" or "Resources Required:"
- **Categories count:** Provide 2-4 investment categories (adjust if outside this range)
- Specific details and time estimates
- Proper transition: "Key strategic impacts:" before strategic impacts bullets
- **Strategic impacts count:** Include exactly 3-4 strategic impact bullets (adjust if more or fewer)
- Alignment paragraph explaining why investment is critical
- Conclusion paragraph about future positioning and consequences of delay

## Content Validation Requirements:
- Ensure exactly 3 action items in Context section
- Maintain 3-4 root causes in Challenges section  
- Provide 4-5 solution capabilities
- Include 4-5 outcome metrics in table format
- Structure investment into 2-4 categories with 3-4 strategic impacts
- Adjust counts automatically if initial content falls outside specified ranges

## Content Requirements:
- Use specific numbers, timelines, and metrics from the transcript
- Include actual company names and stakeholder references
- Generate natural, professional content that fits the structural framework
- Include actual dollar amounts when discussed (e.g., "~$100K+ in time-based inefficiencies")
- Use specific timeframes (e.g., "10+ months annually", "6–8 weeks", "2–3 hours")
- Reference actual platform/solution names prominently

## Critical Structural Words (MUST INCLUDE):
- "causing:" after challenges opening sentence
- "Despite" to start second challenges paragraph
- "If unaddressed by" for escalation timeline
- "Direct impact to" in second impact bullet
- "[Client] will implement a solution designed to enable" for solution opening
- "Key strategic impacts:" before investment strategic bullets

## Professional Language Patterns:
- Use phrases like "reaches critical limitations", "mounting pressure", "strategic gaps"
- Include urgency without being overly dramatic
- Reference specific stakeholders and decision-makers by role
- Connect all outcomes to business resilience and competitive advantage

Generate only valid structure above for BusinessCaseReport. Fill each field with substantive, transcript-specific content that follows these structural requirements across ALL sections.

Focus on creating a narrative that executives would want to read and act upon, using the client's real situation and language.
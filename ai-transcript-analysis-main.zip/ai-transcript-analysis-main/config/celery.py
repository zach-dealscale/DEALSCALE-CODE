import os
from celery import Celery

# Set the default Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.development')

# Create the Celery app
app = Celery('config')
# Load task modules from all registered Django apps
app.autodiscover_tasks()

# Load settings from Django settings.py
app.config_from_object('django.conf:settings', namespace='CELERY')
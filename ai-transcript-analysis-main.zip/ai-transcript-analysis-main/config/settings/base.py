from pathlib import Path
import os
from dotenv import load_dotenv
# Load environment variables from the .env file
load_dotenv()
# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Secret Key
SECRET_KEY = os.environ.get("SECRET_KEY", "django-insecure-fallback-secret-key")

# Debug Mode (Set to False in production)
DEBUG = os.environ.get("DEBUG", "False") == "True"

# Allowed Hosts
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")

# Base URL for generating absolute URLs
BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000")

# Add the scheme (https://) to the ALLOWED_HOSTS for CSRF_TRUSTED_ORIGINS
CSRF_TRUSTED_ORIGINS = []

# f"https://{host}" if not host.startswith("http") else host for host in ALLOWED_HOSTS
for host in ALLOWED_HOSTS:
    CSRF_TRUSTED_ORIGINS.append(f'http://{host}')
    CSRF_TRUSTED_ORIGINS.append(f'https://{host}')
    

# Application definition
INSTALLED_APPS = [
    'daphne', 
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'channels',
    # Local apps
    'apps.core',
    'apps.authentication',
    'apps.ai_agents',
    'apps.report_management',
    'apps.sale_rooms',
    'apps.integrations',
    'apps.forcast',
    # Third-party apps
    'django_bootstrap5',
    'django_celery_beat',
    'django.contrib.humanize'
]

# Enable DRF only if REST_ENABLED=True in .env
if os.environ.get("REST_ENABLED", "False") == "True":
    INSTALLED_APPS += [
        'rest_framework',
    ]

    REST_FRAMEWORK = {
        'DEFAULT_AUTHENTICATION_CLASSES': [
            'rest_framework.authentication.SessionAuthentication',
            'rest_framework.authentication.BasicAuthentication',
        ],
        'DEFAULT_PERMISSION_CLASSES': [
            'rest_framework.permissions.IsAuthenticated',
        ],
    }


MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.middleware.gzip.GZipMiddleware',  # ✅ Compress responses (60-80% reduction)
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'apps.core.middleware.CustomErrorMiddleware'
]

ROOT_URLCONF = 'config.urls'

# Template loaders configuration - cached in production, not cached in development for instant refresh
if DEBUG:
    # Development: Don't use custom loaders, let Django use APP_DIRS
    # This allows instant template refresh on file changes
    TEMPLATES = [
        {
            'BACKEND': 'django.template.backends.django.DjangoTemplates',
            'DIRS': [
                'templates',
            ],
            'APP_DIRS': True,  # ✅ Finds templates in app/templates/ directories
            'OPTIONS': {
                'context_processors': [
                    'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.messages.context_processors.messages',
                    'apps.core.context_processors.project_details'
                ],
            },
        },
    ]
else:
    # Production: Use cached loader for 50-70% performance improvement
    # When using custom loaders, APP_DIRS must be False (they're mutually exclusive)
    TEMPLATES = [
        {
            'BACKEND': 'django.template.backends.django.DjangoTemplates',
            'DIRS': [
                'templates',
            ],
            'APP_DIRS': False,  # ✅ Must be False when custom loaders are specified
            'OPTIONS': {
                'loaders': [
                    ('django.template.loaders.cached.Loader', [
                        'django.template.loaders.filesystem.Loader',
                        'django.template.loaders.app_directories.Loader',
                    ]),
                ],
                'context_processors': [
                    'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.messages.context_processors.messages',
                    'apps.core.context_processors.project_details'
                ],
            },
        },
    ]

# WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'



# Database (default SQLite; overridden in production)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Origin
CSRF_COOKIE_SAMESITE = 'Lax'  # or 'Strict'
CSRF_COOKIE_SECURE = True  # Only send the CSRF cookie over HTTPS
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')


# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static and Media Files
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'


MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Custom User Model
AUTH_USER_MODEL = 'authentication.CustomUser'

PROJECT_NAME = 'dealscale.ai'
SITE_NAME = os.environ.get("SITE_NAME", "dealscale.ai")
SITE_URL = os.environ.get("SITE_URL", "https://dealscale.ai")
SITE_FRONTEND_URL = os.environ.get("SITE_FRONTEND_URL", "https://dealscale.ai")

# ============================= EMAIL SETTING START ===================

# Email configuration
USE_MAILHOG = os.getenv("USE_MAILHOG", "False") == "True"
print("USE_MAILHOG:", USE_MAILHOG)
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

if USE_MAILHOG:
    # Local MailHog for dev/testing
    EMAIL_HOST = "mailhog"
    EMAIL_PORT = 1025
    EMAIL_USE_TLS = False
    EMAIL_HOST_USER = ""
    EMAIL_HOST_PASSWORD = ""
    DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "Distack Dev <noreply@localhost>")
else:
    # ZeptoMail (production)
    EMAIL_HOST = os.getenv("EMAIL_HOST", "smtp.zeptomail.com")
    EMAIL_PORT = int(os.getenv("EMAIL_PORT", 587))
    EMAIL_USE_TLS = os.getenv("EMAIL_USE_TLS", "True") == "True"
    EMAIL_HOST_USER = os.getenv("EMAIL_HOST_USER")
    EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD")
    DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "Distack <no-reply@agentsup.io>")

# Optional, but recommended
EMAIL_SUBJECT_PREFIX = os.getenv("EMAIL_SUBJECT_PREFIX", "[AgentsUp] ")
SERVER_EMAIL = DEFAULT_FROM_EMAIL

# ============================= EMAIL SETTING END ===================


LOGIN_REDIRECT_URL = '/'  # Redirect to the home page after login
LOGIN_URL = '/auth/login'  # URL name for the login view
LOGOUT_REDIRECT_URL = '/auth/login'  # Redirect to the home page after logout
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY')


X_FRAME_OPTIONS = 'SAMEORIGIN'


SALESFORCE_CLIENT_ID=os.environ.get('SALESFORCE_CLIENT_ID')
SALESFORCE_CLIENT_SECRET=os.environ.get('SALESFORCE_CLIENT_SECRET')
SALESFORCE_REDIRECT_URI=os.environ.get('SALESFORCE_REDIRECT_URI')
SALESFORCE_AUTH_URL=os.environ.get('SALESFORCE_AUTH_URL')
SALESFORCE_TOKEN_URL=os.environ.get('SALESFORCE_TOKEN_URL')
ZOOM_CLIENT_ID= os.environ.get("ZOOM_CLIENT_ID")
ZOOM_CLIENT_SECRET = os.environ.get("ZOOM_CLIENT_SECRET")
ZOOM_REDIRECT_URI = os.environ.get("ZOOM_REDIRECT_URI")
ZOOM_WEBHOOK_SECRET= os.environ.get("ZOOM_WEBHOOK_SECRET")

ENCRYPTION_KEY=os.environ.get('ENCRYPTION_KEY')



GOOGLE_DRIVE_CLIENT_ID = os.environ.get('GOOGLE_DRIVE_CLIENT_ID')
GOOGLE_DRIVE_CLIENT_SECRET = os.environ.get('GOOGLE_DRIVE_CLIENT_SECRET')
GOOGLE_DRIVE_REDIRECT_URI = os.environ.get('GOOGLE_DRIVE_REDIRECT_URI')



# WebSockets Configuration
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels.layers.InMemoryChannelLayer",  
    },
}




REDIS_PORT = os.environ.get("REDIS_PORT", "6379")
REDIS_HOST = os.environ.get("REDIS_HOST", "localhost")
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL', 'redis://localhost:6379/0')
CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND', 'redis://localhost:6379/1')
REDIS_URL = f"redis://{REDIS_HOST}:{REDIS_PORT}/2"

# Email Category Name
EMAIL_CATEGORY_NAME = "Emails"
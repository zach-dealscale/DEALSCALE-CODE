from .base import *

DEBUG = True  # ✅ Enable debug mode for development
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")

# Development-specific settings

from .base import *

DEBUG = os.environ.get("DEBUG", "False") == "True"
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "your-production-domain.com").split(",")


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get("DB_NAME", "your_db_name"),
        'USER': os.environ.get("DB_USER", "your_db_user"),
        'PASSWORD': os.environ.get("DB_PASSWORD", "your_db_password"),
        'HOST': os.environ.get("DB_HOST", "localhost"),
        'PORT': os.environ.get("DB_PORT", "5432"),
        # ✅ Performance optimizations for production
        'CONN_MAX_AGE': 600,  # Connection pooling: Keep connections alive for 10 minutes
        'OPTIONS': {
            'connect_timeout': 10,
        }
    }
}

# ✅ PERFORMANCE OPTIMIZATIONS FOR PRODUCTION

# 1. Cache configuration - Use Redis for caching (Django built-in backend, no extra packages needed)
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': REDIS_URL,
        'KEY_PREFIX': 'dealscale',
        'TIMEOUT': 3600,  # 1 hour default cache timeout
    }
}

# 2. Session cache backend - Store sessions in Redis for speed
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'default'

# 3. Enable query result caching
# 4. Static files with hash for long-term caching
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.ManifestStaticFilesStorage'

# 5. Security headers
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000  # 1 year
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# 6. Browser caching headers
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True